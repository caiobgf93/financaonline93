import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import {
  FileText,
  Plus,
  Pencil,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Clock,
  CalendarDays,
  XCircle,
  Filter,
  Tag,
  Bell,
  MoreVertical
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, maskCurrency, parseCurrency } from '@/utils/currency';
import { cn } from '@/lib/utils';

const BillsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [bills, setBills] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filter, setFilter] = useState('all'); // 'all', 'pending', 'paid'

  // Dialog States
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingBill, setEditingBill] = useState(null);
  const [billToDelete, setBillToDelete] = useState(null);

  // Form State
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    due_date: new Date().toLocaleDateString('en-CA'),
    category_id: ''
  });

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch bills with category info
      const { data: billsData, error: billsError } = await supabase
        .from('bills')
        .select(`
          *,
          category:categories(name, icon, color)
        `)
        .eq('user_id', user.id)
        .order('due_date', { ascending: true });

      if (billsError) throw billsError;

      // Fetch categories for the form
      const { data: catData, error: catError } = await supabase
        .from('categories')
        .select('*')
        .eq('user_id', user.id)
        .eq('type', 'expense'); // Only expense categories make sense for bills

      if (catError) throw catError;

      setBills(billsData || []);
      setCategories(catData || []);

      // Check for notifications
      checkUpcomingBills(billsData || []);

    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        variant: "destructive",
        title: "Erro",
        description: "Não foi possível carregar os dados."
      });
    } finally {
      setLoading(false);
    }
  };

  const checkUpcomingBills = (billsList) => {
    const today = new Date().toISOString().split('T')[0];
    const upcoming = billsList.filter(b => b.status === 'pending' && b.due_date === today);

    if (upcoming.length > 0) {
      toast({
        title: "Contas Vencendo Hoje!",
        description: `Você tem ${upcoming.length} conta(s) para pagar hoje.`,
        duration: 5000,
        className: "bg-orange-50 border-orange-200"
      });
    }
  };

  const handleOpenDialog = (bill = null) => {
    if (bill) {
      setEditingBill(bill);
      setFormData({
        description: bill.description,
        amount: formatCurrency(bill.amount),
        due_date: bill.due_date,
        category_id: bill.category_id || ''
      });
    } else {
      setEditingBill(null);
      setFormData({
        description: '',
        amount: '',
        due_date: new Date().toLocaleDateString('en-CA'),
        category_id: ''
      });
    }
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const amount = parseCurrency(formData.amount);
      if (!amount || amount <= 0) {
        toast({
          variant: "destructive",
          title: "Valor inválido",
          description: "Insira um valor maior que zero."
        });
        return;
      }

      if (!formData.category_id) {
        toast({
          variant: "destructive",
          title: "Categoria obrigatória",
          description: "Por favor, selecione uma categoria para a conta."
        });
        return;
      }

      const payload = {
        user_id: user.id,
        description: formData.description,
        amount: amount,
        due_date: formData.due_date,
        category_id: formData.category_id,
        updated_at: new Date().toISOString()
      };

      let error;
      if (editingBill) {
        const { error: updateError } = await supabase
          .from('bills')
          .update(payload)
          .eq('id', editingBill.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('bills')
          .insert([{ ...payload, status: 'pending' }]);
        error = insertError;
      }

      if (error) throw error;

      toast({
        title: editingBill ? "Conta atualizada" : "Conta criada",
        description: editingBill ? "As alterações foram salvas." : "Nova conta agendada com sucesso!"
      });

      setIsDialogOpen(false);
      fetchData(); // Reload to get expanded category data
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro",
        description: error.message
      });
    }
  };

  const confirmDelete = (bill) => {
    setBillToDelete(bill);
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!billToDelete) return;
    try {
      // 1. Delete the bill first (removes the FK reference to the transaction)
      const { error } = await supabase.from('bills').delete().eq('id', billToDelete.id);
      if (error) throw error;

      // 2. If it was paid and had a transaction, delete the orphan transaction
      if (billToDelete.status === 'paid' && billToDelete.transaction_id) {
        const { error: transError } = await supabase
          .from('transactions')
          .delete()
          .eq('id', billToDelete.transaction_id);

        if (transError) {
          console.error('Failed to delete linked transaction', transError);
          // We don't throw here to ensure the UI updates since the bill is already gone
        }
      }

      toast({ title: "Conta excluída", description: "O registro foi removido." });
      setIsDeleteDialogOpen(false);
      fetchData();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  const toggleBillStatus = async (bill) => {
    try {
      const newStatus = bill.status === 'pending' ? 'paid' : 'pending';
      let transactionId = bill.transaction_id;

      if (newStatus === 'paid') {
        // --- MARK AS PAID ---

        // 1. Create Transaction (Inherit Category)
        const { data: transaction, error: transError } = await supabase
          .from('transactions')
          .insert([{
            user_id: user.id,
            description: `Pgto: ${bill.description}`,
            amount: bill.amount,
            type: 'expense',
            transaction_type: 'variable',
            date: new Date().toISOString().split('T')[0], // Paid today
            category_id: bill.category_id // Inherit category!
          }])
          .select()
          .single();

        if (transError) throw transError;
        transactionId = transaction.id;

        // 2. Update Bill with link
        const { error: updateError } = await supabase
          .from('bills')
          .update({
            status: newStatus,
            transaction_id: transactionId,
            updated_at: new Date().toISOString()
          })
          .eq('id', bill.id);

        if (updateError) throw updateError;

      } else {
        // --- UNMARK AS PAID ---

        // 1. Update Bill FIRST to remove link (avoid FK constraints if any)
        const { error: updateError } = await supabase
          .from('bills')
          .update({
            status: newStatus,
            transaction_id: null,
            updated_at: new Date().toISOString()
          })
          .eq('id', bill.id);

        if (updateError) throw updateError;

        // 2. Delete Transaction
        if (transactionId) {
          const { error: deleteError } = await supabase
            .from('transactions')
            .delete()
            .eq('id', transactionId);

          if (deleteError) {
            console.error("Error cleaning up transaction:", deleteError);
            toast({ variant: "destructive", title: "Aviso", description: "Status atualizado, mas houve erro ao limpar a transação antiga." });
          }
        }
      }

      toast({
        title: newStatus === 'paid' ? "Conta Paga!" : "Pagamento Cancelado",
        description: newStatus === 'paid'
          ? "Transação de despesa criada automaticamente."
          : "Status revertido para pendente e transação removida.",
        className: newStatus === 'paid' ? "bg-green-50 border-green-200 text-green-900" : ""
      });

      fetchData();
    } catch (error) {
      console.error(error);
      toast({ variant: "destructive", title: "Erro ao atualizar status", description: error.message });
    }
  };

  const filteredBills = bills.filter(bill => {
    if (filter === 'all') return true;
    return bill.status === filter;
  });

  const getStatusColor = (bill) => {
    if (bill.status === 'paid') return 'bg-green-100 text-green-700 border-green-200';
    const today = new Date().toISOString().split('T')[0];
    if (bill.due_date < today) return 'bg-red-50 text-red-600 border-red-100'; // Overdue
    return 'bg-gray-100 text-gray-600 border-gray-200'; // Upcoming
  };

  const getStatusText = (bill) => {
    if (bill.status === 'paid') return 'Pago';
    const today = new Date().toISOString().split('T')[0];
    if (bill.due_date < today) return 'Atrasado';
    if (bill.due_date === today) return 'Vence Hoje';
    return 'Pendente';
  };

  return (
    <>
      <Helmet><title>Contas a Pagar - Finança Online</title></Helmet>

      <div className="space-y-6 md:space-y-8 pb-20 md:pb-12">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Contas a Pagar</h1>
            <p className="text-gray-500 text-sm md:text-base">Organize seus compromissos financeiros</p>
          </div>
          <Button
            className="w-full sm:w-auto bg-[#3FAE2A] hover:bg-[#359923] gap-2 shadow-sm"
            onClick={() => handleOpenDialog()}
          >
            <Plus size={20} /> <span className="sm:inline">Nova Conta</span>
          </Button>
        </div>

        {/* Filters - Responsive Grid/Flex */}
        <div className="grid grid-cols-3 sm:flex sm:flex-row gap-2 p-1 bg-white rounded-xl border border-gray-100 w-full sm:w-fit shadow-sm">
          {['all', 'pending', 'paid'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-2 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all text-center",
                filter === f
                  ? "bg-[#3FAE2A] text-white shadow-sm"
                  : "text-gray-500 hover:bg-gray-50"
              )}
            >
              {f === 'all' ? 'Todas' : f === 'pending' ? 'Pendentes' : 'Pagas'}
            </button>
          ))}
        </div>

        {/* Loading State */}
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-[#3FAE2A]"></div>
          </div>
        ) : filteredBills.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-gray-200 mx-auto max-w-lg">
            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
              <FileText size={32} />
            </div>
            <p className="text-gray-500 font-medium">Nenhuma conta encontrada.</p>
            <p className="text-sm text-gray-400 mt-1">Adicione uma nova conta para começar a rastrear.</p>
          </div>
        ) : (
          <>
            {/* Desktop Table View */}
            <div className="hidden md:block bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50/50 border-b border-gray-100">
                      <th className="text-left py-4 px-6 font-semibold text-gray-600">Descrição</th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-600">Categoria</th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-600">Vencimento</th>
                      <th className="text-left py-4 px-6 font-semibold text-gray-600">Valor</th>
                      <th className="text-center py-4 px-6 font-semibold text-gray-600">Status</th>
                      <th className="text-right py-4 px-6 font-semibold text-gray-600">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredBills.map((bill) => (
                      <tr key={bill.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors group">
                        <td className="py-4 px-6 font-medium text-gray-800">{bill.description}</td>
                        <td className="py-4 px-6 text-gray-600">
                          <div className="flex items-center gap-2">
                            {bill.category ? (
                              <>
                                <Tag size={14} className="text-gray-400" />
                                <span>{bill.category.name}</span>
                              </>
                            ) : (
                              <span className="text-gray-400 italic text-xs">Sem categoria</span>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-6 text-gray-600">
                          <div className="flex items-center gap-2">
                            <CalendarDays size={16} className="text-gray-400" />
                            {new Date(bill.due_date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}
                          </div>
                        </td>
                        <td className="py-4 px-6 font-bold text-gray-700">
                          {formatCurrency(bill.amount)}
                        </td>
                        <td className="py-4 px-6">
                          <div className={`flex items-center justify-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border w-max mx-auto ${getStatusColor(bill)}`}>
                            {bill.status === 'paid' ? <CheckCircle2 size={12} /> : <Clock size={12} />}
                            {getStatusText(bill)}
                          </div>
                        </td>
                        <td className="py-4 px-6 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className={cn(
                                "h-8 text-xs gap-1 border-gray-200",
                                bill.status === 'paid'
                                  ? "text-gray-500 hover:text-red-600 hover:border-red-200"
                                  : "text-green-600 hover:text-green-700 hover:bg-green-50 border-green-100"
                              )}
                              onClick={() => toggleBillStatus(bill)}
                            >
                              {bill.status === 'paid' ? (
                                <><XCircle size={14} /> Desfazer</>
                              ) : (
                                <><CheckCircle2 size={14} /> Pagar</>
                              )}
                            </Button>

                            <div className="w-px h-4 bg-gray-200 mx-1"></div>

                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-gray-400 hover:text-blue-600"
                              onClick={() => handleOpenDialog(bill)}
                            >
                              <Pencil size={14} />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-gray-400 hover:text-red-600"
                              onClick={() => confirmDelete(bill)}
                            >
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="md:hidden space-y-4">
              {filteredBills.map((bill) => (
                <div key={bill.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex flex-col gap-4">
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-800 text-lg leading-tight truncate">{bill.description}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-gray-500 flex items-center gap-1">
                          <Tag size={12} /> {bill.category?.name || 'Sem categoria'}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end shrink-0">
                      <span className="font-bold text-gray-900 text-lg">
                        {formatCurrency(bill.amount)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-gray-50">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CalendarDays size={14} className="text-gray-400" />
                      <span>{new Date(bill.due_date).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</span>
                    </div>
                    <div className={cn("px-2.5 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5", getStatusColor(bill))}>
                      {bill.status === 'paid' ? <CheckCircle2 size={12} /> : <Clock size={12} />}
                      {getStatusText(bill)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      className={cn(
                        "flex-1 h-10 shadow-sm",
                        bill.status === 'paid'
                          ? "bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-red-600"
                          : "bg-green-50 text-green-700 hover:bg-green-100 border border-green-200"
                      )}
                      variant="outline"
                      onClick={() => toggleBillStatus(bill)}
                    >
                      {bill.status === 'paid' ? (
                        <span className="flex items-center gap-2"><XCircle size={16} /> Desfazer Pgto</span>
                      ) : (
                        <span className="flex items-center gap-2"><CheckCircle2 size={16} /> Marcar como Paga</span>
                      )}
                    </Button>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-10 w-10 border border-gray-100 bg-gray-50">
                          <MoreVertical size={18} className="text-gray-500" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog(bill)}>
                          <Pencil className="mr-2 h-4 w-4" /> Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => confirmDelete(bill)} className="text-red-600 focus:text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" /> Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle>{editingBill ? 'Editar Conta' : 'Nova Conta'}</DialogTitle>
            <DialogDescription>
              {editingBill ? 'Atualize os detalhes da conta.' : 'Adicione uma nova conta a pagar.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-2">
            <div>
              <Label>Descrição</Label>
              <Input
                placeholder="Ex: Aluguel, Internet..."
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                required
                className="text-base"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Valor</Label>
                <Input
                  placeholder="R$ 0,00"
                  value={formData.amount}
                  onChange={e => setFormData({ ...formData, amount: maskCurrency(e.target.value) })}
                  required
                  className="text-base"
                />
              </div>
              <div>
                <Label>Vencimento</Label>
                <Input
                  type="date"
                  value={formData.due_date}
                  onChange={e => setFormData({ ...formData, due_date: e.target.value })}
                  required
                  className="text-base"
                />
              </div>
            </div>

            <div>
              <Label>Categoria <span className="text-red-500">*</span></Label>
              <select
                className="flex h-10 w-full rounded-2xl border border-gray-300 bg-white px-3 py-2 text-base md:text-sm placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-[#3FAE2A] focus:border-transparent disabled:cursor-not-allowed disabled:opacity-50 appearance-none"
                value={formData.category_id}
                onChange={e => setFormData({ ...formData, category_id: e.target.value })}
                required
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='M6 8l4 4 4-4'/%3e%3c/svg%3e")`,
                  backgroundPosition: `right 0.5rem center`,
                  backgroundRepeat: `no-repeat`,
                  backgroundSize: `1.5em 1.5em`,
                  paddingRight: `2.5rem`
                }}
              >
                <option value="" disabled>Selecione uma categoria</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
            </div>

            <DialogFooter className="pt-4 flex-col gap-2 sm:flex-row">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="w-full sm:w-auto">Cancelar</Button>
              <Button type="submit" className="bg-[#3FAE2A] hover:bg-[#359923] w-full sm:w-auto">Salvar</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-500 flex items-center gap-2">
              <AlertCircle size={20} /> Excluir Conta
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir <strong>{billToDelete?.description}</strong>?
              <br />Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)} className="w-full sm:w-auto">Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete} className="bg-red-600 hover:bg-red-500 w-full sm:w-auto">Excluir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BillsPage;

