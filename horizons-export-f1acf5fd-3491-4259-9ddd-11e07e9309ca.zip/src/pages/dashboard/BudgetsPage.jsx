
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import {
  Plus, Trash2, Search, Edit, Receipt, AlertCircle,
  Home, Car, ShoppingBag, CreditCard, Heart, GraduationCap, Smile, FileText,
  TrendingUp, TrendingDown, Briefcase, Utensils, Zap, Droplet, Wifi, Stethoscope,
  PawPrint, Music, Film, Wrench, Plane, Banknote, Globe, Gift, BarChart,
  Lightbulb, Monitor, Wallet, PiggyBank
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { formatCurrency, maskCurrency, parseCurrency } from '@/utils/currency';
import { Progress } from '@/components/ui/progress';

const ICON_OPTIONS = [
  { icon: Home, name: 'Casa', value: 'home' },
  { icon: Car, name: 'Transporte', value: 'car' },
  { icon: ShoppingBag, name: 'Compras', value: 'shopping' },
  { icon: CreditCard, name: 'Cartão', value: 'card' },
  { icon: Heart, name: 'Saúde', value: 'health' },
  { icon: GraduationCap, name: 'Educação', value: 'education' },
  { icon: Smile, name: 'Lazer', value: 'fun' },
  { icon: FileText, name: 'Impostos', value: 'tax' },
  { icon: TrendingUp, name: 'Investimentos', value: 'investment' },
  { icon: Briefcase, name: 'Salário', value: 'salary' },
  { icon: Utensils, name: 'Alimentação', value: 'food' },
  { icon: Receipt, name: 'Contas', value: 'bills' },
  { icon: Zap, name: 'Energia', value: 'energy' },
  { icon: Droplet, name: 'Água', value: 'water' },
  { icon: Wifi, name: 'Internet', value: 'internet' },
  { icon: Stethoscope, name: 'Consultas', value: 'medical' },
  { icon: PawPrint, name: 'Pets', value: 'pets' },
  { icon: Music, name: 'Música', value: 'music' },
  { icon: Film, name: 'Cinema', value: 'cinema' },
  { icon: Wrench, name: 'Manutenção', value: 'maintenance' },
  { icon: Plane, name: 'Viagem', value: 'travel' },
  { icon: Banknote, name: 'Rendimentos', value: 'income' },
  { icon: Monitor, name: 'Freelance', value: 'freelance' },
  { icon: Globe, name: 'Online', value: 'online' },
  { icon: Gift, name: 'Presentes', value: 'gift' },
  { icon: BarChart, name: 'Dividendos', value: 'dividends' },
  { icon: Lightbulb, name: 'Projetos', value: 'projects' },
];

const BudgetsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [budgets, setBudgets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    category_id: '',
    amount: '',
    recurrence: 'once' // once, quarter, semester, year
  });
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [budgetToDelete, setBudgetToDelete] = useState(null);

  const confirmDelete = (budget) => {
    setBudgetToDelete(budget);
    setIsDeleteDialogOpen(true);
  };


  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user, currentDate]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load categories
      const { data: cats } = await supabase
        .from('categories')
        .select('*')
        .eq('user_id', user.id)
        .eq('type', 'expense')
        .order('name');
      setCategories(cats || []);

      // Load budgets for current month
      const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString();
      const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString();

      const { data: budgetsData, error } = await supabase
        .from('budgets')
        .select(`
        *,
        categories (name, icon)
      `)
        .eq('user_id', user.id)
        .gte('start_date', startOfMonth)
        .lte('start_date', endOfMonth);

      if (error) throw error;

      // Calculate spent amount for each budget
      const budgetsWithSpent = await Promise.all((budgetsData || []).map(async (budget) => {
        let transactions = [];

        if (budget.category_id) {
          const { data, error: txError } = await supabase
            .from('transactions')
            .select('amount')
            .eq('category_id', budget.category_id)
            .gte('date', startOfMonth)
            .lte('date', endOfMonth)
            .eq('type', 'expense');

          if (txError) throw txError;
          transactions = data || [];
        }

        const spent = transactions.reduce((sum, t) => sum + Number(t.amount), 0);

        return { ...budget, spent };
      }));

      setBudgets(budgetsWithSpent);
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    } finally {
      setLoading(false);
    }
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const amount = parseCurrency(formData.amount);

      if (editingBudget) {
        // Update existing budget
        const { error } = await supabase
          .from('budgets')
          .update({
            amount: amount,
            category_id: formData.category_id
          })
          .eq('id', editingBudget.id);

        if (error) throw error;
        toast({ title: "Sucesso", description: "Orçamento atualizado!" });
      } else {
        // Create new budget(s)
        const baseDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);

        let monthsToAdd = 1;
        if (formData.recurrence === 'quarter') monthsToAdd = 3;
        if (formData.recurrence === 'semester') monthsToAdd = 6;
        if (formData.recurrence === 'year') monthsToAdd = 12;

        const newBudgets = [];
        for (let i = 0; i < monthsToAdd; i++) {
          const date = new Date(baseDate);
          date.setMonth(baseDate.getMonth() + i);

          newBudgets.push({
            user_id: user.id,
            category_id: formData.category_id,
            amount: amount,
            period_type: 'monthly',
            start_date: date.toISOString(),
            is_recurring: formData.recurrence !== 'once'
          });
        }

        const { error } = await supabase.from('budgets').insert(newBudgets);
        if (error) throw error;
        toast({ title: "Sucesso", description: "Orçamento(s) criado(s)!" });
      }

      setDialogOpen(false);
      resetForm();
      loadData();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  const resetForm = () => {
    setFormData({ category_id: '', amount: '', recurrence: 'once' });
    setEditingBudget(null);
  };

  const openEditDialog = (budget) => {
    setEditingBudget(budget);
    setFormData({
      category_id: budget.category_id,
      amount: formatCurrency(budget.amount),
      recurrence: 'once' // Editing is always single instance for now
    });
    setDialogOpen(true);
  };

  const handleDelete = async (id) => {
    try {
      const { error } = await supabase.from('budgets').delete().eq('id', id);
      if (error) throw error;
      toast({ title: "Excluído", description: "Orçamento removido." });
      loadData();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    } finally {
      setIsDeleteDialogOpen(false);
    }
  };


  const changeMonth = (delta) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(newDate.getMonth() + delta);
    setCurrentDate(newDate);
  };

  const getIcon = (iconValue) => {
    const iconOption = ICON_OPTIONS.find(opt => opt.value === iconValue);
    return iconOption ? iconOption.icon : Home;
  };

  const filteredBudgets = budgets.filter(budget =>
    budget.categories?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Summary Calculations
  const totalBudget = budgets.reduce((acc, curr) => acc + Number(curr.amount), 0);
  const totalSpent = budgets.reduce((acc, curr) => acc + Number(curr.spent), 0);
  const remaining = totalBudget - totalSpent;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#3FAE2A]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet><title>Orçamentos - Finança Online</title></Helmet>
      <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Orçamentos</h1>
            <p className="text-gray-600">Planeje seus gastos mensais</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center justify-between bg-white rounded-lg border border-gray-200 p-1 shadow-sm">
              <Button variant="ghost" size="sm" onClick={() => changeMonth(-1)}>&lt;</Button>
              <span className="px-4 min-w-[140px] text-center font-medium capitalize text-sm">
                {currentDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
              </span>
              <Button variant="ghost" size="sm" onClick={() => changeMonth(1)}>&gt;</Button>
            </div>

            <Dialog open={dialogOpen} onOpenChange={(open) => {
              if (!open) resetForm();
              setDialogOpen(open);
            }}>
              <DialogTrigger asChild>
                <Button className="bg-[#3FAE2A] hover:bg-[#359923] gap-2 shadow-sm hover:shadow-md transition-all w-full sm:w-auto">
                  <Plus size={20} /> Novo Orçamento
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-white sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle className="text-xl font-bold text-[#4A4A4A] text-center">
                    {editingBudget ? 'Editar Orçamento' : 'Novo Orçamento'}
                  </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 py-4">
                  <div>
                    <Label className="text-[#4A4A4A] mb-1.5 block">Categoria</Label>
                    <select
                      className="flex h-11 w-full rounded-2xl border border-gray-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3FAE2A]"
                      value={formData.category_id}
                      onChange={e => setFormData({ ...formData, category_id: e.target.value })}
                      required
                    >
                      <option value="">Selecione uma categoria...</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                    </select>
                    {categories.length === 0 && (
                      <p className="text-xs text-amber-600 mt-1">
                        Você não possui categorias de despesa cadastradas.
                      </p>
                    )}
                  </div>

                  <div>
                    <Label className="text-[#4A4A4A] mb-1.5 block">Valor Limite</Label>
                    <Input
                      value={formData.amount}
                      onChange={e => setFormData({ ...formData, amount: maskCurrency(e.target.value) })}
                      placeholder="R$ 0,00"
                      className="h-11 text-lg font-medium"
                      required
                    />
                  </div>

                  {!editingBudget && (
                    <div>
                      <Label className="text-[#4A4A4A] mb-1.5 block">Repetir por</Label>
                      <select
                        className="flex h-11 w-full rounded-2xl border border-gray-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3FAE2A]"
                        value={formData.recurrence}
                        onChange={e => setFormData({ ...formData, recurrence: e.target.value })}
                      >
                        <option value="once">Apenas este mês</option>
                        <option value="quarter">3 meses (Trimestre)</option>
                        <option value="semester">6 meses (Semestre)</option>
                        <option value="year">12 meses (Ano)</option>
                      </select>
                    </div>
                  )}

                  <Button type="submit" className="w-full bg-[#3FAE2A] hover:bg-[#359923] h-11 font-bold text-lg">
                    {editingBudget ? 'Salvar Alterações' : 'Criar Orçamento'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                   <Wallet size={20} />
                </div>
                <span className="font-medium">Total Orçado</span>
              </div>
              <p className="text-3xl font-bold text-blue-600 tracking-tight">
                {formatCurrency(totalBudget)}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-red-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                <div className="p-2 bg-red-100 rounded-lg text-red-600">
                   <TrendingDown size={20} />
                </div>
                <span className="font-medium">Valor Gasto</span>
              </div>
              <p className="text-3xl font-bold text-red-600 tracking-tight">
                {formatCurrency(totalSpent)}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-green-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                 <div className="p-2 bg-green-100 rounded-lg text-green-600">
                   <PiggyBank size={20} />
                 </div>
                <span className="font-medium">Saldo Disponível</span>
              </div>
              <p className={`text-3xl font-bold tracking-tight ${
                remaining >= 0 ? 'text-[#3FAE2A]' : 'text-red-500'
              }`}>
                {formatCurrency(remaining)}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <Input
            placeholder="Buscar orçamentos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white border-gray-200 w-full"
          />
        </div>

        {/* Budgets List */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {budgets.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Receipt className="text-gray-400" size={24} />
              </div>
              <p className="text-gray-900 font-medium mb-2">Nenhum orçamento definido</p>
              <p className="text-sm text-gray-500">Defina limites de gastos para suas categorias.</p>
            </div>
          ) : filteredBudgets.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Nenhum orçamento encontrado na busca.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredBudgets.map((budget) => {
                const IconComponent = getIcon(budget.categories?.icon);
                const percentage = Math.min((budget.spent / budget.amount) * 100, 100);
                const isOver = budget.spent > budget.amount;

                return (
                  <div
                    key={budget.id}
                    className="group flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 hover:bg-gray-50 transition-colors duration-200 gap-4"
                  >
                    <div className="flex items-center gap-4 w-full sm:w-auto overflow-hidden">
                      <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${isOver ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-600'
                        }`}>
                        <IconComponent size={24} />
                      </div>

                      <div className="min-w-0 flex-1">
                        <h3 className="font-semibold text-gray-800 text-base truncate">
                          {budget.categories?.name || 'Sem categoria'}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <span className={isOver ? 'text-red-600 font-bold' : ''}>{formatCurrency(budget.spent)}</span>
                          <span>/</span>
                          <span>{formatCurrency(budget.amount)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto sm:flex-1 sm:px-8">
                      <Progress
                        value={percentage}
                        indicatorColor={isOver ? "bg-red-500" : "bg-[#3FAE2A]"}
                        className="h-2.5 w-full"
                      />
                      {isOver && (
                        <div className="flex items-center gap-1 text-xs text-red-600 font-bold whitespace-nowrap">
                          <AlertCircle size={12} /> Excedido
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 self-end sm:self-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-gray-400 hover:text-[#3FAE2A] hover:bg-green-50 rounded-full"
                        onClick={() => openEditDialog(budget)}
                      >
                        <Edit size={16} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full"
                        onClick={() => confirmDelete(budget)}
                      >
                        <Trash2 size={16} />
                      </Button>

                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-500 flex items-center gap-2">
              <Trash2 size={20} /> Excluir Orçamento
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir <strong>{budgetToDelete?.categories?.name}</strong>?<br />
              Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => budgetToDelete && handleDelete(budgetToDelete.id)}
              className="bg-red-600 hover:bg-red-500 w-full sm:w-auto"
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BudgetsPage;
