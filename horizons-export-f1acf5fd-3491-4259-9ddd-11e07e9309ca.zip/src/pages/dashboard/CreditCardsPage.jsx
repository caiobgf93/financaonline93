import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { CreditCard, Plus, Trash2, Check, Pencil, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { formatCurrency, maskCurrency, parseCurrency } from '@/utils/currency';
import { checkLimit } from '@/utils/planLimits';

const CARD_COLORS = [
  '#3FAE2A', // Default Green
  '#2563EB', // Blue
  '#7C3AED', // Purple
  '#DB2777', // Pink
  '#DC2626', // Red
  '#EA580C', // Orange
  '#CA8A04', // Yellow
  '#4B5563', // Gray
  '#000000', // Black
];

const CreditCardsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Form Dialog State
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState(null);
  const [formData, setFormData] = useState({ 
    name: '', 
    bank: '', 
    credit_limit: '', 
    due_day: '',
    color: '#3FAE2A'
  });

  // Delete Confirmation State
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [cardToDelete, setCardToDelete] = useState(null);

  useEffect(() => { if (user) loadCards(); }, [user]);

  const loadCards = async () => {
    setLoading(true);
    try {
      const { data: cardsData, error } = await supabase
        .from('credit_cards')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const currentMonth = new Date().toISOString().slice(0, 7);
      const start = `${currentMonth}-01`;
      const [year, month] = currentMonth.split('-');
      const end = new Date(year, month, 0).toISOString().slice(0, 10);

      const cardsWithInvoice = await Promise.all(
        cardsData.map(async (card) => {
          const { data: transactions } = await supabase
            .from('transactions')
            .select('amount')
            .eq('credit_card_id', card.id)
            .gte('date', start)
            .lte('date', end)
            .eq('type', 'expense');

          const current_invoice =
            transactions?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;

          return { ...card, current_invoice };
        })
      );

      setCards(cardsWithInvoice);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Erro', description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (card = null) => {
    if (card) {
      setEditingCard(card);
      setFormData({
        name: card.name,
        bank: card.bank,
        // Fix: Use formatCurrency to display the correct value initially (e.g. "R$ 2.000,00")
        credit_limit: formatCurrency(card.credit_limit),
        due_day: card.due_day.toString(),
        color: card.color || '#3FAE2A'
      });
    } else {
      setEditingCard(null);
      setFormData({ name: '', bank: '', credit_limit: '', due_day: '', color: '#3FAE2A' });
    }
    setDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!editingCard) {
        const allowed = await checkLimit(user.id, 'credit_cards');
        if (!allowed) throw new Error("Limite de cartões do seu plano atingido!");
      }

      const payload = {
        user_id: user.id,
        name: formData.name,
        bank: formData.bank,
        credit_limit: parseCurrency(formData.credit_limit),
        due_day: parseInt(formData.due_day),
        color: formData.color
      };

      let error;
      
      if (editingCard) {
        const result = await supabase
          .from('credit_cards')
          .update(payload)
          .eq('id', editingCard.id);
        error = result.error;
      } else {
        const result = await supabase
          .from('credit_cards')
          .insert([payload]);
        error = result.error;
      }

      if (error) throw error;

      toast({ 
        title: editingCard ? "Cartão atualizado" : "Cartão criado", 
        description: editingCard ? "As alterações foram salvas." : "Novo cartão adicionado com sucesso!" 
      });
      setDialogOpen(false);
      loadCards();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  const confirmDelete = (card) => {
    setCardToDelete(card);
    setDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!cardToDelete) return;

    const { error } = await supabase.from('credit_cards').delete().eq('id', cardToDelete.id);
    
    setDeleteDialogOpen(false);
    setCardToDelete(null);

    if (!error) {
      toast({ title: "Excluído", description: "Cartão removido." });
      loadCards();
    } else {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  return (
    <>
      <Helmet><title>Cartões de Crédito - Finança Online</title></Helmet>
      <div className="p-4 lg:p-8 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Cartões de Crédito</h1>
            <p className="text-gray-600">Gerencie seus limites e faturas</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="bg-[#3FAE2A] hover:bg-[#359923] gap-2"
                onClick={() => handleOpenDialog(null)}
              >
                <Plus size={20} /> Novo Cartão
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white">
              <DialogHeader>
                <DialogTitle>{editingCard ? 'Editar Cartão' : 'Adicionar Cartão'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div><Label>Apelido do Cartão</Label><Input value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Ex: Nubank Principal" required /></div>
                <div><Label>Banco</Label><Input value={formData.bank} onChange={e => setFormData({...formData, bank: e.target.value})} placeholder="Ex: Nubank" required /></div>
                <div><Label>Limite de Crédito</Label><Input value={formData.credit_limit} onChange={e => setFormData({...formData, credit_limit: maskCurrency(e.target.value)})} placeholder="R$ 0,00" required /></div>
                <div><Label>Dia do Vencimento</Label><Input type="number" min="1" max="31" value={formData.due_day} onChange={e => setFormData({...formData, due_day: e.target.value})} placeholder="Dia" required /></div>
                
                <div>
                  <Label className="mb-2 block">Cor do Cartão</Label>
                  <div className="flex flex-wrap gap-3">
                    {CARD_COLORS.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setFormData({...formData, color})}
                        className={`w-8 h-8 rounded-full flex items-center justify-center border border-gray-200 transition-transform hover:scale-110 ${formData.color === color ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                        style={{ backgroundColor: color }}
                      >
                        {formData.color === color && <Check size={14} className="text-white" />}
                      </button>
                    ))}
                  </div>
                </div>

                <Button type="submit" className="w-full bg-[#3FAE2A]">
                  {editingCard ? 'Salvar Alterações' : 'Adicionar Cartão'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="bg-white sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-600">
                <AlertTriangle size={20} />
                Confirmar Exclusão
              </DialogTitle>
              <DialogDescription className="pt-2">
                Tem certeza que deseja excluir o cartão <strong>{cardToDelete?.name}</strong>? 
                <br /><br />
                Esta ação não pode ser desfeita e pode afetar o histórico de transações vinculadas a este cartão.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="gap-2 sm:gap-0">
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Cancelar
              </Button>
              <Button variant="destructive" onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Excluir Cartão
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#3FAE2A]"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cards.map((card) => {
              const limit = Number(card.credit_limit);
              const invoice = Number(card.current_invoice || 0);
              const percentage = Math.min((invoice / limit) * 100, 100);
              const available = limit - invoice;
              const cardColor = card.color || '#3FAE2A';

              return (
                <div key={card.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col h-full">
                  <div 
                    className="p-6 text-white relative transition-colors"
                    style={{ backgroundColor: cardColor }}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm opacity-80">{card.bank}</p>
                        <h3 className="text-xl font-bold mt-1">{card.name}</h3>
                      </div>
                      <CreditCard className="opacity-80" size={24} />
                    </div>
                    <div className="mt-6 flex justify-between items-end">
                      <div>
                        <p className="text-xs opacity-80">Vencimento</p>
                        <p className="font-medium">Dia {card.due_day}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-white hover:bg-white/20 h-8 w-8" 
                          onClick={() => handleOpenDialog(card)}
                          title="Editar"
                        >
                          <Pencil size={16} />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-white hover:bg-white/20 h-8 w-8" 
                          onClick={() => confirmDelete(card)}
                          title="Excluir"
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6 space-y-4 flex-1 flex flex-col justify-center">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">Fatura Atual</span>
                        <span className="font-bold text-[#4A4A4A]">{formatCurrency(invoice)}</span>
                      </div>
                      
                      <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden mt-2">
                         <div 
                            className="h-full transition-all duration-300" 
                            style={{ width: `${percentage}%`, backgroundColor: cardColor }} 
                         />
                      </div>

                      <div className="flex justify-between text-xs text-gray-500">
                        <span>0%</span>
                        <span>{percentage.toFixed(0)}%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-gray-100 mt-auto">
                      <div>
                        <p className="text-xs text-gray-500">Limite Total</p>
                        <p className="text-sm font-bold text-[#4A4A4A]">{formatCurrency(limit)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Disponível</p>
                        <p className="text-sm font-bold" style={{ color: cardColor }}>{formatCurrency(available)}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {cards.length === 0 && (
              <div className="col-span-full text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
                <p className="text-gray-500">Nenhum cartão cadastrado.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </>
  );
};

export default CreditCardsPage;
