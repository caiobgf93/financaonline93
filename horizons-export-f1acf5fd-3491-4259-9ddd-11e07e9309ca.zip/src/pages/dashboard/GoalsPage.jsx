import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Target, Plus, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { formatCurrency, maskCurrency, parseCurrency } from '@/utils/currency';
import { Progress } from '@/components/ui/progress';
import { checkLimit } from '@/utils/planLimits';

const GoalsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [goals, setGoals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [formData, setFormData] = useState({ name: '', target_amount: '', current_amount: '', deadline: '' });

  // Estados para exclusão
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [goalToDelete, setGoalToDelete] = useState(null);

  useEffect(() => { if (user) loadGoals(); }, [user]);

  const loadGoals = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('financial_goals').select('*').eq('user_id', user.id);
      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        user_id: user.id,
        name: formData.name,
        target_amount: parseCurrency(formData.target_amount),
        current_amount: parseCurrency(formData.current_amount),
        deadline: formData.deadline || null
      };

      if (editingGoal) {
        const { error } = await supabase.from('financial_goals').update(payload).eq('id', editingGoal.id);
        if (error) throw error;
        toast({ title: "Atualizado", description: "Meta atualizada!" });
      } else {
        const allowed = await checkLimit(user.id, 'financial_goals');
        if (!allowed) throw new Error("Limite de metas do seu plano atingido!");

        const { error } = await supabase.from('financial_goals').insert([payload]);
        if (error) throw error;
        toast({ title: "Criado", description: "Meta criada!" });
      }

      setDialogOpen(false);
      setEditingGoal(null);
      setFormData({ name: '', target_amount: '', current_amount: '', deadline: '' });
      loadGoals();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  const handleEdit = (goal) => {
    setEditingGoal(goal);
    setFormData({
      name: goal.name,
      target_amount: formatCurrency(goal.target_amount),
      current_amount: formatCurrency(goal.current_amount),
      deadline: goal.deadline || ''
    });
    setDialogOpen(true);
  };

  const confirmDelete = (goal) => {
    setGoalToDelete(goal);
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async (id) => {
    try {
      const { error } = await supabase.from('financial_goals').delete().eq('id', id);
      if (error) throw error;
      toast({ title: "Excluído", description: "Meta removida." });
      loadGoals();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    } finally {
      setIsDeleteDialogOpen(false);
    }
  };

  return (
    <>
      <Helmet><title>Metas - Finança Online</title></Helmet>
      <div className="p-4 lg:p-8 max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Metas Financeiras</h1>
            <p className="text-gray-600">Defina e acompanhe seus objetivos</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) setEditingGoal(null); }}>
            <DialogTrigger asChild>
              <Button className="bg-[#3FAE2A] hover:bg-[#359923] gap-2">
                <Plus size={20} /> Nova Meta
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white">
              <DialogHeader><DialogTitle>{editingGoal ? 'Editar Meta' : 'Nova Meta'}</DialogTitle></DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div><Label>Nome da Meta</Label><Input value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Ex: Viagem Férias" required /></div>
                <div><Label>Valor Alvo</Label><Input value={formData.target_amount} onChange={e => setFormData({ ...formData, target_amount: maskCurrency(e.target.value) })} placeholder="R$ 0,00" required /></div>
                <div><Label>Valor Atual (Já guardado)</Label><Input value={formData.current_amount} onChange={e => setFormData({ ...formData, current_amount: maskCurrency(e.target.value) })} placeholder="R$ 0,00" /></div>
                <div><Label>Prazo (Opcional)</Label><Input type="date" value={formData.deadline} onChange={e => setFormData({ ...formData, deadline: e.target.value })} /></div>
                <Button type="submit" className="w-full bg-[#3FAE2A]">Salvar</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal) => {
            const current = Number(goal.current_amount || 0);
            const target = Number(goal.target_amount);
            const percentage = Math.min((current / target) * 100, 100);

            return (
              <div key={goal.id} className="bg-white p-6 rounded-2xl shadow-md border border-gray-100 hover:shadow-lg transition-all">
                <div className="flex justify-between items-start mb-4">
                  <div className="bg-gradient-to-r from-[#3FAE2A] to-[#A4D68D] p-3 rounded-full shadow-sm">
                    <Target className="text-white" size={24} />
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-[#3FAE2A]" onClick={() => handleEdit(goal)}>
                      <Edit size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-red-500" onClick={() => confirmDelete(goal)}>
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>

                <h3 className="font-bold text-lg text-[#4A4A4A] mb-1">{goal.name}</h3>
                {goal.deadline && (
                  <p className="text-xs text-gray-500 mb-4">Prazo: {new Date(goal.deadline).toLocaleDateString('pt-BR')}</p>
                )}

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-bold text-[#3FAE2A]">{formatCurrency(current)}</span>
                    <span className="text-gray-500">de {formatCurrency(target)}</span>
                  </div>
                  <Progress value={percentage} indicatorColor="bg-[#3FAE2A]" className="h-3 rounded-full" />
                  <div className="text-right text-xs font-bold text-[#4A4A4A]">{percentage.toFixed(1)}% concluído</div>
                </div>
              </div>
            );
          })}
          {goals.length === 0 && (
            <div className="col-span-full text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
              <p className="text-gray-500">Nenhuma meta definida.</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal de exclusão */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-500 flex items-center gap-2">
              <Trash2 size={20} /> Excluir Meta
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir <strong>{goalToDelete?.name}</strong>?<br />
              Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleDelete(goalToDelete.id)}
              className="bg-red-600 hover:bg-red-500 w-full sm:w-auto"
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default GoalsPage;
