import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import {
  Home, Car, ShoppingBag, CreditCard, Heart, GraduationCap, Smile, FileText,
  TrendingUp, Briefcase, Utensils, Receipt, Zap, Droplet, Wifi, Stethoscope,
  PawPrint, Music, Film, Wrench, Plane, Banknote, Globe, Gift, BarChart,
  Lightbulb, Monitor, Plus, Edit, Trash2, Search
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';

// IMPORTS DO DIALOG COMPLETOS
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';

import { Label } from '@/components/ui/label';

const ICON_OPTIONS = [
  { icon: Home, name: 'Casa', value: 'home' },
  { icon: Car, name: 'Transporte', value: 'car' },
  { icon: ShoppingBag, name: 'Compras', value: 'shopping' },
  { icon: CreditCard, name: 'Cartão', value: 'card' },
  { icon: Heart, name: 'Saúde', value: 'health' },
  { icon: GraduationCap, name: 'Educação', value: 'education' },
  { icon: Smile, name: 'Lazer', value: 'fun' },
  { icon: FileText, name: 'Impostos', value: 'tax' },
  { icon: TrendingUp, name: 'Investimentos', value: 'investment' },
  { icon: Briefcase, name: 'Salário', value: 'salary' },
  { icon: Utensils, name: 'Alimentação', value: 'food' },
  { icon: Receipt, name: 'Contas', value: 'bills' },
  { icon: Zap, name: 'Energia', value: 'energy' },
  { icon: Droplet, name: 'Água', value: 'water' },
  { icon: Wifi, name: 'Internet', value: 'internet' },
  { icon: Stethoscope, name: 'Consultas', value: 'medical' },
  { icon: PawPrint, name: 'Pets', value: 'pets' },
  { icon: Music, name: 'Música', value: 'music' },
  { icon: Film, name: 'Cinema', value: 'cinema' },
  { icon: Wrench, name: 'Manutenção', value: 'maintenance' },
  { icon: Plane, name: 'Viagem', value: 'travel' },
  { icon: Banknote, name: 'Rendimentos', value: 'income' },
  { icon: Monitor, name: 'Freelance', value: 'freelance' },
  { icon: Globe, name: 'Online', value: 'online' },
  { icon: Gift, name: 'Presentes', value: 'gift' },
  { icon: BarChart, name: 'Dividendos', value: 'dividends' },
  { icon: Lightbulb, name: 'Projetos', value: 'projects' },
];

const CategoriesPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    icon: 'home',
    type: 'expense'
  });

  // Estados do modal de exclusão
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState(null);

  // Função para abrir modal de exclusão
  const confirmDelete = (category) => {
    setCategoryToDelete(category);
    setIsDeleteDialogOpen(true);
  };

  useEffect(() => {
    if (user) {
      loadCategories();
    }
  }, [user]);

  const loadCategories = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Erro ao carregar categorias',
        description: error.message,
      });
    } else {
      setCategories(data || []);
    }
    setLoading(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      icon: 'home',
      type: 'expense',
    });
    setEditingCategory(null);
    setDialogOpen(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const categoryData = {
      ...formData,
      user_id: user.id
    };

    if (editingCategory) {
      const { error } = await supabase
        .from('categories')
        .update(categoryData)
        .eq('id', editingCategory.id);

      if (error) {
        toast({
          variant: 'destructive',
          title: 'Erro ao atualizar categoria',
          description: error.message,
        });
      } else {
        toast({
          title: 'Categoria atualizada!',
          description: 'A categoria foi atualizada com sucesso.',
        });
        resetForm();
        loadCategories();
      }
    } else {
      const { error } = await supabase
        .from('categories')
        .insert([categoryData]);

      if (error) {
        toast({
          variant: 'destructive',
          title: 'Erro ao criar categoria',
          description: error.message,
        });
      } else {
        toast({
          title: 'Categoria criada!',
          description: 'A categoria foi criada com sucesso.',
        });
        resetForm();
        loadCategories();
      }
    }
  };

  const handleDelete = async (id) => {
    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);

      if (error) {
        toast({
          variant: 'destructive',
          title: 'Erro ao excluir categoria',
          description: error.message,
        });
      } else {
        toast({
          title: 'Categoria excluída!',
          description: 'A categoria foi excluída com sucesso.',
        });
        loadCategories();
      }
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Erro inesperado',
        description: error.message,
      });
    } finally {
      setIsDeleteDialogOpen(false);
    }
  };

  const openEditDialog = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      icon: category.icon,
      type: category.type
    });
    setDialogOpen(true);
  };

  const getIcon = (iconValue) => {
    const iconOption = ICON_OPTIONS.find(opt => opt.value === iconValue);
    return iconOption ? iconOption.icon : Home;
  };

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#3FAE2A]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Categorias - Finança Online</title>
        <meta name="description" content="Gerencie suas categorias financeiras" />
      </Helmet>

      <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-6">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Categorias</h1>
            <p className="text-gray-600">Organize seus gastos e receitas</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button
                onClick={resetForm}
                className="bg-[#3FAE2A] hover:bg-[#359923] gap-2 w-full md:w-auto shadow-sm hover:shadow-md transition-all"
              >
                <Plus size={20} />
                Nova Categoria
              </Button>
            </DialogTrigger>

            <DialogContent className="bg-white sm:max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold text-[#4A4A4A] text-center">
                  {editingCategory ? 'Editar Categoria' : 'Nova Categoria'}
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-6 py-4">
                <div>
                  <Label htmlFor="name" className="text-[#4A4A4A] mb-1.5 block">Nome da Categoria</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Ex: Alimentação"
                    required
                    className="h-11"
                  />
                </div>

                <div>
                  <Label className="text-[#4A4A4A] mb-3 block text-center">Tipo de Transação</Label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, type: 'expense' })}
                      className={`p-3 rounded-xl border-2 font-medium transition-all ${
                        formData.type === 'expense'
                          ? 'border-red-500 bg-red-50 text-red-600 shadow-sm'
                          : 'border-gray-100 bg-gray-50 text-gray-500 hover:bg-gray-100'
                      }`}
                    >
                      Despesa
                    </button>

                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, type: 'income' })}
                      className={`p-3 rounded-xl border-2 font-medium transition-all ${
                        formData.type === 'income'
                          ? 'border-[#3FAE2A] bg-[#A4D68D]/20 text-[#3FAE2A] shadow-sm'
                          : 'border-gray-100 bg-gray-50 text-gray-500 hover:bg-gray-100'
                      }`}
                    >
                      Receita
                    </button>
                  </div>
                </div>

                <div>
                  <Label className="text-[#4A4A4A] mb-3 block text-center">Escolha um ícone</Label>
                  <div className="grid grid-cols-5 sm:grid-cols-6 gap-3 sm:gap-4 justify-items-center max-h-[200px] overflow-y-auto p-2 border border-gray-100 rounded-lg">
                    {ICON_OPTIONS.map((option) => {
                      const IconComponent = option.icon;
                      const isSelected = formData.icon === option.value;

                      return (
                        <button
                          key={option.value}
                          type="button"
                          onClick={() => setFormData({ ...formData, icon: option.value })}
                          className={`w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center rounded-xl transition-all duration-200 ${
                            isSelected
                              ? 'bg-[#3FAE2A] text-white shadow-md scale-110 ring-2 ring-offset-2 ring-[#3FAE2A]'
                              : 'bg-gray-50 text-gray-500 hover:bg-gray-100 hover:scale-105 border border-gray-200'
                          }`}
                          title={option.name}
                        >
                          <IconComponent size={20} />
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                    className="flex-1 h-11"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-[#3FAE2A] hover:bg-[#359923] h-11"
                  >
                    {editingCategory ? 'Salvar Alterações' : 'Criar Categoria'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <Input
            placeholder="Buscar categorias..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-white border-gray-200 w-full"
          />
        </div>

        {/* Categories List */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {categories.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="text-gray-400" size={24} />
              </div>
              <p className="text-gray-900 font-medium mb-2">Nenhuma categoria encontrada</p>
              <p className="text-sm text-gray-500">Crie sua primeira categoria para começar.</p>
            </div>
          ) : filteredCategories.length === 0 ? (
            <div className="text-center py-10">
              <p className="text-gray-500">Nenhuma categoria corresponde à sua busca.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredCategories.map((category) => {
                const IconComponent = getIcon(category.icon);
                const isIncome = category.type === 'income';

                return (
                  <div
                    key={category.id}
                    className="group flex items-center justify-between p-4 hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="flex items-center gap-4 overflow-hidden">
                      {/* Icon */}
                      <div
                        className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                          isIncome ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'
                        }`}
                      >
                        <IconComponent size={24} />
                      </div>

                      {/* Info */}
                      <div className="min-w-0">
                        <h3 className="font-semibold text-gray-800 text-base truncate">
                          {category.name}
                        </h3>
                        <div className="flex items-center mt-0.5">
                          <span
                            className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                              isIncome ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                            }`}
                          >
                            {isIncome ? 'Receita' : 'Despesa'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 sm:gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-gray-400 hover:text-[#3FAE2A] hover:bg-green-50 rounded-full"
                        onClick={() => openEditDialog(category)}
                      >
                        <Edit size={16} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full"
                        onClick={() => confirmDelete(category)}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Modal de exclusão */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-500 flex items-center gap-2">
              <Trash2 size={20} /> Excluir Categoria
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir <strong>{categoryToDelete?.name}</strong>?<br />
              Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => handleDelete(categoryToDelete.id)}
              className="bg-red-600 hover:bg-red-500 w-full sm:w-auto"
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default CategoriesPage;
