import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import {
  Plus, Search, Filter, Trash2, Edit, CreditCard,
  Home, Car, ShoppingBag, Heart, GraduationCap, Smile, FileText,
  TrendingUp, Briefcase, Utensils, Receipt, Zap, Droplet, Wifi, Stethoscope,
  PawPrint, Music, Film, Wrench, Plane, Banknote, Globe, Gift, BarChart,
  Lightbulb, Monitor
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription, // Importante: Garanta que este componente exista no seu UI
  DialogFooter
} from '@/components/ui/dialog';

import { Label } from '@/components/ui/label';
import { formatCurrency, maskCurrency, parseCurrency } from '@/utils/currency';

const ICON_OPTIONS = [
  { icon: Home, name: 'Casa', value: 'home' },
  { icon: Car, name: 'Transporte', value: 'car' },
  { icon: ShoppingBag, name: 'Compras', value: 'shopping' },
  { icon: CreditCard, name: 'Cartão', value: 'card' },
  { icon: Heart, name: 'Saúde', value: 'health' },
  { icon: GraduationCap, name: 'Educação', value: 'education' },
  { icon: Smile, name: 'Lazer', value: 'fun' },
  { icon: FileText, name: 'Impostos', value: 'tax' },
  { icon: TrendingUp, name: 'Investimentos', value: 'investment' },
  { icon: Briefcase, name: 'Salário', value: 'salary' },
  { icon: Utensils, name: 'Alimentação', value: 'food' },
  { icon: Receipt, name: 'Contas', value: 'bills' },
  { icon: Zap, name: 'Energia', value: 'energy' },
  { icon: Droplet, name: 'Água', value: 'water' },
  { icon: Wifi, name: 'Internet', value: 'internet' },
  { icon: Stethoscope, name: 'Consultas', value: 'medical' },
  { icon: PawPrint, name: 'Pets', value: 'pets' },
  { icon: Music, name: 'Música', value: 'music' },
  { icon: Film, name: 'Cinema', value: 'cinema' },
  { icon: Wrench, name: 'Manutenção', value: 'maintenance' },
  { icon: Plane, name: 'Viagem', value: 'travel' },
  { icon: Banknote, name: 'Rendimentos', value: 'income' },
  { icon: Monitor, name: 'Freelance', value: 'freelance' },
  { icon: Globe, name: 'Online', value: 'online' },
  { icon: Gift, name: 'Presentes', value: 'gift' },
  { icon: BarChart, name: 'Dividendos', value: 'dividends' },
  { icon: Lightbulb, name: 'Projetos', value: 'projects' },
];

const TransactionsPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingTransaction, setEditingTransaction] = useState(null);

  // --- NOVOS STATES PARA CONTROLE DE PARCELAS ---
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState(null);
  const [deleteScope, setDeleteScope] = useState('single'); // 'single' | 'future'
  const [updateFuture, setUpdateFuture] = useState(false); // Para edição

  const [filters, setFilters] = useState({
    month: new Date().toISOString().slice(0, 7),
    type: 'all',
    category: 'all'
  });

  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    date: new Date().toLocaleDateString('en-CA'), // CORREÇÃO DE DATA (UTC-Safe)
    type: 'expense',
    category_id: null,
    credit_card_id: null,
    is_installment: false,
    total_installments: 1
  });

  useEffect(() => {
    if (user?.id) { // Verifica user.id
      Promise.all([loadTransactions(), loadAuxData()]);
    }
  }, [user?.id, filters]);

  const loadAuxData = async () => {
    const [{ data: cats }, { data: ccds }] = await Promise.all([
      supabase.from('categories').select('*').eq('user_id', user.id).order('name'),
      supabase.from('credit_cards').select('*').eq('user_id', user.id).order('name')
    ]);
    setCategories(cats || []);
    setCards(ccds || []);
  };

  const loadTransactions = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('transactions')
        .select(`
          *,
          categories (name, icon),
          credit_cards (name)
        `)
        .eq('user_id', user.id)
        .order('date', { ascending: false });

      if (filters.month) {
        const start = `${filters.month}-01`;
        // Pega o último dia do mês corretamente
        const end = new Date(filters.month.split('-')[0], filters.month.split('-')[1], 0).toLocaleDateString('en-CA');
        query = query.gte('date', start).lte('date', end);
      }
      if (filters.type !== 'all') {
        query = query.eq('type', filters.type);
      }
      if (filters.category !== 'all') {
        query = query.eq('category_id', filters.category);
      }

      const { data, error } = await query;
      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      toast({ variant: "destructive", title: "Erro", description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const amount = parseCurrency(formData.amount);
      const baseDate = new Date(formData.date + 'T12:00:00'); // Garante meio-dia para evitar bug de fuso na iteração

      // 1. LÓGICA DE ATUALIZAÇÃO (UPDATE)
      if (editingTransaction) {
        const payload = {
          description: formData.description,
          amount: amount,
          date: formData.date,
          type: formData.type,
          category_id: formData.category_id || null,
          credit_card_id: formData.credit_card_id || null,
        };

        let error;

        // Se for parcela e o usuário marcou "Atualizar futuras"
        if (editingTransaction.is_installment && editingTransaction.installment_id && updateFuture) {
          // Atualiza a atual normalmente
          await supabase.from('transactions').update(payload).eq('id', editingTransaction.id);

          // Prepara payload para as futuras (REMOVE a data para não mover todas para o mesmo dia)
          const { date, ...payloadWithoutDate } = payload;

          // Atualiza as futuras (Index > atual)
          const { error: batchError } = await supabase
            .from('transactions')
            .update(payloadWithoutDate)
            .eq('installment_id', editingTransaction.installment_id)
            .gt('installment_index', editingTransaction.installment_index);

          error = batchError;
        } else {
          // Update simples (apenas o registro atual)
          const { error: singleError } = await supabase
            .from('transactions')
            .update(payload)
            .eq('id', editingTransaction.id);
          error = singleError;
        }

        if (error) throw error;
        toast({ title: "Sucesso", description: "Lançamento atualizado!" });

      } else {
        // 2. LÓGICA DE INSERÇÃO (CREATE)
        const newTransactions = [];

        if (formData.is_installment && formData.total_installments > 1 && formData.type === 'expense') {
          const installmentValue = amount / formData.total_installments;

          // --- GERA O ID DO GRUPO DE PARCELAS ---
          const batchId = self.crypto.randomUUID();

          for (let i = 0; i < formData.total_installments; i++) {
            const date = new Date(baseDate);
            date.setMonth(baseDate.getMonth() + i);

            newTransactions.push({
              user_id: user.id,
              description: `${formData.description} (${i + 1}/${formData.total_installments})`,
              amount: installmentValue,
              date: date.toLocaleDateString('en-CA'), // Formato YYYY-MM-DD
              type: 'expense',
              transaction_type: 'fixed',
              category_id: formData.category_id || null,
              credit_card_id: formData.credit_card_id || null,
              is_installment: true,
              installment_index: i + 1,
              total_installments: formData.total_installments,
              installment_id: batchId // <--- SALVANDO O VÍNCULO
            });
          }
        } else {
          // Lançamento Único
          newTransactions.push({
            user_id: user.id,
            description: formData.description,
            amount: amount,
            date: formData.date,
            type: formData.type,
            transaction_type: 'variable',
            category_id: formData.category_id || null,
            credit_card_id: formData.credit_card_id || null,
            is_installment: false,
            installment_index: null,
            total_installments: null,
            installment_id: null
          });
        }

        const { error } = await supabase.from('transactions').insert(newTransactions);
        if (error) throw error;
        toast({ title: "Sucesso", description: "Lançamento(s) criado(s)!" });
      }

      setDialogOpen(false);
      resetForm();
      loadTransactions();
    } catch (error) {
      console.error(error);
      toast({ variant: "destructive", title: "Erro", description: error.message });
    }
  };

  const resetForm = () => {
    setFormData({
      description: '',
      amount: '',
      date: new Date().toLocaleDateString('en-CA'),
      type: 'expense',
      category_id: null,
      credit_card_id: null,
      is_installment: false,
      total_installments: 1
    });
    setEditingTransaction(null);
    setUpdateFuture(false); // Resetar checkbox de edição
  };

  const openEditDialog = (t) => {
    setEditingTransaction(t);
    // Remove o sufixo (1/12) da descrição ao editar para ficar limpo
    const cleanDescription = t.is_installment
      ? t.description.replace(/\s\(\d+\/\d+\)$/, '')
      : t.description;

    setFormData({
      description: cleanDescription,
      amount: formatCurrency(t.amount),
      date: t.date,
      type: t.type,
      category_id: t.category_id,
      credit_card_id: t.credit_card_id,
      is_installment: t.is_installment,
      total_installments: t.total_installments || 1
    });
    setUpdateFuture(false);
    setDialogOpen(true);
  };

  const confirmDelete = (transaction) => {
    setTransactionToDelete(transaction);
    setDeleteScope('single'); // Resetar para padrão
    setIsDeleteDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!transactionToDelete) return;

    try {
      let error;

      // Se for parcela e o usuário escolheu "Futuras"
      if (transactionToDelete.is_installment && transactionToDelete.installment_id && deleteScope === 'future') {
        const { error: batchError } = await supabase
          .from('transactions')
          .delete()
          .eq('installment_id', transactionToDelete.installment_id)
          .gte('installment_index', transactionToDelete.installment_index); // >= index atual
        error = batchError;
      } else {
        // Exclusão Simples
        const { error: singleError } = await supabase
          .from('transactions')
          .delete()
          .eq('id', transactionToDelete.id);
        error = singleError;
      }

      if (error) throw error;

      toast({ title: "Excluído", description: "Registro(s) removido(s)." });
      loadTransactions();
    } catch (error) {
      toast({ variant: "destructive", title: "Erro inesperado", description: error.message });
    } finally {
      setIsDeleteDialogOpen(false);
      setTransactionToDelete(null);
    }
  };

  const getIcon = (iconValue) => {
    const iconOption = ICON_OPTIONS.find(opt => opt.value === iconValue);
    return iconOption ? iconOption.icon : Home;
  };

  const getCategoryIcon = (categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    return getIcon(category?.icon);
  };

  const filteredTransactions = transactions.filter(t =>
    t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.categories?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <Helmet><title>Lançamentos - Finança Online</title></Helmet>
      <div className="p-4 lg:p-8 max-w-7xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Lançamentos</h1>
            <p className="text-gray-600">Gerencie todas as suas transações</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => {
            if (!open) resetForm();
            setDialogOpen(open);
          }}>
            <DialogTrigger asChild>
              <Button className="bg-[#3FAE2A] hover:bg-[#359923] gap-2 shadow-md w-full md:w-auto">
                <Plus size={20} /> Novo Lançamento
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white sm:max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-xl font-bold text-center">
                  {editingTransaction ? 'Editar Lançamento' : 'Novo Lançamento'}
                </DialogTitle>
                {/* ADICIONE ESTA LINHA ABAIXO PARA ACALMAR O ERRO: */}
                <DialogDescription className="hidden">
                  Formulário para gerenciar detalhes do lançamento financeiro.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4 py-4">
                {/* Transaction Type Toggle */}
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, type: 'income', category_id: null })}
                    className={`p-3 rounded-xl border-2 font-bold transition-all ${formData.type === 'income'
                      ? 'border-[#3FAE2A] bg-[#E6F4E8] text-[#3FAE2A]'
                      : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                  >
                    Receita
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, type: 'expense', category_id: null })}
                    className={`p-3 rounded-xl border-2 font-bold transition-all ${formData.type === 'expense'
                      ? 'border-red-500 bg-red-50 text-red-500'
                      : 'border-gray-100 bg-gray-50 text-gray-400'
                      }`}
                  >
                    Despesa
                  </button>
                </div>

                <div>
                  <Label className="mb-1.5 block">Descrição</Label>
                  <Input
                    value={formData.description}
                    onChange={e => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Ex: Supermercado"
                    required
                    className="h-11"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="mb-1.5 block">Valor</Label>
                    <Input
                      value={formData.amount}
                      onChange={e => setFormData({ ...formData, amount: maskCurrency(e.target.value) })}
                      placeholder="R$ 0,00"
                      required
                      className="h-11 font-medium"
                    />
                  </div>
                  <div>
                    <Label className="mb-1.5 block">Data</Label>
                    <Input
                      type="date"
                      value={formData.date}
                      onChange={e => setFormData({ ...formData, date: e.target.value })}
                      required
                      className="h-11"
                    />
                  </div>
                </div>

                <div>
                  <Label className="mb-1.5 block">Categoria</Label>
                  <select
                    className="flex h-11 w-full rounded-2xl border border-gray-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3FAE2A]"
                    value={formData.category_id || ''}
                    onChange={e => setFormData({ ...formData, category_id: e.target.value || null })}
                  >
                    <option value="">Selecione uma categoria...</option>
                    {categories
                      .filter(c => c.type === formData.type)
                      .map((cat) => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                      ))}
                  </select>
                </div>

                <div>
                  <Label className="mb-1.5 block">Conta / Cartão</Label>
                  <select
                    className="flex h-11 w-full rounded-2xl border border-gray-300 bg-white px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3FAE2A]"
                    value={formData.credit_card_id || ''}
                    onChange={e => setFormData({ ...formData, credit_card_id: e.target.value || null })}
                  >
                    <option value="">Dinheiro / Conta Corrente</option>
                    {cards.map(c => <option key={c.id} value={c.id}>Cartão: {c.name}</option>)}
                  </select>
                </div>

                {/* Opções de Parcelamento (Criação) */}
                {formData.type === 'expense' && !editingTransaction && (
                  <div className="bg-gray-50 p-4 rounded-xl space-y-3">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="installment"
                        checked={formData.is_installment}
                        onChange={e => setFormData({ ...formData, is_installment: e.target.checked })}
                        className="w-4 h-4 text-[#3FAE2A] rounded border-gray-300 focus:ring-[#3FAE2A]"
                      />
                      <Label htmlFor="installment" className="mb-0 cursor-pointer">É uma compra parcelada?</Label>
                    </div>

                    {formData.is_installment && (
                      <div className="pl-6">
                        <Label className="mb-1.5 block text-xs">Número de Parcelas</Label>
                        <Input
                          type="number"
                          min="2"
                          max="48"
                          value={formData.total_installments}
                          onChange={e => setFormData({ ...formData, total_installments: parseInt(e.target.value) })}
                          className="h-9"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Opções de Parcelamento (Edição) */}
                {editingTransaction?.is_installment && editingTransaction?.installment_id && (
                  <div className="flex items-center gap-2 py-2 bg-yellow-50 p-3 rounded-lg border border-yellow-100">
                    <input
                      type="checkbox"
                      id="updateFuture"
                      checked={updateFuture}
                      onChange={(e) => setUpdateFuture(e.target.checked)}
                      className="w-4 h-4 text-[#3FAE2A] rounded border-gray-300 focus:ring-[#3FAE2A]"
                    />
                    <Label htmlFor="updateFuture" className="mb-0 cursor-pointer text-sm text-yellow-800">
                      Aplicar alterações para as próximas parcelas?
                    </Label>
                  </div>
                )}

                <Button type="submit" className="w-full bg-[#3FAE2A] hover:bg-[#359923] h-11 text-lg font-bold">
                  {editingTransaction ? 'Salvar Alterações' : 'Adicionar Lançamento'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search Bar & Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative w-full sm:w-1/2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <Input
              placeholder="Buscar lançamentos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white border-gray-200 w-full"
            />
          </div>

          <div className="bg-white p-2 rounded-xl shadow-sm flex flex-col sm:flex-row gap-2 items-center border border-gray-100 w-full sm:w-auto">
            <div className="flex items-center gap-2 text-gray-500 px-2">
              <Filter size={16} />
              <span className="text-sm font-medium hidden sm:inline">Filtrar:</span>
            </div>
            <Input
              type="month"
              value={filters.month}
              onChange={e => setFilters({ ...filters, month: e.target.value })}
              className="w-full sm:w-auto min-w-[150px] h-9"
            />
            <select
              value={filters.type}
              onChange={e => setFilters({ ...filters, type: e.target.value })}
              className="h-9 px-3 rounded-md border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#3FAE2A] w-full sm:w-auto"
            >
              <option value="all">Todos Tipos</option>
              <option value="income">Receitas</option>
              <option value="expense">Despesas</option>
            </select>
          </div>
        </div>

        {/* List View */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          {transactions.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Receipt className="text-gray-400" size={24} />
              </div>
              <p className="text-gray-900 font-medium mb-2">Nenhum lançamento encontrado</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredTransactions.map((t) => {
                const IconComponent = getCategoryIcon(t.category_id);
                const isIncome = t.type === 'income';

                return (
                  <div
                    key={t.id}
                    className="group p-4 hover:bg-gray-50 transition-colors duration-200 flex flex-col sm:flex-row sm:items-center gap-4"
                  >
                    {/* Icon & Date */}
                    <div className="flex items-center gap-4 min-w-[160px]">
                      <div
                        className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center ${isIncome ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'
                          }`}
                      >
                        <IconComponent size={24} />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                          {/* USO DE UTC PARA EXIBIÇÃO CORRETA NA TABELA */}
                          {new Date(t.date).toLocaleDateString('pt-BR', {
                            timeZone: 'UTC',
                            day: '2-digit',
                            month: 'short',
                          })}
                        </span>
                        <span className="text-sm font-medium text-gray-500">
                          {new Date(t.date).getFullYear()}
                        </span>
                      </div>
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base font-semibold text-gray-800 truncate">
                        {t.description}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="inline-flex items-center gap-1 text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                          {t.categories?.name || 'Sem categoria'}
                        </span>
                        {t.credit_cards && (
                          <span className="inline-flex items-center gap-1 text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                            <CreditCard size={10} /> {t.credit_cards.name}
                          </span>
                        )}
                        {t.is_installment && (
                          <span className="inline-flex items-center gap-1 text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                            {t.installment_index}/{t.total_installments}
                          </span>
                        )}
                      </div>
                    </div>
                    {/* Amount & Actions */}
                    <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto mt-2 sm:mt-0">
                      <span
                        className={`text-base font-bold whitespace-nowrap ${isIncome ? 'text-[#3FAE2A]' : 'text-red-500'
                          }`}
                      >
                        {isIncome ? '+' : '-'} {formatCurrency(t.amount)}
                      </span>

                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-[#3FAE2A]"
                          onClick={() => openEditDialog(t)}
                        >
                          <Edit size={16} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-gray-400 hover:text-red-500"
                          onClick={() => confirmDelete(t)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Modal de Exclusão */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-500 flex items-center gap-2">
              <Trash2 size={20} /> Excluir Lançamento
            </DialogTitle>
            <DialogDescription className="text-left pt-2">
              <div>
                Tem certeza que deseja excluir <strong>{transactionToDelete?.description}</strong>?
              </div>

              {/* Opções de exclusão de parcelamento */}
              {transactionToDelete?.is_installment && transactionToDelete?.installment_id && (
                <div className="mt-4 flex flex-col gap-3 p-4 bg-red-50 rounded-xl border border-red-100">
                  <span className="text-red-800 font-bold text-xs uppercase tracking-wide">Opções de Parcelamento</span>

                  <label className="flex items-center gap-3 cursor-pointer p-1 hover:bg-red-100/50 rounded transition-colors">
                    <div className="relative flex items-center">
                      <input
                        type="radio"
                        name="delScope"
                        checked={deleteScope === 'single'}
                        onChange={() => setDeleteScope('single')}
                        className="peer h-4 w-4 border-gray-300 text-red-600 focus:ring-red-500"
                      />
                    </div>
                    <span className="text-gray-700 text-sm font-medium">Excluir apenas esta parcela</span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer p-1 hover:bg-red-100/50 rounded transition-colors">
                    <div className="relative flex items-center">
                      <input
                        type="radio"
                        name="delScope"
                        checked={deleteScope === 'future'}
                        onChange={() => setDeleteScope('future')}
                        className="peer h-4 w-4 border-gray-300 text-red-600 focus:ring-red-500"
                      />
                    </div>
                    <span className="text-gray-700 text-sm font-medium">Excluir esta e as futuras</span>
                  </label>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row mt-2">
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-500 w-full sm:w-auto"
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default TransactionsPage;