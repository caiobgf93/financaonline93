import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { 
  BarChart3, 
  Calendar, 
  ArrowUp, 
  ArrowDown, 
  PieChart as PieChartIcon, 
  Loader2, 
  TrendingUp, 
  Wallet,
  CreditCard,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { formatCurrency } from '@/utils/currency';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LabelList,
  ComposedChart, Line, Area
} from 'recharts';

// --- Configuration & Constants ---

const COLORS = [
  '#0ea5e9', // Blue
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#ec4899', // Pink
  '#10b981', // Emerald
  '#f43f5e', // Rose
  '#6366f1', // Indigo
  '#84cc16', // Lime
  '#d946ef', // Fuchsia
  '#06b6d4', // Cyan
  '#f97316', // Orange
  '#14b8a6', // Teal
];

const MONTH_NAMES = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

// --- Sub-Components for Charts ---

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-100 shadow-xl rounded-xl z-50 min-w-[150px]">
        {label && <p className="text-sm font-bold text-gray-800 mb-2 border-b border-gray-100 pb-1">{label}</p>}
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center gap-2 mb-1 last:mb-0">
            <div 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: entry.color || entry.fill }}
            />
            {/* Conditional rendering for name - hide "value" */}
            {entry.name !== 'value' && (
                <span className="text-xs text-gray-500 capitalize flex-1">
                {entry.name}:
                </span>
            )}
            <span className="text-xs font-bold text-gray-700">
              {formatCurrency(entry.value)}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const ReportsPage = () => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') || 'monthly';

  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [loading, setLoading] = useState(false);

  // Data States
  const [monthlyData, setMonthlyData] = useState([]);
  const [dailyData, setDailyData] = useState([]);
  const [rankingData, setRankingData] = useState({
    income: { top5: [], others: 0, total: 0 },
    expense: { top5: [], others: 0, total: 0 }
  });
  const [analysisData, setAnalysisData] = useState({
    incomeByCategory: [],
    expenseByCategory: [],
    expenseByCard: []
  });
  const [billsData, setBillsData] = useState({
    summary: { total: 0, paid: 0, pending: 0, overdue: 0 },
    statusBreakdown: [],
    history: []
  });

  // --- Handlers ---

  const handleTabChange = (tab) => {
    setSearchParams({ tab });
  };

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, activeTab, year, month]);

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'monthly') await loadMonthlyData();
      if (activeTab === 'daily') await loadDailyData();
      if (activeTab === 'ranking') await loadRankingData();
      if (activeTab === 'analysis') await loadAnalysisData();
      if (activeTab === 'bills') await loadBillsReportData();
    } catch (error) {
      console.error("Error loading report data:", error);
    } finally {
      setLoading(false);
    }
  };

  // --- Data Loaders ---

  const loadMonthlyData = async () => {
    const { data } = await supabase
      .from('transactions')
      .select('amount, date, type')
      .eq('user_id', user.id)
      .gte('date', `${year}-01-01`)
      .lte('date', `${year}-12-31`);

    let cumulative = 0;
    const months = Array.from({ length: 12 }, (_, i) => {
      const mData = (data || []).filter(d => new Date(d.date).getMonth() === i);
      const inc = mData.filter(d => d.type === 'income').reduce((s, c) => s + Number(c.amount), 0);
      const exp = mData.filter(d => d.type === 'expense').reduce((s, c) => s + Number(c.amount), 0);
      const balance = inc - exp;
      cumulative += balance;

      return {
        name: MONTH_NAMES[i].substring(0, 3),
        fullName: MONTH_NAMES[i],
        Receitas: inc,
        Despesas: exp,
        Saldo: balance,
        Acumulado: cumulative
      };
    });

    setMonthlyData(months);
  };

  const loadDailyData = async () => {
    const startDate = new Date(year, month - 1, 1).toISOString().slice(0, 10);
    const endDate = new Date(year, month, 0).toISOString().slice(0, 10);

    const { data } = await supabase
      .from('transactions')
      .select('amount, date, type')
      .eq('user_id', user.id)
      .gte('date', startDate)
      .lte('date', endDate);

    const daysInMonth = new Date(year, month, 0).getDate();
    const days = Array.from({ length: daysInMonth }, (_, i) => {
      const dayStr = String(i + 1).padStart(2, '0');
      const dayData = (data || []).filter(d => d.date.endsWith(dayStr));
      return {
        day: i + 1,
        income: dayData.filter(d => d.type === 'income').reduce((s, c) => s + Number(c.amount), 0),
        expense: dayData.filter(d => d.type === 'expense').reduce((s, c) => s + Number(c.amount), 0)
      };
    });

    setDailyData(days);
  };

  const loadRankingData = async () => {
    const startDate = new Date(year, month - 1, 1).toISOString().slice(0, 10);
    const endDate = new Date(year, month, 0).toISOString().slice(0, 10);

    const { data: transactions } = await supabase
      .from('transactions')
      .select('description, amount, type')
      .eq('user_id', user.id)
      .gte('date', startDate)
      .lte('date', endDate)
      .order('amount', { ascending: false });

    const income = (transactions || []).filter(t => t.type === 'income');
    const expense = (transactions || []).filter(t => t.type === 'expense');

    const processRanking = (list) => {
      const top5 = list.slice(0, 5);
      const others = list.slice(5).reduce((s, c) => s + Number(c.amount), 0);
      return { top5, others, total: list.reduce((s, c) => s + Number(c.amount), 0) };
    };

    setRankingData({
      income: processRanking(income),
      expense: processRanking(expense)
    });
  };

  const loadAnalysisData = async () => {
    const startDate = new Date(year, month - 1, 1).toISOString().slice(0, 10);
    const endDate = new Date(year, month, 0).toISOString().slice(0, 10);

    const { data: transactions } = await supabase
      .from('transactions')
      .select(`
        amount,
        type,
        category:categories ( name ),
        credit_card:credit_cards ( name, color )
      `)
      .eq('user_id', user.id)
      .gte('date', startDate)
      .lte('date', endDate);

    if (!transactions) {
      setAnalysisData({ incomeByCategory: [], expenseByCategory: [], expenseByCard: [] });
      return;
    }

    // Process Categories
    const processCategories = (type) => {
      const map = {};
      transactions
        .filter(t => t.type === type)
        .forEach(t => {
          const name = t.category?.name || 'Sem Categoria';
          map[name] = (map[name] || 0) + Number(t.amount);
        });
      
      return Object.keys(map)
        .map(name => ({ name, value: map[name] }))
        .sort((a, b) => b.value - a.value);
    };

    // Process Cards (Only expenses usually)
    const cardMap = {};
    const cardColorMap = {};

    transactions
      .filter(t => t.type === 'expense' && t.credit_card?.name)
      .forEach(t => {
        const name = t.credit_card.name;
        cardMap[name] = (cardMap[name] || 0) + Number(t.amount);
        // Store the color if available
        if (t.credit_card.color) {
            cardColorMap[name] = t.credit_card.color;
        }
      });
    
    const byCard = Object.keys(cardMap)
      .map((name, index) => ({ 
          name, 
          value: cardMap[name],
          // Use stored color or fallback to default palette
          color: cardColorMap[name] || COLORS[index % COLORS.length]
      }))
      .sort((a, b) => b.value - a.value);

    setAnalysisData({
      incomeByCategory: processCategories('income'),
      expenseByCategory: processCategories('expense'),
      expenseByCard: byCard
    });
  };

  const loadBillsReportData = async () => {
    // Load all bills for the selected year
    const { data: bills } = await supabase
      .from('bills')
      .select('*')
      .eq('user_id', user.id)
      .gte('due_date', `${year}-01-01`)
      .lte('due_date', `${year}-12-31`);

    if (!bills) return;

    const today = new Date().toISOString().split('T')[0];

    // Filter bills for the specific month selected
    const monthlyBills = bills.filter(b => {
      // due_date is YYYY-MM-DD
      const m = parseInt(b.due_date.split('-')[1], 10);
      return m === month;
    });

    // Summary (Calculated from MONTHLY bills)
    let total = 0, paid = 0, pending = 0, overdue = 0;
    
    monthlyBills.forEach(bill => {
      total += Number(bill.amount);
      if (bill.status === 'paid') {
        paid += Number(bill.amount);
      } else {
        pending += Number(bill.amount);
        if (bill.due_date < today) overdue += Number(bill.amount);
      }
    });

    // Breakdown for Pie Chart (Calculated from MONTHLY bills)
    const statusBreakdown = [
      { name: 'Pagas', value: paid },
      { name: 'Pendentes', value: pending - overdue }, // Purely pending, not overdue
      { name: 'Atrasadas', value: overdue }
    ].filter(i => i.value > 0);

    // History (Calculated from YEARLY bills to show context)
    const historyMap = {};
    bills.forEach(bill => {
      const mIndex = parseInt(bill.due_date.split('-')[1], 10) - 1;
      const mName = MONTH_NAMES[mIndex].substring(0, 3);
      if (!historyMap[mIndex]) historyMap[mIndex] = { name: mName, total: 0, paid: 0 };
      
      historyMap[mIndex].total += Number(bill.amount);
      if (bill.status === 'paid') historyMap[mIndex].paid += Number(bill.amount);
    });

    const history = Object.values(historyMap).sort((a,b) => MONTH_NAMES.indexOf(a.name) - MONTH_NAMES.indexOf(b.name));

    setBillsData({
      summary: { total, paid, pending, overdue },
      statusBreakdown,
      history
    });
  };

  // --- Render ---

  return (
    <>
      <Helmet><title>Relatórios Avançados - Finança Online</title></Helmet>

      <div className="p-4 lg:p-8 max-w-7xl mx-auto pb-24">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-6">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Relatórios</h1>
            <p className="text-gray-500 text-sm mt-1">Análise detalhada da sua saúde financeira.</p>
          </div>

          <div className="flex flex-wrap gap-2 bg-white p-1.5 rounded-xl border border-gray-200 shadow-sm w-full lg:w-auto overflow-x-auto">
            {[
              { id: 'monthly', label: 'Visão Mensal', icon: BarChart3 },
              { id: 'analysis', label: 'Análise', icon: PieChartIcon },
              { id: 'daily', label: 'Diário', icon: Calendar },
              { id: 'ranking', label: 'Rankings', icon: TrendingUp },
              { id: 'bills', label: 'Contas', icon: FileText }
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => handleTabChange(t.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 whitespace-nowrap ${
                  activeTab === t.id
                  ? 'bg-[#3FAE2A] text-white shadow-md transform scale-[1.02]'
                  : 'text-gray-500 hover:text-[#3FAE2A] hover:bg-green-50'
                }`}
              >
                <t.icon size={16} />
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 mb-6 flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2 text-gray-500">
            <Calendar size={20} className="text-[#3FAE2A]" />
            <span className="text-sm font-medium">Filtros:</span>
          </div>

          <select
            value={year}
            onChange={e => setYear(Number(e.target.value))}
            className="p-2 pr-8 border-gray-200 bg-gray-50 rounded-xl text-sm font-medium focus:ring-2 focus:ring-[#3FAE2A] focus:border-transparent outline-none cursor-pointer hover:bg-gray-100 transition-colors"
          >
            {[2023, 2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>

          {(activeTab !== 'monthly') && (
            <select
              value={month}
              onChange={e => setMonth(Number(e.target.value))}
              className="p-2 pr-8 border-gray-200 bg-gray-50 rounded-xl text-sm font-medium focus:ring-2 focus:ring-[#3FAE2A] focus:border-transparent outline-none cursor-pointer hover:bg-gray-100 transition-colors"
            >
              {MONTH_NAMES.map((m, i) => (
                <option key={i + 1} value={i + 1}>{m}</option>
              ))}
            </select>
          )}
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex items-center justify-center h-64 bg-white rounded-2xl border border-gray-100">
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="w-8 h-8 animate-spin text-[#3FAE2A]" />
              <span className="text-gray-500 text-sm">Atualizando gráficos...</span>
            </div>
          </div>
        )}

        {!loading && (
          <div className="space-y-6">
            
            {/* --- MONTHLY TAB --- */}
            {activeTab === 'monthly' && (
              <div className="grid grid-cols-1 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* Chart 1: Income vs Expense */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="text-lg font-bold text-[#4A4A4A] mb-6 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-[#3FAE2A]" />
                    Receitas vs Despesas ({year})
                  </h3>
                  <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                        <YAxis 
                          tickFormatter={(val) => `R$ ${val/1000}k`} 
                          tick={{ fontSize: 12, fill: '#9ca3af' }} 
                          axisLine={false} 
                          tickLine={false} 
                        />
                        <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f9fafb' }} />
                        <Legend iconType="circle" />
                        <Bar name="Receitas" dataKey="Receitas" fill="#22c55e" radius={[4, 4, 0, 0]} maxBarSize={50} />
                        <Bar name="Despesas" dataKey="Despesas" fill="#ef4444" radius={[4, 4, 0, 0]} maxBarSize={50} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Chart 2: Balance Evolution */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="text-lg font-bold text-[#4A4A4A] mb-6 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-blue-500" />
                    Evolução Financeira
                  </h3>
                  <div className="h-[350px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={monthlyData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                        <YAxis 
                          yAxisId="left"
                          tickFormatter={(val) => `R$ ${val/1000}k`} 
                          tick={{ fontSize: 12, fill: '#9ca3af' }} 
                          axisLine={false} 
                          tickLine={false}
                        />
                        <YAxis 
                          yAxisId="right"
                          orientation="right"
                          tickFormatter={(val) => `R$ ${val/1000}k`} 
                          tick={{ fontSize: 12, fill: '#9ca3af' }} 
                          axisLine={false} 
                          tickLine={false} 
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend />
                        <Area 
                          yAxisId="right"
                          type="monotone" 
                          dataKey="Acumulado" 
                          name="Saldo Acumulado" 
                          fill="#eff6ff" 
                          stroke="#3b82f6" 
                          strokeWidth={3}
                        />
                        <Bar 
                          yAxisId="left" 
                          dataKey="Saldo" 
                          name="Saldo Mensal" 
                          fill="#cbd5e1" 
                          radius={[4, 4, 0, 0]} 
                          maxBarSize={40} 
                        />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {/* --- ANALYSIS TAB --- */}
            {activeTab === 'analysis' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                
                {/* Pie Charts Container */}
                <div className="grid lg:grid-cols-2 gap-6">
                  
                  {/* Income Pie */}
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col h-[450px]">
                    <h3 className="text-lg font-bold text-[#4A4A4A] mb-2 flex items-center gap-2">
                      <ArrowUp className="w-5 h-5 text-green-500" />
                      Origem das Receitas
                    </h3>
                    <div className="flex-1 min-h-0 relative">
                      {analysisData.incomeByCategory.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={analysisData.incomeByCategory}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              paddingAngle={2}
                              dataKey="value"
                            >
                              {analysisData.incomeByCategory.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                              ))}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                            <Legend 
                              layout="vertical" 
                              verticalAlign="middle" 
                              align="right"
                              wrapperStyle={{ fontSize: '12px', right: 0 }} 
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
                          <PieChartIcon className="w-12 h-12 opacity-20 mb-2" />
                          <p className="text-sm">Sem dados de receita</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Expense Pie */}
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col h-[450px]">
                    <h3 className="text-lg font-bold text-[#4A4A4A] mb-2 flex items-center gap-2">
                      <ArrowDown className="w-5 h-5 text-red-500" />
                      Distribuição de Despesas
                    </h3>
                    <div className="flex-1 min-h-0 relative">
                      {analysisData.expenseByCategory.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={analysisData.expenseByCategory}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              paddingAngle={2}
                              dataKey="value"
                            >
                              {analysisData.expenseByCategory.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[(index + 2) % COLORS.length]} stroke="none" />
                              ))}
                            </Pie>
                            <Tooltip content={<CustomTooltip />} />
                            <Legend 
                              layout="vertical" 
                              verticalAlign="middle" 
                              align="right"
                              wrapperStyle={{ fontSize: '12px', right: 0 }} 
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
                          <PieChartIcon className="w-12 h-12 opacity-20 mb-2" />
                          <p className="text-sm">Sem dados de despesa</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Credit Card Bar Chart */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <h3 className="text-lg font-bold text-[#4A4A4A] mb-6 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-purple-500" />
                    Gastos por Cartão
                  </h3>
                  <div className="h-[300px] w-full">
                    {analysisData.expenseByCard.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={analysisData.expenseByCard}
                          layout="vertical"
                          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                          <XAxis type="number" hide />
                          <YAxis
                            dataKey="name"
                            type="category"
                            width={100}
                            tick={{ fontSize: 13, fill: '#374151', fontWeight: 500 }}
                            axisLine={false}
                            tickLine={false}
                          />
                          <Tooltip content={<CustomTooltip />} cursor={{fill: '#f9fafb'}} />
                          <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={32}>
                            {analysisData.expenseByCard.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                            ))}
                            <LabelList
                              dataKey="value"
                              position="top"
                              formatter={(val) => formatCurrency(val)}
                              style={{ fontSize: '12px', fill: '#4A4A4A', fontWeight: 600 }}
                            />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center text-gray-400 border-2 border-dashed border-gray-100 rounded-xl">
                        <CreditCard className="w-12 h-12 opacity-20 mb-2" />
                        <p className="text-sm">Nenhum gasto com cartão neste período</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* --- DAILY TAB --- */}
            {activeTab === 'daily' && (
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <h3 className="text-lg font-bold text-[#4A4A4A] mb-6 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-[#3FAE2A]" />
                  Visão Diária ({month}/{year})
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
                  {dailyData.map(d => {
                     const hasActivity = d.income > 0 || d.expense > 0;
                     return (
                      <div 
                        key={d.day} 
                        className={`
                          p-3 rounded-xl min-h-[90px] flex flex-col justify-between border transition-all duration-200
                          ${hasActivity ? 'bg-white border-gray-200 shadow-sm hover:shadow-md hover:-translate-y-1' : 'bg-gray-50/50 border-transparent text-gray-300'}
                        `}
                      >
                        <span className={`text-xs font-bold ${hasActivity ? 'text-gray-600' : 'text-gray-300'}`}>{d.day}</span>
                        <div className="text-right space-y-0.5">
                          {d.income > 0 && <p className="text-xs text-green-600 font-bold">+{Math.round(d.income)}</p>}
                          {d.expense > 0 && <p className="text-xs text-red-500 font-bold">-{Math.round(d.expense)}</p>}
                          {!hasActivity && <p className="text-xs text-gray-300">-</p>}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* --- RANKING TAB --- */}
            {activeTab === 'ranking' && (
              <div className="grid md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* Income Ranking */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <div className="flex items-center gap-2 mb-6 pb-4 border-b border-gray-100">
                    <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                      <ArrowUp className="text-green-600 w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">Top Entradas</h3>
                      <p className="text-xs text-gray-500">Maiores receitas do mês</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {rankingData.income.top5.length > 0 ? rankingData.income.top5.map((item, i) => (
                      <div key={i} className="flex justify-between items-center text-sm p-3 rounded-xl bg-gray-50 hover:bg-green-50 transition-colors group">
                        <div className="flex items-center gap-3 overflow-hidden">
                          <span className="text-xs font-bold text-gray-400 w-4 group-hover:text-green-600">{i + 1}</span>
                          <span className="text-gray-700 truncate font-medium">{item.description}</span>
                        </div>
                        <span className="font-bold text-green-600 whitespace-nowrap">{formatCurrency(item.amount)}</span>
                      </div>
                    )) : <p className="text-sm text-gray-400 text-center py-8 italic">Nenhuma entrada registrada.</p>}
                  </div>
                </div>

                {/* Expense Ranking */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                  <div className="flex items-center gap-2 mb-6 pb-4 border-b border-gray-100">
                    <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center">
                      <ArrowDown className="text-red-600 w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-800">Top Saídas</h3>
                      <p className="text-xs text-gray-500">Maiores despesas do mês</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    {rankingData.expense.top5.length > 0 ? rankingData.expense.top5.map((item, i) => (
                      <div key={i} className="flex justify-between items-center text-sm p-3 rounded-xl bg-gray-50 hover:bg-red-50 transition-colors group">
                        <div className="flex items-center gap-3 overflow-hidden">
                          <span className="text-xs font-bold text-gray-400 w-4 group-hover:text-red-500">{i + 1}</span>
                          <span className="text-gray-700 truncate font-medium">{item.description}</span>
                        </div>
                        <span className="font-bold text-red-500 whitespace-nowrap">{formatCurrency(item.amount)}</span>
                      </div>
                    )) : <p className="text-sm text-gray-400 text-center py-8 italic">Nenhuma saída registrada.</p>}
                  </div>
                </div>
              </div>
            )}

            {/* --- BILLS TAB --- */}
            {activeTab === 'bills' && (
              <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* KPIs Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                    <p className="text-xs text-gray-500 mb-1">Total em Contas ({MONTH_NAMES[month-1]})</p>
                    <p className="text-xl font-bold text-gray-800">{formatCurrency(billsData.summary.total)}</p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                     <div className="flex items-center gap-1.5 mb-1">
                        <CheckCircle2 size={12} className="text-green-500"/>
                        <p className="text-xs text-gray-500">Pago</p>
                     </div>
                    <p className="text-xl font-bold text-green-600">{formatCurrency(billsData.summary.paid)}</p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                     <div className="flex items-center gap-1.5 mb-1">
                        <Clock size={12} className="text-orange-500"/>
                        <p className="text-xs text-gray-500">Pendente</p>
                     </div>
                    <p className="text-xl font-bold text-orange-500">{formatCurrency(billsData.summary.pending)}</p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm">
                     <div className="flex items-center gap-1.5 mb-1">
                        <AlertTriangle size={12} className="text-red-500"/>
                        <p className="text-xs text-gray-500">Vencido</p>
                     </div>
                    <p className="text-xl font-bold text-red-500">{formatCurrency(billsData.summary.overdue)}</p>
                  </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-6">
                   {/* Status Breakdown Pie */}
                   <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col h-[400px]">
                      <h3 className="text-lg font-bold text-[#4A4A4A] mb-2 flex items-center gap-2">
                         <PieChartIcon className="w-5 h-5 text-indigo-500" />
                         Status das Contas ({MONTH_NAMES[month-1]})
                      </h3>
                      <div className="flex-1 min-h-0 relative">
                         {billsData.statusBreakdown.length > 0 ? (
                           <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                 <Pie
                                    data={billsData.statusBreakdown}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={60}
                                    outerRadius={100}
                                    paddingAngle={2}
                                    dataKey="value"
                                 >
                                    {billsData.statusBreakdown.map((entry, index) => {
                                       let color = '#94a3b8';
                                       if(entry.name === 'Pagas') color = '#22c55e';
                                       if(entry.name === 'Pendentes') color = '#f97316';
                                       if(entry.name === 'Atrasadas') color = '#ef4444';
                                       return <Cell key={`cell-${index}`} fill={color} stroke="none" />
                                    })}
                                 </Pie>
                                 <Tooltip content={<CustomTooltip />} />
                                 <Legend verticalAlign="bottom" height={36} />
                              </PieChart>
                           </ResponsiveContainer>
                         ) : (
                           <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
                             <p className="text-sm">Sem dados de contas para este mês</p>
                           </div>
                         )}
                      </div>
                   </div>

                   {/* History Bar Chart */}
                   <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col h-[400px]">
                      <h3 className="text-lg font-bold text-[#4A4A4A] mb-2 flex items-center gap-2">
                         <Calendar className="w-5 h-5 text-blue-500" />
                         Histórico Anual de Pagamentos
                      </h3>
                      <div className="flex-1 min-h-0 relative">
                         {billsData.history.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                               <BarChart data={billsData.history} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                  <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                                  <YAxis 
                                    tickFormatter={(val) => `R$${val/1000}k`} 
                                    tick={{ fontSize: 12, fill: '#9ca3af' }} 
                                    axisLine={false} 
                                    tickLine={false} 
                                  />
                                  <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f9fafb' }} />
                                  <Legend />
                                  <Bar name="Total Previsto" dataKey="total" fill="#e2e8f0" radius={[4, 4, 0, 0]} />
                                  <Bar name="Pago" dataKey="paid" fill="#22c55e" radius={[4, 4, 0, 0]} />
                               </BarChart>
                            </ResponsiveContainer>
                         ) : (
                           <div className="absolute inset-0 flex flex-col items-center justify-center text-gray-400">
                             <p className="text-sm">Sem histórico disponível</p>
                           </div>
                         )}
                      </div>
                   </div>
                </div>
              </div>
            )}

          </div>
        )}
      </div>
    </>
  );
};

export default ReportsPage;