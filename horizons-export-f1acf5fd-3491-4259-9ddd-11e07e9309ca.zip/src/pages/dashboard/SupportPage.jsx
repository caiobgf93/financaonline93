import React, { useState, useRef, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Search, 
  MessageCircle, 
  HelpCircle, 
  ChevronRight, 
  Send, 
  User, 
  CreditCard, 
  FileText, 
  Settings,
  LayoutDashboard,
  Wallet,
  Receipt,
  X,
  Phone
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from '@/components/ui/accordion';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const FAQ_CATEGORIES = [
  { id: 'start', label: 'Primeiros Passos', icon: <HelpCircle className="w-5 h-5" /> },
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: 'transactions', label: 'Lançamentos', icon: <Wallet className="w-5 h-5" /> },
  { id: 'bills', label: 'Contas a Pagar', icon: <Receipt className="w-5 h-5" /> },
  { id: 'reports', label: 'Relatórios', icon: <FileText className="w-5 h-5" /> },
  { id: 'subscription', label: 'Planos', icon: <CreditCard className="w-5 h-5" /> },
  { id: 'account', label: 'Minha Conta', icon: <User className="w-5 h-5" /> },
];

const FAQS = [
  {
    category: 'start',
    question: "Como começo a organizar minhas finanças?",
    answer: "Dentro da Finança Online, o primeiro passo é criar categorias de despesas e receitas, garantindo que cada lançamento fique organizado e que você consiga identificar com facilidade onde está gastando ou recebendo mais. Em seguida, registre todos os seus lançamentos, pois eles formam a base de todo o controle financeiro. Por fim, cadastre suas metas financeiras e cartões, para acompanhar objetivos e gerenciar pagamentos de forma completa."
  },
  {
    category: 'start',
    question: "O aplicativo é seguro?",
    answer: "Sim. O Finança Online foi desenvolvido com foco em proteção de dados e segurança. Todas as informações são transmitidas de forma criptografada e os pagamentos são processados pelo Stripe, uma das plataformas mais confiáveis do mercado. Além disso, o sistema utiliza protocolos de segurança para garantir que seus dados pessoais e financeiros estejam sempre protegidos."
  },
  {
    category: 'dashboard',
    question: "O que significam os gráficos na tela inicial?",
    answer: "Os gráficos do Finança Online mostram um resumo visual das suas movimentações financeiras, organizando os lançamentos por categorias de despesas e receitas, exibindo a evolução dos cartões e contas e destacando o progresso das metas financeiras."
  },
  {
    category: 'transactions',
    question: "Como adiciono uma nova categoria?",
    answer: "Para criar uma nova categoria no Finança Online, acesse o menu Categorias e clique em Nova Categoria. Informe o nome desejado (ex.: “Alimentação”, “Transporte”), defina se será de despesa ou receita, escolha um ícone representativo e finalize em Criar Categoria. A partir desse momento, ela estará disponível para uso nos seus lançamentos, ajudando a organizar cada despesa ou receita de forma clara e personalizada. Atenção: antes de excluir uma categoria, lembre-se de que ela é a base da organização do sistema. A exclusão pode impactar diretamente orçamentos, lançamentos e relatórios vinculados a essa categoria."
  },
  {
    category: 'transactions',
    question: "Como adiciono um novo lançamento?",
    answer: "Para adicionar uma nova despesa no Finança Online, vá até a área de lançamentos e escolha a opção de criar um novo lançamento. Em seguida, informe a descrição, o valor e selecione a categoria correspondente e associe a despesa ao cartão ou conta desejada. Depois, salve o lançamento. O sistema permite também o cadastro de lançamentos parcelados. Nesse caso, insira o valor total da compra e ele registra as transações subsequentes automaticamente. Esse processo garante que a despesa fique organizada dentro das categorias e vinculada corretamente ao meio de pagamento, permitindo que os relatórios e gráficos mostrem sua movimentação de forma precisa."
  },
  {
    category: 'transactions',
    question: "Como adiciono um novo orçamento?",
    answer: "No Finança Online, para adicionar um novo orçamento basta acessar o menu Orçamentos e clicar em Novo Orçamento. Em seguida, escolha a categoria de despesa que deseja controlar, defina o valor limite e selecione a recorrência desejada (apenas este mês, trimestre, semestre ou ano). Depois de salvar, o orçamento ficará disponível na sua lista. O sentido do orçamento é permitir que você planeje e acompanhe seus gastos mensais de forma organizada. Cada lançamento registrado na categoria escolhida será automaticamente contabilizado, mostrando quanto já foi gasto e quanto ainda resta dentro do limite definido."
  },
  {
    category: 'bills',
    question: "Como funcionam as Contas a Pagar?",
    answer: "No Finança Online, as Contas a Pagar servem para organizar e acompanhar todas as despesas futuras que você precisa quitar. Ao selecionar Nova Conta, você informa a descrição, o valor da conta, a data de vencimento e a categoria. O sistema então registra esse compromisso e exibe nos relatórios e gráficos, permitindo que você visualize o impacto dessas despesas no seu orçamento. Conforme a data de vencimento se aproxima, você tem um controle claro do que precisa ser pago, evitando atrasos e mantendo suas finanças sempre em ordem. Além disso, o sistema enviar um alerta no dia do vencimento."
  },
  {
    category: 'bills',
    question: "O que acontece quando marco uma conta como paga?",
    answer: "Ao marcar como paga, o sistema automaticamente cria um lançamento com o valor da conta e com a categoria cadastrada."
  },
  {
    category: 'transactions',
    question: "Como funcionam os Cartões?",
    answer: "No Finança Online, os Cartões permitem centralizar o controle de todas as movimentações feitas. Para cadastrar um cartão, basta selecionar Novo Cartão e preencher os campos com o nome do cartão, o banco ao qual ele pertence, o limite de crédito e a data de vencimento. A partir daí, o sistema organiza automaticamente os lançamentos por categoria e relaciona cada gasto ao cartão correspondente, facilitando a análise dos relatórios e gráficos. Dessa forma, você tem uma visão clara de quanto está sendo utilizado em cada cartão e consegue planejar melhor seus pagamentos e limites."
  },
  {
    category: 'subscription',
    question: "Como funcionam as metas financeiras?",
    answer: "No Finança Online, as metas financeiras permitem que você defina objetivos claros para o seu dinheiro, como juntar um valor específico ou reduzir gastos em determinada categoria. Para criar uma meta, basta acessar a área de Metas, selecionar Nova Meta e preencher o nome da meta, o valor alvo, o valor atual e o prazo. A cada montante separado, é necessário atualizar o valor atual dentro da meta, registrando o que já foi guardado. O sistema acompanha automaticamente seus lançamentos e mostra o progresso em gráficos, indicando quanto já foi atingido e o que ainda falta. Assim, você consegue visualizar de forma prática se está no caminho certo para realizar seus planos."
  },
  {
    category: 'subscription',
    question: "Quais os pagamentos aceitos?",
    answer: "No Finança Online, os pagamentos são aceitos somente por cartões de crédito. Essa forma de cobrança garante praticidade e segurança no processamento das assinaturas."
  },
  {
    category: 'subscription',
    question: "Como cancelo minha assinatura?",
    answer: "Você pode cancelar a renovação automática a qualquer momento nas configurações do seu perfil, na página 'Meus Planos'."
  },
  {
    category: 'account',
    question: "Como altero minha senha?",
    answer: "Acesse as configurações do perfil clicando no seu avatar no menu lateral. Lá você encontrará a opção de segurança para alterar sua senha."
  }
];

const CHAT_OPTIONS = [
  { id: 'login', label: 'Problemas de Login', response: 'Se você está com problemas para acessar sua conta, tente redefinir sua senha na tela de login. Se o problema persistir, verifique se seu email está correto.' },
  { id: 'plans', label: 'Dúvidas sobre Planos', response: 'Nossos planos oferecem recursos variados. O plano Gratuito é ideal para começar, enquanto o PRO oferece relatórios avançados e gestão ilimitada.' },
  { id: 'payments', label: 'Pagamentos e Faturas', response: 'Você pode visualizar seu histórico de pagamentos nas configurações da conta. Para segunda via de boleto, entre em contato com nosso suporte humano.' },
  { id: 'bug', label: 'Reportar um Erro', response: 'Sentimos muito por isso! Por favor, descreva o erro detalhadamente para nosso suporte humano no WhatsApp para que possamos corrigir o mais rápido possível.' },
  { id: 'other', label: 'Outros Assuntos', response: 'Entendo. Para assuntos mais específicos, recomendo falar diretamente com um de nossos especialistas.' },
];

const SupportPage = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [chatHistory, setChatHistory] = useState([
    { type: 'bot', text: `Olá, ${user?.user_metadata?.full_name?.split(' ')[0] || 'visitante'}! Sou o assistente virtual do Finança Online. Como posso ajudar você hoje?` }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  // Filter FAQs
  const filteredFaqs = FAQS.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || faq.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Chat Functionality
  const handleChatOption = (option) => {
    // Add user message
    setChatHistory(prev => [...prev, { type: 'user', text: option.label }]);
    setIsTyping(true);

    // Simulate bot response
    setTimeout(() => {
      setChatHistory(prev => [
        ...prev, 
        { type: 'bot', text: option.response },
        { type: 'bot', text: 'Essa resposta foi útil? Se precisar de mais ajuda, fale com um humano.' }
      ]);
      setIsTyping(false);
    }, 1500);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatHistory, isTyping]);

  return (
    <>
      <Helmet>
        <title>Suporte & Ajuda - Finança Online</title>
      </Helmet>

      <div className="max-w-7xl mx-auto space-y-8 pb-24">
        
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-[#4A4A4A]">Central de Ajuda</h1>
          <p className="text-gray-500 mt-2">Encontre respostas rápidas ou fale com nosso time.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          
          {/* Main Content - FAQs */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input 
                className="pl-10 h-12 text-base rounded-xl border-gray-200 bg-white shadow-sm focus:ring-[#3FAE2A]" 
                placeholder="Busque por dúvidas (ex: como cancelar, adicionar despesa...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory('all')}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                  selectedCategory === 'all' 
                    ? "bg-[#3FAE2A] text-white shadow-md" 
                    : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-100"
                )}
              >
                Todas
              </button>
              {FAQ_CATEGORIES.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
                    selectedCategory === cat.id 
                      ? "bg-[#3FAE2A] text-white shadow-md" 
                      : "bg-white text-gray-600 hover:bg-gray-50 border border-gray-100"
                  )}
                >
                  {cat.icon}
                  {cat.label}
                </button>
              ))}
            </div>

            {/* FAQ List */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              {filteredFaqs.length > 0 ? (
                <Accordion type="single" collapsible className="w-full">
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`} className="border-b last:border-0 px-6">
                      <AccordionTrigger className="hover:no-underline hover:text-[#3FAE2A] text-left py-4 font-semibold text-gray-700">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-gray-600 pb-4 leading-relaxed">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              ) : (
                <div className="p-12 text-center text-gray-500">
                  <HelpCircle className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhuma dúvida encontrada para sua busca.</p>
                  <Button variant="link" onClick={() => setSearchQuery('')} className="text-[#3FAE2A]">Limpar busca</Button>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar - Chat Assistant */}
          <div className="lg:col-span-1">
             <div className="bg-white rounded-2xl shadow-sm border border-gray-100 h-[600px] flex flex-col sticky top-6">
                <div className="p-4 border-b border-gray-100 bg-gray-50/50 rounded-t-2xl flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#3FAE2A] flex items-center justify-center text-white shadow-md">
                        <MessageCircle size={20} />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-800 text-sm">Assistente Virtual</h3>
                        <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> Online
                        </p>
                      </div>
                   </div>
                   <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setChatHistory([{ type: 'bot', text: 'Chat reiniciado.' }])}>
                      <X size={16} className="text-gray-400" />
                   </Button>
                </div>

                {/* Messages Area */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/30" ref={scrollRef}>
                   {chatHistory.map((msg, idx) => (
                     <motion.div 
                       key={idx}
                       initial={{ opacity: 0, y: 10 }}
                       animate={{ opacity: 1, y: 0 }}
                       className={cn(
                         "max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed",
                         msg.type === 'user' 
                           ? "bg-[#3FAE2A] text-white ml-auto rounded-tr-none" 
                           : "bg-white border border-gray-100 text-gray-600 mr-auto rounded-tl-none shadow-sm"
                       )}
                     >
                       {msg.text}
                     </motion.div>
                   ))}
                   {isTyping && (
                     <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-white border border-gray-100 p-3 rounded-2xl rounded-tl-none w-16 mr-auto">
                        <div className="flex gap-1 justify-center">
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                          <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></span>
                        </div>
                     </motion.div>
                   )}
                </div>

                {/* Quick Options Footer */}
                <div className="p-4 border-t border-gray-100 bg-white rounded-b-2xl">
                   <p className="text-xs text-gray-400 font-medium mb-3 uppercase tracking-wider text-center">Opções Rápidas</p>
                   <div className="flex flex-wrap gap-2 justify-center">
                      {CHAT_OPTIONS.map(opt => (
                        <button
                          key={opt.id}
                          onClick={() => handleChatOption(opt)}
                          className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-full transition-colors border border-gray-200"
                        >
                          {opt.label}
                        </button>
                      ))}
                      <a 
                        href="http://wa.me/5519991098088?text=Olá,%20preciso%20de%20ajuda%20com%20minha%20conta" 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-xs bg-green-50 hover:bg-green-100 text-green-700 px-3 py-1.5 rounded-full transition-colors border border-green-200 font-medium flex items-center gap-1"
                      >
                         <Phone size={10} /> Falar com Humano
                      </a>
                   </div>
                </div>
             </div>
          </div>

        </div>

        {/* Floating WhatsApp Button */}
        <motion.a
          href="http://wa.me/5519991098088?text=Olá,%20preciso%20de%20ajuda%20com%20minha%20conta"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:shadow-xl hover:bg-[#20bd5a] transition-all z-50 flex items-center gap-2 group"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
        >
          <img 
            src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" 
            alt="WhatsApp" 
            className="w-8 h-8 filter brightness-0 invert"
          />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 ease-in-out whitespace-nowrap font-bold pl-0 group-hover:pl-2">
            Suporte via WhatsApp
          </span>
        </motion.a>

      </div>
    </>
  );
};

export default SupportPage;