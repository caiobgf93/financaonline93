import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Filter,
  CalendarDays,
  ArrowRight,
  FileText,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { formatCurrency } from '@/utils/currency';
import { Link } from 'react-router-dom';

const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

const YEARS = [2023, 2024, 2025, 2026];

const DashboardHome = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  
  // Filter States
  const currentDate = new Date();
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth());
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  
  // Data states
  const [transactions, setTransactions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [goals, setGoals] = useState([]);
  const [cards, setCards] = useState([]);
  const [upcomingBills, setUpcomingBills] = useState([]);

  useEffect(() => {
    let mounted = true;

    const loadDashboardData = async () => {
      if (!user) return;
      
      setLoading(true);
      try {
        // Calculate date range for filter
        const startDate = new Date(selectedYear, selectedMonth, 1).toISOString().split('T')[0];
        const endDate = new Date(selectedYear, selectedMonth + 1, 0).toISOString().split('T')[0];

        // Parallel fetching
        const [
          { data: transactionsData },
          { data: categoriesData },
          { data: goalsData },
          { data: cardsData },
          { data: billsData }
        ] = await Promise.all([
          supabase
            .from('transactions')
            .select('*')
            .eq('user_id', user.id)
            .gte('date', startDate)
            .lte('date', endDate)
            .order('date', { ascending: false }),
          
          supabase.from('categories').select('*').eq('user_id', user.id),
          supabase.from('financial_goals').select('*').eq('user_id', user.id).limit(3),
          supabase.from('credit_cards').select('*').eq('user_id', user.id),
          
          // Fetch bills: All pending bills, ordered by due date (overdue first)
          supabase
            .from('bills')
            .select('*')
            .eq('user_id', user.id)
            .eq('status', 'pending')
            .order('due_date', { ascending: true })
            .limit(5)
        ]);

        // Process cards usage for the selected month
        let cardsWithUsage = [];
        if (cardsData && cardsData.length > 0) {
            cardsWithUsage = await Promise.all(cardsData.map(async (card) => {
                const { data: cardTrans } = await supabase
                   .from('transactions')
                   .select('amount')
                   .eq('credit_card_id', card.id)
                   .gte('date', startDate)
                   .lte('date', endDate)
                   .eq('type', 'expense');
                
                const current_invoice = cardTrans?.reduce((sum, t) => sum + Number(t.amount), 0) || 0;
                return { ...card, current_invoice };
            }));
        }

        if (mounted) {
          setTransactions(transactionsData || []);
          setCategories(categoriesData || []);
          setGoals(goalsData || []);
          setCards(cardsWithUsage || []);
          setUpcomingBills(billsData || []);
        }

      } catch (error) {
        console.error("Dashboard data load error:", error);
        if (mounted) {
          toast({
            variant: "destructive",
            title: "Erro",
            description: "Falha ao carregar dados.",
          });
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };

    loadDashboardData();

    return () => {
      mounted = false;
    };
  }, [user, selectedMonth, selectedYear, toast]);

  const calculateBalance = () => {
    const income = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const expenses = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    return { income, expenses, balance: income - expenses };
  };

  const { income, expenses, balance } = calculateBalance();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#3FAE2A]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Dashboard - Finança Online</title>
      </Helmet>

      <div className="space-y-4 pb-6">
        {/* Header with Filters */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#4A4A4A]">Dashboard</h1>
            <p className="text-gray-600">Visão geral: {MONTHS[selectedMonth]} de {selectedYear}</p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3 bg-white p-2.5 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 px-3 text-gray-400">
               <Filter size={18} />
               <span className="text-sm font-medium">Filtrar:</span>
            </div>
            
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm font-medium text-[#4A4A4A] cursor-pointer hover:bg-gray-100 focus:ring-2 focus:ring-[#3FAE2A] focus:border-transparent outline-none transition-all"
            >
              {MONTHS.map((month, index) => (
                <option key={index} value={index}>{month}</option>
              ))}
            </select>

            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm font-medium text-[#4A4A4A] cursor-pointer hover:bg-gray-100 focus:ring-2 focus:ring-[#3FAE2A] focus:border-transparent outline-none transition-all"
            >
              {YEARS.map((year) => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-green-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                <div className="p-2 bg-green-100 rounded-lg text-green-600">
                   <DollarSign size={20} />
                </div>
                <span className="font-medium">Saldo em Caixa</span>
              </div>
              <p className={`text-3xl font-bold tracking-tight ${
                balance >= 0 ? 'text-[#3FAE2A]' : 'text-red-500'
              }`}>
                {formatCurrency(balance)}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                <div className="p-2 bg-blue-100 rounded-lg text-blue-600">
                   <TrendingUp size={20} />
                </div>
                <span className="font-medium">Receitas</span>
              </div>
              <p className="text-3xl font-bold text-blue-600 tracking-tight">
                {formatCurrency(income)}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 relative overflow-hidden group hover:shadow-md transition-shadow">
            <div className="absolute right-0 top-0 w-24 h-24 bg-red-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4 text-gray-500">
                 <div className="p-2 bg-red-100 rounded-lg text-red-600">
                   <TrendingDown size={20} />
                 </div>
                <span className="font-medium">Despesas</span>
              </div>
              <p className="text-3xl font-bold text-red-600 tracking-tight">
                {formatCurrency(expenses)}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column (Transactions & Bills) */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Upcoming Bills Section */}
            <motion.div
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.3 }}
               className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100"
            >
               <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#4A4A4A] flex items-center gap-2">
                     <FileText className="text-[#3FAE2A]" size={20} />
                     Contas a Pagar
                  </h2>
                  <Link to="/dashboard/contas">
                    <Button variant="ghost" size="sm" className="text-[#3FAE2A] hover:text-[#3FAE2A] hover:bg-green-50">
                       Ver todas <ArrowRight size={16} className="ml-1" />
                    </Button>
                  </Link>
               </div>

               {upcomingBills.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                     <p className="text-gray-500 text-sm">Nenhuma conta pendente.</p>
                  </div>
               ) : (
                  <div className="space-y-3">
                     {upcomingBills.map(bill => {
                        const today = new Date().toISOString().split('T')[0];
                        const isOverdue = bill.due_date < today;
                        const isToday = bill.due_date === today;
                        
                        return (
                           <div key={bill.id} className="flex items-center justify-between p-3 rounded-xl border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all bg-white group">
                              <div className="flex items-center gap-3">
                                 <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isOverdue ? 'bg-red-50 text-red-500' : isToday ? 'bg-orange-50 text-orange-500' : 'bg-gray-50 text-gray-500'}`}>
                                    <CalendarDays size={18} />
                                 </div>
                                 <div>
                                    <p className="font-bold text-[#4A4A4A] text-sm group-hover:text-[#3FAE2A] transition-colors">{bill.description}</p>
                                    <p className={`text-xs font-medium ${isOverdue ? 'text-red-500' : isToday ? 'text-orange-500' : 'text-gray-400'}`}>
                                       {isOverdue ? 'Atrasada' : isToday ? 'Vence Hoje' : `Vence em ${new Date(bill.due_date).toLocaleDateString('pt-BR')}`}
                                    </p>
                                 </div>
                              </div>
                              <span className="font-bold text-[#4A4A4A] text-sm">
                                 {formatCurrency(bill.amount)}
                              </span>
                           </div>
                        );
                     })}
                  </div>
               )}
            </motion.div>

            {/* Recent Transactions List */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-[#4A4A4A]">Transações do Mês</h2>
                <Link to="/dashboard/lancamentos">
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-[#4A4A4A]">Ver todas</Button>
                </Link>
              </div>
              
              {transactions.length === 0 ? (
                <div className="text-center py-12 text-gray-400 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                  <p>Nenhuma transação neste período.</p>
                </div>
              ) : (
                <div className="overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left py-3 px-2 text-xs uppercase tracking-wider font-semibold text-gray-400">Dia</th>
                        <th className="text-left py-3 px-2 text-xs uppercase tracking-wider font-semibold text-gray-400">Descrição</th>
                        <th className="text-right py-3 px-2 text-xs uppercase tracking-wider font-semibold text-gray-400">Valor</th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactions.slice(0, 8).map((transaction) => (
                        <tr key={transaction.id} className="group hover:bg-gray-50/80 transition-colors">
                          <td className="py-3 px-2 text-sm text-gray-500 font-medium border-b border-gray-50">
                            {new Date(transaction.date).getDate().toString().padStart(2, '0')}
                          </td>
                          <td className="py-3 px-2 text-sm text-[#4A4A4A] font-medium border-b border-gray-50 group-hover:text-[#3FAE2A] transition-colors">
                             {transaction.description}
                             <span className="block text-xs text-gray-400 font-normal">
                                {categories.find(c => c.id === transaction.category_id)?.name || 'Sem categoria'}
                             </span>
                          </td>
                          <td className={`py-3 px-2 text-sm text-right font-bold border-b border-gray-50 ${
                            transaction.type === 'income' ? 'text-[#3FAE2A]' : 'text-red-500'
                          }`}>
                            {transaction.type === 'income' ? '+' : '-'} {formatCurrency(transaction.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {transactions.length > 8 && (
                     <div className="text-center mt-4">
                        <span className="text-xs text-gray-400">Mostrando 8 de {transactions.length} lançamentos</span>
                     </div>
                  )}
                </div>
              )}
            </motion.div>
          </div>

          {/* Right Column (Goals & Cards) */}
          <div className="space-y-8">
             {/* Metas */}
             <motion.div
               initial={{ opacity: 0, x: 20 }}
               animate={{ opacity: 1, x: 0 }}
               transition={{ delay: 0.5 }}
               className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100"
             >
                <h2 className="text-xl font-bold text-[#4A4A4A] mb-4">Minhas Metas</h2>
                {goals.length === 0 ? (
                   <p className="text-gray-400 text-sm text-center py-4">Sem metas cadastradas.</p>
                ) : (
                   <div className="space-y-5">
                      {goals.map(goal => {
                         const percentage = (parseFloat(goal.current_amount || 0) / parseFloat(goal.target_amount)) * 100;
                         return (
                            <div key={goal.id}>
                               <div className="flex justify-between text-sm mb-1.5">
                                  <span className="font-semibold text-gray-700">{goal.name}</span>
                                  <span className="font-bold text-[#3FAE2A]">{percentage.toFixed(0)}%</span>
                               </div>
                               <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                                  <div className="h-full bg-[#3FAE2A] rounded-full" style={{ width: `${Math.min(percentage, 100)}%` }} />
                               </div>
                               <p className="text-xs text-gray-400 mt-1 text-right">
                                  {formatCurrency(goal.current_amount || 0)} de {formatCurrency(goal.target_amount)}
                               </p>
                            </div>
                         )
                      })}
                   </div>
                )}
             </motion.div>

             {/* Cartões */}
             <motion.div
               initial={{ opacity: 0, x: 20 }}
               animate={{ opacity: 1, x: 0 }}
               transition={{ delay: 0.6 }}
               className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100"
             >
                <h2 className="text-xl font-bold text-[#4A4A4A] mb-4">Uso dos Cartões</h2>
                {cards.length === 0 ? (
                   <p className="text-gray-400 text-sm text-center py-4">Sem cartões cadastrados.</p>
                ) : (
                   <div className="space-y-4">
                      {cards.map(card => {
                         const limit = parseFloat(card.credit_limit);
                         const invoice = parseFloat(card.current_invoice || 0);
                         const percentage = Math.min((invoice / limit) * 100, 100);
                         
                         return (
                            <div key={card.id} className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                               <div className="flex items-center justify-between mb-3">
                                  <div className="flex items-center gap-2">
                                     <div className="w-2 h-8 rounded-full" style={{ backgroundColor: card.color || '#3FAE2A' }} />
                                     <div>
                                        <p className="font-bold text-sm text-gray-700">{card.name}</p>
                                        <p className="text-xs text-gray-500">{card.bank}</p>
                                     </div>
                                  </div>
                                  <p className="font-bold text-sm text-gray-800">{formatCurrency(invoice)}</p>
                               </div>
                               <div className="h-1.5 w-full bg-gray-200 rounded-full overflow-hidden">
                                  <div 
                                     className="h-full rounded-full transition-all duration-500" 
                                     style={{ width: `${percentage}%`, backgroundColor: card.color || '#3FAE2A' }} 
                                  />
                               </div>
                            </div>
                         )
                      })}
                   </div>
                )}
             </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DashboardHome;