import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, FileText, Lock, Scale, AlertCircle, CheckCircle2, UserCheck, CreditCard } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const TermsAndPrivacyPage = () => {
  const termsItems = [
    {
      title: "1. Aceitação dos Termos",
      icon: <CheckCircle2 className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Ao acessar e utilizar a plataforma Finança Online, você concorda integralmente com estes Termos de Uso. Se você não concordar com qualquer parte destes termos, você não deve utilizar nosso serviço. O uso continuado da plataforma constitui sua aceitação de quaisquer alterações ou modificações feitas nestes termos."
    },
    {
      title: "2. Uso do Serviço",
      icon: <UserCheck className="w-5 h-5 text-[#3FAE2A]" />,
      content: "A Finança Online concede a você uma licença limitada, não exclusiva e intransferível para usar nossos serviços apenas para fins pessoais e não comerciais. Você concorda em não usar o serviço para qualquer finalidade ilegal ou não autorizada. Você é responsável por manter a confidencialidade de sua senha e conta."
    },
    {
      title: "3. Planos e Pagamentos",
      icon: <CreditCard className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Oferecemos planos gratuitos e pagos (Premium). Ao assinar um plano pago, você concorda em pagar as taxas aplicáveis conforme descrito no momento da compra. As assinaturas são renovadas automaticamente, a menos que canceladas pelo menos 24 horas antes do final do período atual."
    },
    {
      title: "4. Cancelamento e Reembolso",
      icon: <AlertCircle className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Você pode cancelar sua assinatura a qualquer momento através do painel de controle da sua conta. Para reembolsos, consulte nossa Política de Reembolso específica. O cancelamento interrompe a renovação automática, mas o serviço permanece ativo até o final do período já pago."
    },
    {
      title: "5. Propriedade Intelectual",
      icon: <Scale className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Todo o conteúdo, design, gráficos, código e software da plataforma são propriedade exclusiva da Finança Online e estão protegidos por leis de direitos autorais e propriedade intelectual. É proibida a reprodução, distribuição ou criação de obras derivadas sem nossa permissão expressa."
    }
  ];

  const privacyItems = [
    {
      title: "1. Coleta de Informações",
      icon: <FileText className="w-5 h-5 text-blue-500" />,
      content: "Coletamos informações que você nos fornece diretamente (nome, e-mail, dados financeiros inseridos manualmente) e dados coletados automaticamente (endereço IP, tipo de navegador, logs de acesso). Não armazenamos dados completos de cartões de crédito; estes são processados de forma segura por nosso parceiro de pagamentos (Stripe)."
    },
    {
      title: "2. Uso das Informações",
      icon: <UserCheck className="w-5 h-5 text-blue-500" />,
      content: "Utilizamos seus dados para: fornecer e manter o serviço; notificar sobre alterações; permitir suporte ao cliente; e analisar o uso para melhorias. Seus dados financeiros são usados estritamente para gerar seus relatórios e dashboards pessoais e nunca são vendidos a terceiros."
    },
    {
      title: "3. Segurança dos Dados",
      icon: <Lock className="w-5 h-5 text-blue-500" />,
      content: "Empregamos medidas de segurança robustas, incluindo criptografia SSL/TLS para transmissão de dados e criptografia em repouso para dados sensíveis. No entanto, nenhum método de transmissão pela Internet ou armazenamento eletrônico é 100% seguro, e não podemos garantir segurança absoluta."
    },
    {
      title: "4. Cookies e Rastreamento",
      icon: <Shield className="w-5 h-5 text-blue-500" />,
      content: "Utilizamos cookies para melhorar a experiência do usuário, manter você logado e lembrar suas preferências. Você pode configurar seu navegador para recusar cookies, mas algumas funcionalidades da plataforma podem não funcionar corretamente."
    },
    {
      title: "5. Seus Direitos (LGPD)",
      icon: <Scale className="w-5 h-5 text-blue-500" />,
      content: "De acordo com a Lei Geral de Proteção de Dados (LGPD), você tem direito a: confirmar a existência de tratamento; acessar seus dados; corrigir dados incompletos ou desatualizados; anonimizar, bloquear ou eliminar dados desnecessários; e revogar seu consentimento a qualquer momento."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Termos de Uso e Privacidade - Finança Online</title>
        <meta name="description" content="Leia nossos Termos de Uso e Política de Privacidade. Transparência total sobre seus dados e direitos." />
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
             <Link to="/"><Logo /></Link>
             <div className="flex items-center gap-4">
                <Link to="/contato"><Button variant="ghost" className="hidden sm:inline-flex">Ajuda</Button></Link>
                <Link to="/login"><Button>Entrar</Button></Link>
             </div>
          </nav>
        </header>

        <div className="flex-1 py-12 px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto"
          >
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold text-[#4A4A4A] mb-4">Central Legal</h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Transparência é um dos nossos pilares. Aqui você encontra tudo sobre como operamos e como cuidamos dos seus dados.
              </p>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
              <Tabs defaultValue="terms" className="w-full">
                <div className="border-b border-gray-200 bg-gray-50/50 p-2">
                  <TabsList className="grid w-full grid-cols-2 h-12 bg-gray-200/50 rounded-xl p-1">
                    <TabsTrigger value="terms" className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-[#3FAE2A] data-[state=active]:shadow-sm text-base font-medium">
                      Termos de Uso
                    </TabsTrigger>
                    <TabsTrigger value="privacy" className="rounded-lg data-[state=active]:bg-white data-[state=active]:text-blue-600 data-[state=active]:shadow-sm text-base font-medium">
                      Política de Privacidade
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="terms" className="p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-center gap-3 mb-6">
                    <FileText className="w-8 h-8 text-[#3FAE2A]" />
                    <h2 className="text-2xl font-bold text-[#4A4A4A]">Termos de Uso</h2>
                  </div>
                  <p className="text-gray-600 mb-8">
                    Última atualização: 05 de Dezembro de 2025. Por favor, leia estes termos cuidadosamente antes de usar nosso serviço.
                  </p>
                  
                  <Accordion type="single" collapsible className="w-full space-y-4">
                    {termsItems.map((item, index) => (
                      <AccordionItem key={index} value={`item-${index}`} className="border border-gray-100 rounded-xl px-4 data-[state=open]:bg-green-50/30 data-[state=open]:border-[#3FAE2A]/30">
                        <AccordionTrigger className="hover:no-underline py-5">
                          <div className="flex items-center gap-3 text-left">
                            {item.icon}
                            <span className="font-bold text-[#4A4A4A] text-lg">{item.title}</span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-600 text-base leading-relaxed pb-6 pl-11">
                          {item.content}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </TabsContent>

                <TabsContent value="privacy" className="p-6 md:p-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="w-8 h-8 text-blue-600" />
                    <h2 className="text-2xl font-bold text-[#4A4A4A]">Política de Privacidade</h2>
                  </div>
                  <p className="text-gray-600 mb-8">
                    Sua privacidade é nossa prioridade. Esta política descreve como coletamos, usamos e protegemos suas informações pessoais.
                  </p>

                  <Accordion type="single" collapsible className="w-full space-y-4">
                    {privacyItems.map((item, index) => (
                      <AccordionItem key={index} value={`item-${index}`} className="border border-gray-100 rounded-xl px-4 data-[state=open]:bg-blue-50/30 data-[state=open]:border-blue-200">
                        <AccordionTrigger className="hover:no-underline py-5">
                          <div className="flex items-center gap-3 text-left">
                            {item.icon}
                            <span className="font-bold text-[#4A4A4A] text-lg">{item.title}</span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="text-gray-600 text-base leading-relaxed pb-6 pl-11">
                          {item.content}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </TabsContent>
              </Tabs>
            </div>
          </motion.div>
        </div>

        <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
          <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
            <p>&copy; 2025 Finança Online. Todos os direitos reservados.</p>
          </div>
        </footer>
      </div>
    </>
  );
};

export default TermsAndPrivacyPage;