
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff, Loader2 } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import SocialAuthButtons from '@/components/SocialAuthButtons';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { signIn } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get("confirmed") === "true") {
      toast({
        title: "E-mail confirmado com sucesso",
        description: "Agora você pode acessar sua conta.",
        duration: 6000,
        className: "bg-green-50 border-green-200 text-green-900",
      });
      setTimeout(() => {
        navigate('/login', { replace: true });
      }, 5000);
    }
  }, [location, toast, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);

    try {
      const { error } = await signIn(email, password);

      if (error) {
        let errorMsg = "Ocorreu um erro ao entrar.";
        if (error.message.includes("Invalid login credentials")) errorMsg = "E-mail ou senha incorretos.";
        if (error.message.includes("Email not confirmed")) errorMsg = "Confirme seu e-mail antes de entrar.";

        toast({
          variant: "destructive",
          title: "Erro no Login",
          description: errorMsg,
        });
        setIsSubmitting(false);
      } else {
        toast({
          title: "Bem-vindo!",
          description: "Login realizado com sucesso.",
        });
        setTimeout(() => navigate('/dashboard'), 500);
      }
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Erro Inesperado",
        description: "Tente novamente mais tarde.",
      });
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet><title>Login - Finança Online</title></Helmet>
      <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md"
        >
          <div className="text-center mb-8">
            <div className="flex justify-center mb-8">
              <Logo className="h-10 mb-4" />
            </div>
            <h1 className="text-2xl font-bold text-[#4A4A4A]">Bem-vindo de volta!</h1>
            <p className="text-gray-500 mt-2">Entre para gerenciar suas finanças</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">E-mail</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-[#3FAE2A] outline-none"
                  placeholder="seu@email.com"
                  required
                  disabled={isSubmitting}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">Senha</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 text-gray-400" size={20} />
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-12 py-3 border rounded-lg focus:ring-2 focus:ring-[#3FAE2A] outline-none"
                  placeholder="••••••••"
                  required
                  disabled={isSubmitting}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <div className="text-right">
              <Link to="/recuperar-senha" className="text-sm text-[#3FAE2A] hover:underline">Esqueceu a senha?</Link>
            </div>

            <Button type="submit" disabled={isSubmitting} className="w-full bg-[#3FAE2A] hover:bg-[#359923] py-6 text-lg">
              {isSubmitting ? (
                <span className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Entrando...
                </span>
              ) : 'Entrar'}
            </Button>
          </form>

          <div className="mt-6">
            <SocialAuthButtons />
          </div>

          <div className="mt-8 text-center border-t border-gray-100 pt-6">
            <p className="text-gray-600">
              Não tem uma conta? <Link to="/cadastro" className="text-[#3FAE2A] font-bold hover:underline">Cadastre-se</Link>
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default LoginPage;
