import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';

const EmailConfirmado = () => {
  const [countdown, setCountdown] = useState(5);
  const [status, setStatus] = useState('validando'); // validando | sucesso | erro
  const [errorMsg, setErrorMsg] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const token = params.get('token');
    const type = params.get('type') || 'email';
    const email = params.get('email');

    const confirmarEmail = async () => {
      if (!token || !email) {
        setStatus('erro');
        setErrorMsg('Link inválido ou incompleto. Tente reenviar o e‑mail de confirmação.');
        return;
      }

      const { error } = await supabase.auth.verifyOtp({
        email,
        token,
        type, // "email"
      });

      if (error) {
        setStatus('erro');
        setErrorMsg('Ocorreu um erro ao confirmar seu e‑mail. Tente novamente.');
      } else {
        setStatus('sucesso');
      }
    };

    confirmarEmail();
  }, [location.search]);

  useEffect(() => {
    if (status === 'sucesso' && countdown === 0) {
      navigate('/login');
      return;
    }
    if (status === 'sucesso') {
      const timer = setTimeout(() => setCountdown((c) => c - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown, navigate, status]);

  return (
    <>
      <Helmet>
        <title>E-mail Confirmado - Finança Online</title>
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5] flex flex-col items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center"
        >
          {status === 'validando' && (
            <p className="text-gray-600">Validando seu e‑mail...</p>
          )}

          {status === 'sucesso' && (
            <>
              <div className="mb-6 flex justify-center">
                <div className="h-20 w-20 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="h-10 w-10 text-[#3FAE2A]" />
                </div>
              </div>

              <h1 className="text-2xl font-bold text-[#4A4A4A] mb-4">
                E‑mail confirmado com sucesso
              </h1>

              <p className="text-gray-600 mb-6 leading-relaxed">
                Sua conta foi ativada. Você será redirecionado para o login em{' '}
                <span className="font-semibold">{countdown}</span> segundos.
              </p>

              <Link to="/login" className="block w-full">
                <Button className="w-full bg-[#3FAE2A] hover:bg-[#359923] py-6 text-lg">
                  Efetuar Login <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </>
          )}

          {status === 'erro' && (
            <>
              <p className="text-red-600">{errorMsg}</p>
              <div className="mt-4">
                <Link to="/login" className="block w-full">
                  <Button variant="outline" className="w-full">
                    Voltar ao login
                  </Button>
                </Link>
              </div>
            </>
          )}
        </motion.div>

        <div className="mt-8">
          <Logo className="h-8 opacity-50 grayscale" />
        </div>
      </div>
    </>
  );
};

export default EmailConfirmado;