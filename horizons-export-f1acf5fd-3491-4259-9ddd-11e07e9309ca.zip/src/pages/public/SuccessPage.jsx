import React, { useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWindowSize } from 'react-use';
import Confetti from 'react-confetti';

const SuccessPage = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const { width, height } = useWindowSize();

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
      <Confetti width={width} height={height} recycle={false} numberOfPieces={500} />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-xl p-8 max-w-md text-center"
      >
        <div className="flex justify-center mb-6">
          <CheckCircle className="w-20 h-20 text-[#3FAE2A]" />
        </div>
        
        <h1 className="text-3xl font-bold text-[#4A4A4A] mb-4">Pagamento Confirmado!</h1>
        <p className="text-gray-600 mb-8">
					Sua assinatura está ativa! Agora você tem acesso completo a todos os recursos do Finança Online!
        </p>
        
        <Link to="/dashboard">
          <Button className="w-full bg-[#3FAE2A] hover:bg-[#359923] h-12 text-lg gap-2">
            Ir para o Dashboard<ArrowRight size={20} />
          </Button>
        </Link>
      </motion.div>
    </div>
  );
};

export default SuccessPage;