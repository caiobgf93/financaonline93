import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  PieChart,
  Target,
  CreditCard,
  Shield,
  Zap,
  Check,
  Star,
  Coffee,
  Instagram,
  ArrowRight,
  Sparkles,
  PlayCircle
} from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { PLAN_PRICES } from '@/utils/stripeConfig';

const HomePage = () => {
  const features = [
    {
      icon: <PieChart className="w-8 h-8" />,
      title: 'Clareza Total',
      description: 'Veja para onde cada centavo está indo. Gráficos intuitivos transformam números complexos em insights simples.'
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: 'Realize Sonhos',
      description: 'Defina metas financeiras claras e acompanhe seu progresso. Do carro novo à aposentadoria.'
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: 'Adeus Surpresas',
      description: 'Controle todos os seus cartões de crédito em um só lugar. Saiba o valor da fatura antes dela fechar.'
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Relatórios Inteligentes',
      description: 'Análises mensais e anuais que mostram sua evolução e ajudam a cortar gastos desnecessários.'
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: 'Segurança de Banco',
      description: 'Seus dados são criptografados e protegidos com os mais altos padrões de segurança do mercado.'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Rápido e Prático',
      description: 'Interface limpa e ágil. Lance suas despesas em segundos, no computador ou no celular.'
    }
  ];

  const landingPlans = [
    {
      name: "Plano Mensal",
      price: "R$ 19,90",
      period: "/mês",
      description: "Flexibilidade total.",
      features: ["Lançamentos Ilimitados", "Controle de Contas e Cartões", "Relatórios Completos", "Planejamento de Metas", "Suporte", "Backup Automático"],
      cta: "Assinar Mensal",
      highlight: false,
      link: `/cadastro?plan=${PLAN_PRICES.basic_monthly.id}`,
      subtext: "Sem fidelidade"
    },
    {
      name: "Plano Anual",
      price: "R$ 199,90",
      period: "/ano",
      description: "Economia inteligente.",
      features: ["Todos os recursos do Básico", "Suporte prioritário"],
      cta: "Assinar Anual",
      highlight: true,
      link: `/cadastro?plan=${PLAN_PRICES.pro_annual.id}`,
      subtext: "Economize R$ 38,90",
      tag: "Mais Popular"
    }
  ];

  return (
    <>
      <Helmet>
        <title>Finança Online - O Controle Financeiro que Você Merece</title>
        <meta name="description" content="Assuma o controle do seu dinheiro. Gestão financeira simples, poderosa e segura para você realizar seus sonhos." />
      </Helmet>

      <div className="min-h-screen bg-[#F8F9FA] font-sans">

        {/* Navigation */}
        <header className="bg-white/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-50 transition-all duration-300">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
            <Logo />
            <div className="flex items-center gap-3 sm:gap-6">
              {/* Mobile: Show ONLY Login (Entrar) button as primary action */}
              <Link to="/login" className="block sm:hidden">
                <Button className="bg-[#3FAE2A] hover:bg-[#359923] text-white font-bold rounded-full px-6 shadow-md">
                  Entrar
                </Button>
              </Link>

              {/* Desktop: Show Login (Ghost) + Começar Agora (Primary) */}
              <Link to="/login" className="hidden sm:block">
                <Button variant="ghost" className="text-gray-600 hover:text-[#3FAE2A] font-medium hover:bg-transparent text-base">
                  Entrar
                </Button>
              </Link>
              <Link to="/cadastro" className="hidden sm:block">
                <Button className="bg-[#3FAE2A] hover:bg-[#359923] text-white font-bold rounded-full px-6 py-5 shadow-lg shadow-green-200 transition-transform hover:-translate-y-0.5">
                  Começar Agora
                </Button>
              </Link>
            </div>
          </nav>
        </header>

        {/* Hero Section */}
        {/* Adjusted pt-16 to pt-8 on mobile to reduce gap */}
        <section className="relative pt-8 pb-16 md:pt-24 md:pb-32 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-50/50 to-white -z-10"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">

              {/* Left Column: Copy */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
              >
                <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-700 px-4 py-1.5 rounded-full text-sm font-bold mb-6 md:mb-8 border border-yellow-200">
                  <Star size={16} fill="currentColor" /> #1 em Gestão Financeira
                </div>

                <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-[#1A1A1A] leading-[1.1] mb-6 tracking-tight">
                  Seu dinheiro, <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#3FAE2A] to-[#2D8A1E]">
                    suas regras.
                  </span>
                </h1>

                <p className="text-lg md:text-2xl text-gray-500 mb-8 md:mb-10 leading-relaxed max-w-lg">
                  Pare de sobreviver mês a mês. Comece a construir sua liberdade financeira hoje com a plataforma mais completa do mercado.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 mb-8 md:mb-10">
                  <Link to="/cadastro" className="w-full sm:w-auto">
                    <Button size="lg" className="w-full h-14 md:h-16 bg-[#3FAE2A] hover:bg-[#359923] text-white text-lg font-bold rounded-xl shadow-xl shadow-green-200/50 hover:shadow-2xl transition-all">
                      Criar Conta Grátis
                      <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                  </Link>
                  <Link to="/como-funciona" className="w-full sm:w-auto">
                    <Button size="lg" variant="outline" className="w-full h-14 md:h-16 border-2 border-gray-200 text-gray-700 hover:border-[#3FAE2A] hover:text-[#3FAE2A] hover:bg-green-50 text-lg font-bold rounded-xl transition-all">
                      Ver Como Funciona
                    </Button>
                  </Link>
                </div>

                <div className="flex items-center gap-4 md:gap-6 text-sm text-gray-500 font-medium flex-wrap">
                  <span className="flex items-center gap-2"><Check className="text-[#3FAE2A]" size={18} /> Sem cartão necessário</span>
                  <span className="flex items-center gap-2"><Check className="text-[#3FAE2A]" size={18} /> Cancele quando quiser</span>
                </div>
              </motion.div>

              {/* Right Column: Video/Visual */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative mt-8 lg:mt-0"
              >
                <div className="absolute -inset-4 bg-[#3FAE2A] rounded-[2rem] opacity-20 blur-2xl -z-10 animate-pulse"></div>
                <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
                  <div className="aspect-w-16 aspect-h-9 w-full bg-gray-900">
                    <iframe
                      className="w-full h-[250px] sm:h-[350px] md:h-[450px]"
                      src="https://www.youtube.com/embed/GAqcncO9sF0?si=s7s2e-bRd-eW1CLq"
                      title="Apresentação Finança Online"
                      frameBorder="0"
                      allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                </div>
              </motion.div>

            </div>
          </div>
        </section>

        {/* NEW SECTION: High-impact Offer */}
        <section className="bg-[#111] py-10 md:py-16 text-white relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#3FAE2A] rounded-full filter blur-[150px] opacity-10 translate-x-1/2 -translate-y-1/2"></div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-16">
              <div className="flex-1 text-center lg:text-left">
                <div className="inline-flex items-center gap-2 bg-[#3FAE2A]/20 text-[#3FAE2A] px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-4 border border-[#3FAE2A]/30">
                  <Sparkles size={14} /> Oferta Especial
                </div>
                <h2 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
                  Experimente 7 dias <span className="text-[#3FAE2A]">totalmente grátis</span>
                </h2>
                <p className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto lg:mx-0 leading-relaxed">
                  Desbloqueie todos os recursos Premium hoje. Depois, apenas
                  <span className="text-white font-bold"> R$ 19,90/mês</span>.
                  Sem compromisso, cancele a qualquer momento.
                </p>
              </div>

              <div className="flex-shrink-0 w-full lg:w-auto">
                <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl flex flex-col items-center gap-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-400 uppercase tracking-wide font-medium">Plano Mensal</p>
                    <div className="flex items-baseline justify-center gap-1 mt-1">
                      <span className="text-sm text-gray-400 line-through">R$ 29,90</span>
                      <span className="text-4xl font-bold text-white">R$ 19,90</span>
                    </div>
                  </div>
                  <Link to={`/cadastro?plan=${PLAN_PRICES.basic_monthly.id}&trial=true`} className="w-full">
                    <Button className="w-full h-12 bg-[#3FAE2A] hover:bg-[#359923] text-white font-bold text-lg rounded-xl shadow-[0_0_20px_rgba(63,174,42,0.4)] hover:shadow-[0_0_30px_rgba(63,174,42,0.6)] transition-all">
                      Iniciar Teste Grátis
                    </Button>
                  </Link>
                  <p className="text-xs text-gray-500 flex items-center gap-1">
                    <Shield size={12} /> Garantia de satisfação
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-4xl font-bold text-[#1A1A1A] mb-4">Poderoso, porém simples.</h2>
              <p className="text-xl text-gray-500">Desenvolvemos cada detalhe pensando em facilitar sua vida, não complicar.</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="p-8 rounded-3xl bg-gray-50 hover:bg-white border border-transparent hover:border-gray-100 hover:shadow-xl transition-all duration-300 group"
                >
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-[#3FAE2A] shadow-sm mb-6 group-hover:scale-110 transition-transform duration-300 group-hover:bg-[#3FAE2A] group-hover:text-white">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold text-[#1A1A1A] mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Strip */}
        <section className="py-20 bg-[#1A1A1A] text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#3FAE2A] rounded-full filter blur-[100px] opacity-20 -translate-y-1/2 translate-x-1/2"></div>

          <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Assuma o comando da sua vida.</h2>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
              Junte-se a milhares de pessoas que deixaram as dívidas para trás e começaram a investir no futuro.
            </p>
            <Link to="/cadastro">
              <Button size="lg" className="h-16 px-10 text-xl font-bold bg-[#3FAE2A] hover:bg-[#359923] text-white rounded-full shadow-[0_0_30px_rgba(63,174,42,0.5)] hover:shadow-[0_0_50px_rgba(63,174,42,0.7)] transition-all">
                Começar Gratuitamente
              </Button>
            </Link>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="py-24 bg-[#F8F9FA]" id="plans">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-[#1A1A1A] mb-4">Um preço justo pelo seu sossego.</h2>
              <p className="text-xl text-gray-500">
                Sem taxas escondidas. Sem surpresas.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {landingPlans.map((plan, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className={`relative bg-white rounded-3xl p-8 lg:p-10 flex flex-col h-full transition-all duration-300 ${plan.highlight
                    ? 'shadow-2xl border-2 border-[#3FAE2A] scale-100 md:scale-105 z-10'
                    : 'shadow-lg border border-gray-100'
                    }`}
                >
                  {plan.highlight && (
                    /* Fixed positioning: using explicit negative top value and z-index to avoid clipping */
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20 w-max">
                      <span className="bg-[#3FAE2A] text-white px-6 py-2 rounded-full text-sm font-bold uppercase tracking-wider shadow-lg flex items-center gap-2">
                        <Star size={14} fill="currentColor" /> {plan.tag}
                      </span>
                    </div>
                  )}

                  <div className="text-center mb-8 pt-4">
                    <h3 className="text-2xl font-bold text-[#1A1A1A] mb-2">{plan.name}</h3>
                    <p className="text-gray-500 text-sm font-medium mb-6">{plan.description}</p>

                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-5xl font-extrabold text-[#3FAE2A] tracking-tighter">{plan.price}</span>
                      <span className="text-gray-400 font-bold">{plan.period}</span>
                    </div>

                    {plan.subtext && (
                      <p className={`text-sm mt-3 font-semibold ${plan.highlight ? 'text-green-600' : 'text-gray-400'}`}>
                        {plan.subtext}
                      </p>
                    )}
                  </div>

                  <div className="space-y-4 mb-10 flex-1">
                    {plan.features.map((feat, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${plan.highlight ? 'bg-green-100 text-[#3FAE2A]' : 'bg-gray-100 text-gray-500'}`}>
                          <Check size={14} strokeWidth={3} />
                        </div>
                        <span className="text-gray-600 font-medium">{feat}</span>
                      </div>
                    ))}
                  </div>

                  <Link to={plan.link} className="w-full">
                    <Button
                      className={`w-full h-14 font-bold text-lg rounded-xl transition-all ${plan.highlight
                        ? 'bg-[#3FAE2A] hover:bg-[#359923] text-white shadow-lg hover:-translate-y-1'
                        : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-[#3FAE2A] hover:text-[#3FAE2A] hover:bg-green-50'
                        }`}
                    >
                      {plan.cta}
                    </Button>
                  </Link>
                </motion.div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <p className="text-gray-400 flex items-center justify-center gap-2">
                <Coffee size={20} />
                <span>Menos que um cafezinho por dia.</span>
              </p>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-white border-t border-gray-100 pt-16 pb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-4 gap-12 mb-16">
              <div className="col-span-1 md:col-span-2">
                <Logo className="mb-6 scale-90 origin-left" />
                <p className="text-gray-500 leading-relaxed max-w-sm">
                  Finança Online é a plataforma líder em gestão financeira pessoal. Nossa missão é democratizar a educação financeira e ajudar pessoas a realizarem seus sonhos.
                </p>
              </div>

              <div>
                <h4 className="font-bold text-[#1A1A1A] mb-6">Plataforma</h4>
                <ul className="space-y-4 text-gray-500">
                  <li><Link to="/como-funciona" className="hover:text-[#3FAE2A] transition-colors">Como Funciona</Link></li>
                  <li><Link to="/planos-publicos" className="hover:text-[#3FAE2A] transition-colors">Planos e Preços</Link></li>
                  <li><Link to="/cadastro" className="hover:text-[#3FAE2A] transition-colors">Criar Conta</Link></li>
                  <li><Link to="/login" className="hover:text-[#3FAE2A] transition-colors">Entrar</Link></li>
                </ul>
              </div>

              <div>
                <h4 className="font-bold text-[#1A1A1A] mb-6">Suporte</h4>
                <ul className="space-y-4 text-gray-500">
                  <li><Link to="/contato" className="hover:text-[#3FAE2A] transition-colors">Fale Conosco</Link></li>
                  <li><Link to="/termos-privacidade" className="hover:text-[#3FAE2A] transition-colors">Termos de Uso</Link></li>
                  <li><Link to="/termos-privacidade" className="hover:text-[#3FAE2A] transition-colors">Privacidade</Link></li>
                </ul>
              </div>
            </div>

            <div className="border-t border-gray-300 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400 text-sm">
                &copy; {new Date().getFullYear()} Finança Online. Todos os direitos reservados.
              </p>

              {/* Ícones alinhados à direita */}
              <div className="flex gap-6 md:ml-auto text-gray-700">
                <a
                  href="https://www.instagram.com/financa_online/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[#3FAE2A] transition-colors"
                >
                  <Instagram size={20} />
                </a>
                <div className="flex items-center gap-2">
                  <Shield size={20} />
                  <span className="text-xs">Segurança SSL</span>
                </div>
              </div>
            </div>


          </div>
        </footer>

      </div>
    </>
  );
};

export default HomePage;