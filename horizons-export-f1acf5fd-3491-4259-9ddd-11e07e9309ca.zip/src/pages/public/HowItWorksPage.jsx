import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { UserPlus, Settings, TrendingUp, Target, Smartphone, RefreshCw, Lock, Rocket, CreditCard, Shield } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';

const HowItWorksPage = () => {
  const steps = [
    {
      icon: <UserPlus className="w-12 h-12" />,
      title: '1. Crie sua conta',
      description: 'Cadastre-se gratuitamente e comece seu teste de 7 dias sem compromisso.'
    },
    {
      icon: <Settings className="w-12 h-12" />,
      title: '2. Configure',
      description: 'Defina suas categorias, contas e cartões de crédito para refletir sua realidade.'
    },
    {
      icon: <TrendingUp className="w-12 h-12" />,
      title: '3. Acompanhe',
      description: 'Registre seus gastos diários e veja gráficos atualizados em tempo real.'
    },
    {
      icon: <Target className="w-12 h-12" />,
      title: '4. Realize',
      description: 'Defina metas de economia e acompanhe seu progresso até a conquista.'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Como Funciona - Finança Online</title>
        <meta name="description" content="Saiba como o Finança Online ajuda você a organizar sua vida financeira." />
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5]">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <Link to="/"><Logo /></Link>
            <div className="flex items-center gap-4">
              <Link to="/login"><Button variant="ghost">Entrar</Button></Link>
              <Link to="/cadastro"><Button className="bg-[#3FAE2A] text-white hover:bg-[#359923]">Começar Grátis</Button></Link>
            </div>
          </nav>
        </header>

        <section className="bg-gradient-to-br from-[#3FAE2A] to-[#2d8a1f] text-white py-20">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Simplifique suas Finanças</h1>
            <p className="text-xl text-white/90">Uma plataforma completa projetada para dar clareza sobre seu dinheiro.</p>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8">
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-white p-8 rounded-xl shadow-sm text-center relative"
                >
                  {i < 3 && <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gray-200 z-10"></div>}
                  <div className="text-[#3FAE2A] mb-4 flex justify-center">{step.icon}</div>
                  <h3 className="font-bold text-lg mb-2">{step.title}</h3>
                  <p className="text-gray-600 text-sm">{step.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-16 text-[#4A4A4A]">O Futuro da Plataforma</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="border border-gray-100 p-6 rounded-xl hover:shadow-lg transition-shadow">
                <Smartphone className="w-10 h-10 text-[#3FAE2A] mb-4" />
                <h3 className="font-bold text-xl mb-2">App Mobile Nativo</h3>
                <p className="text-gray-600">Em breve, leve o Finança Online no seu bolso com nosso app dedicado para iOS e Android.</p>
              </div>
              <div className="border border-gray-100 p-6 rounded-xl hover:shadow-lg transition-shadow">
                <RefreshCw className="w-10 h-10 text-[#3FAE2A] mb-4" />
                <h3 className="font-bold text-xl mb-2">Open Finance</h3>
                <p className="text-gray-600">Conecte seus bancos automaticamente para importar transações sem digitação manual.</p>
              </div>
              <div className="border border-gray-100 p-6 rounded-xl hover:shadow-lg transition-shadow">
                <Lock className="w-10 h-10 text-[#3FAE2A] mb-4" />
                <h3 className="font-bold text-xl mb-2">Cofre de Documentos</h3>
                <p className="text-gray-600">Armazene comprovantes e garantias com segurança militar diretamente na nuvem.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Mid-page CTA */}
        <section className="bg-[#F5F5F5] py-16 border-y border-gray-200">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-[#4A4A4A] mb-4">Pronto para assumir o controle?</h2>
              <p className="text-xl text-gray-600 mb-8">
                Junte-se a milhares de pessoas que já transformaram sua vida financeira.
              </p>
              <Link to="/cadastro">
                <Button size="lg" className="bg-[#3FAE2A] hover:bg-[#359923] text-white text-xl font-bold px-10 py-7 shadow-[0_4px_14px_0_rgba(63,174,42,0.39)] hover:shadow-[0_6px_20px_rgba(63,174,42,0.23)] hover:-translate-y-1 transition-all duration-200 flex items-center gap-2 mx-auto">
                  <Rocket className="w-6 h-6" />
                  Começar Teste Grátis
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#dedede] text-gray-700 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-4 gap-8 mb-8">
              <div className="col-span-2">
                <Logo className="mb-4" />
                <p className="text-gray-500 max-w-xs">Gestão financeira inteligente para você alcançar seus objetivos e realizar sonhos.</p>
              </div>
              <div>
                <h3 className="font-bold mb-4">Links Rápidos</h3>
                <ul className="space-y-2 text-gray-500">
                  <li><Link to="/como-funciona" className="hover:text-gray-700">Como Funciona</Link></li>
                  <li><Link to="/planos-publicos" className="hover:text-gray-700">Planos</Link></li>
                  <li><Link to="/login" className="hover:text-gray-700">Login</Link></li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold mb-4">Legal</h3>
                <ul className="space-y-2 gray-500">
                  <li><Link to="/termos-privacidade" className="hover:text-gray-700">Termos e Privacidade</Link></li>
                  <li><Link to="/reembolso" className="hover:text-gray-700">Política de Reembolso</Link></li>
                  <li><Link to="/contato" className="hover:text-gray-700">Contato</Link></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-gray-700 pt-8 text-center text-gray-500 flex flex-col md:flex-row justify-between items-center gap-4">
              <p>&copy; 2025 Finança Online. Todos os direitos reservados.</p>
              <div className="flex items-center gap-2">
                <CreditCard size={20} className="text-gray-700" />
                <Shield size={20} className="text-gray-700" />
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default HowItWorksPage;