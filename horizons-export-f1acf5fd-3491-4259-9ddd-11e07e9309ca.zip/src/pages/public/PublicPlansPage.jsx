import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Star, Coffee, BarChart3, Target, Landmark, Headphones, Zap, Clock, Infinity, CreditCard, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/Logo';
import { PLAN_PRICES } from '@/utils/stripeConfig';

const PublicPlansPage = () => {
  const plans = [
    {
      id: PLAN_PRICES.basic_monthly.id,
      name: 'Básico Mensal',
      price: 'R$ 19,90',
      period: 'por mês',
      description: 'Controle essencial para o seu dia a dia',
      buttonText: "Quero o Básico",
      features: [
        { text: 'Fluxo de caixa mensal', icon: <Clock className="w-5 h-5" /> },
        { text: 'Relatórios básicos', icon: <BarChart3 className="w-5 h-5" /> },
        { text: 'Até 5 contas bancárias', icon: <Landmark className="w-5 h-5" /> },
        { text: 'Suporte por e-mail', icon: <Headphones className="w-5 h-5" /> }
      ],
      highlight: false,
      link: `/cadastro?plan=${PLAN_PRICES.basic_monthly.id}`
    },
    {
      id: PLAN_PRICES.pro_annual.id,
      name: 'PRO Anual',
      price: 'R$ 199,90',
      period: 'por ano',
      description: 'Economize e tenha recursos PRO o ano todo',
      buttonText: "Quero o PRO",
      originalPrice: 'R$ 238,80',
      discount: 'Economize R$ 38,90',
      features: [
        { text: 'Tudo do plano Básico', icon: <Check className="w-5 h-5" /> },
        { text: 'Relatórios Avançados', icon: <BarChart3 className="w-5 h-5" /> },
        { text: 'Contas ilimitadas', icon: <Infinity className="w-5 h-5" /> },
        { text: 'Planejamento de metas', icon: <Target className="w-5 h-5" /> },
        { text: 'Suporte prioritário', icon: <Zap className="w-5 h-5" /> },
        { text: 'Acesso antecipado', icon: <Star className="w-5 h-5" /> }
      ],
      highlight: true,
      link: `/cadastro?plan=${PLAN_PRICES.pro_annual.id}`
    }
  ];

  return (
    <>
      <Helmet>
        <title>Planos e Preços - Finança Online</title>
        <meta name="description" content="Conheça nossos planos e escolha a melhor opção para suas finanças." />
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
             <Link to="/"><Logo /></Link>
             <div className="flex gap-4">
               <Link to="/login"><Button variant="ghost">Entrar</Button></Link>
               <Link to="/cadastro"><Button className="bg-[#3FAE2A] hover:bg-[#359923] text-white">Começar Grátis</Button></Link>
             </div>
          </nav>
        </header>

        <div className="flex-1 py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-[#4A4A4A] mb-4">Escolha o plano ideal</h1>
              <p className="text-xl text-gray-600 flex items-center justify-center gap-2">
                <Coffee className="text-[#3FAE2A]" size={24} />
                Invista no seu controle financeiro por <strong>menos de um café por dia!</strong>
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {plans.map((plan, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`bg-white rounded-2xl p-8 flex flex-col h-full ${
                      plan.highlight 
                      ? 'ring-4 ring-[#FFD700]/40 shadow-2xl relative' 
                      : 'shadow-lg border border-gray-100'
                  }`}
                >
                  {plan.highlight && (
                      <div className="absolute -top-5 left-1/2 transform -translate-x-1/2 bg-[#FFD700] text-gray-900 px-8 py-2 rounded-full text-lg font-bold shadow-lg flex items-center gap-2 border-4 border-white whitespace-nowrap">
                        <Star size={20} fill="currentColor" strokeWidth={1.5} /> Recomendado
                      </div>
                  )}
                  
                  <div className="flex-grow">
                      <h3 className="text-2xl font-bold text-[#4A4A4A] mb-2">{plan.name}</h3>
                      <p className="text-gray-600 mb-4 min-h-[3rem]">{plan.description}</p>
                      
                      <div className="mb-6 p-6 bg-gray-50 rounded-2xl border border-gray-100 relative overflow-hidden">
                        {plan.originalPrice && (
                            <div className="text-gray-400 line-through text-sm mb-1">
                            {plan.originalPrice}
                            </div>
                        )}
                        <div className="flex items-baseline gap-2">
                            <span className="text-5xl font-extrabold text-[#3FAE2A] tracking-tight">{plan.price}</span>
                            <span className="text-gray-600 text-sm font-medium">{plan.period}</span>
                        </div>
                        {plan.discount && (
                            <div className="mt-3 inline-flex items-center gap-1.5 bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-bold">
                                <Zap size={14} fill="currentColor" /> {plan.discount}
                            </div>
                        )}
                      </div>

                      <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, i) => (
                          <li key={i} className="flex items-start gap-3">
                          <div className={`p-2 rounded-xl shrink-0 ${plan.highlight ? 'bg-[#3FAE2A] text-white' : 'bg-gray-100 text-gray-500'}`}>
                             {feature.icon}
                          </div>
                          <span className="text-gray-700 font-medium pt-1.5">{feature.text}</span>
                          </li>
                      ))}
                      </ul>
                  </div>

                  <Link to={plan.link} className="w-full">
                    <Button
                        className={`w-full h-14 text-xl font-bold rounded-xl shadow-lg transition-all duration-200 ${
                        plan.highlight
                            ? 'bg-[#3FAE2A] hover:bg-[#359923] text-white hover:shadow-xl hover:-translate-y-1'
                            : 'bg-white border-2 border-gray-200 text-gray-700 hover:border-gray-400 hover:bg-gray-50'
                        }`}
                    >
                        {plan.buttonText}
                    </Button>
                  </Link>
                  
                  <div className="mt-6 flex items-center justify-center gap-2 text-gray-400 text-xs font-medium">
                      <Shield size={12} /> Pagamento 100% seguro via Stripe
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-[#4A4A4A] text-white py-12 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-4 gap-8 mb-8">
              <div className="col-span-2">
                <Logo className="mb-4" />
                <p className="text-white/70 max-w-xs">Gestão financeira inteligente para você alcançar seus objetivos e realizar sonhos.</p>
              </div>
              <div>
                <h3 className="font-bold mb-4">Links Rápidos</h3>
                <ul className="space-y-2 text-white/70">
                  <li><Link to="/como-funciona" className="hover:text-white">Como Funciona</Link></li>
                  <li><Link to="/planos-publicos" className="hover:text-white">Planos</Link></li>
                  <li><Link to="/login" className="hover:text-white">Login</Link></li>
                </ul>
              </div>
              <div>
                <h3 className="font-bold mb-4">Legal</h3>
                <ul className="space-y-2 text-white/70">
                  <li><Link to="/termos-privacidade" className="hover:text-white">Termos e Privacidade</Link></li>
                  <li><Link to="/reembolso" className="hover:text-white">Política de Reembolso</Link></li>
                  <li><Link to="/contato" className="hover:text-white">Contato</Link></li>
                </ul>
              </div>
            </div>
            <div className="border-t border-white/20 pt-8 text-center text-white/70 flex flex-col md:flex-row justify-between items-center gap-4">
              <p>&copy; 2025 Finança Online. Todos os direitos reservados.</p>
              <div className="flex gap-4">
                 <CreditCard size={20} />
                 <Shield size={20} />
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default PublicPlansPage;