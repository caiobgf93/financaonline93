import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowRight } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import ResendEmailButton from '@/components/ResendEmailButton';

const ConfirmacaoPage = () => {
  const location = useLocation();
  const email = location.state?.email;

  return (
    <>
      <Helmet>
        <title>Valide o E-mail</title>
      </Helmet>
      
      <div className="min-h-screen bg-[#F5F5F5] flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md text-center"
        >
          <div className="mb-6 flex justify-center">
             <div className="h-20 w-20 bg-green-100 rounded-full flex items-center justify-center">
                <Mail className="h-10 w-10 text-[#3FAE2A]" />
             </div>
          </div>
          
          <h1 className="text-2xl font-bold text-[#4A4A4A] mb-4">Necessário validar o e-mail</h1>
          
          <p className="text-gray-600 mb-6 leading-relaxed">
            Confirme o acesso no seu e-mail com o link enviado{email ? <span className="font-semibold"> ({email})</span> : ''}. 
          </p>

          <div className="space-y-4">
            {email && (
              <div className="mb-4">
                 <ResendEmailButton email={email} />
              </div>
            )}

            <Link to="/login" className="block w-full">
              <Button className="w-full bg-[#3FAE2A] hover:bg-[#359923] py-6 text-lg">
                Ir para o Login <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </motion.div>
        
        <div className="mt-8">
          <Logo className="h-8 opacity-50 grayscale" />
        </div>
      </div>
    </>
  );
};

export default ConfirmacaoPage;