import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';

const PrivacyPage = () => {
  return (
    <>
      <Helmet><title>Política de Privacidade - Finança Online</title></Helmet>
      <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
             <Link to="/"><Logo /></Link>
             <Link to="/login"><Button variant="ghost">Entrar</Button></Link>
          </nav>
        </header>
        <div className="flex-1 max-w-4xl mx-auto px-4 py-12">
          <h1 className="text-3xl font-bold text-[#4A4A4A] mb-6">Política de Privacidade</h1>
          <div className="bg-white p-8 rounded-xl shadow-sm text-gray-600">
            <p className="mb-4">Esta página está em construção.</p>
            <p>Em breve, detalharemos aqui como protegemos seus dados.</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default PrivacyPage;