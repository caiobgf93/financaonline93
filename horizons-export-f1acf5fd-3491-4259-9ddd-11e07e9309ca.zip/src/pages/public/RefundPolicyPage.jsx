import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { RefreshCw, Clock, CreditCard, Mail, CheckCircle2, AlertTriangle } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const RefundPolicyPage = () => {
  const policies = [
    {
      title: "Garantia Incondicional de 7 Dias",
      icon: <CheckCircle2 className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Acreditamos na qualidade do nosso produto. Por isso, oferecemos uma garantia de satisfação total de 7 dias. Se você assinar qualquer plano e não ficar satisfeito por qualquer motivo dentro dos primeiros 7 dias corridos, devolveremos 100% do valor pago, sem perguntas e sem burocracia."
    },
    {
      title: "Como Solicitar o Reembolso",
      icon: <Mail className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Para solicitar o reembolso, basta enviar um e-mail para suporte@financaonline.com com o assunto 'Solicitação de Reembolso' e o e-mail utilizado na sua conta. Nossa equipe processará sua solicitação em até 2 dias úteis."
    },
    {
      title: "Prazos de Estorno",
      icon: <Clock className="w-5 h-5 text-[#3FAE2A]" />,
      content: "Após a confirmação do reembolso por nossa equipe, o valor será estornado automaticamente para o método de pagamento original. Para pagamentos via cartão de crédito, o estorno pode levar de 5 a 10 dias úteis para aparecer na sua fatura, dependendo da administradora do cartão."
    },
    {
      title: "Cancelamentos Após 7 Dias",
      icon: <AlertTriangle className="w-5 h-5 text-yellow-500" />,
      content: "Após o período de garantia de 7 dias, não oferecemos reembolsos parciais para períodos não utilizados (mensais ou anuais). Você pode cancelar a renovação automática a qualquer momento, e seu acesso continuará ativo até o final do ciclo de faturamento atual."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Política de Reembolso - Finança Online</title>
        <meta name="description" content="Saiba como funciona nossa garantia de 7 dias e política de reembolso." />
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
             <Link to="/"><Logo /></Link>
             <Link to="/contato"><Button variant="outline">Fale Conosco</Button></Link>
          </nav>
        </header>

        <main className="flex-1 py-12 md:py-20 px-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-3xl mx-auto bg-white rounded-2xl shadow-lg overflow-hidden"
          >
            <div className="bg-[#3FAE2A] p-8 md:p-12 text-center text-white">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6">
                <RefreshCw className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">Política de Reembolso</h1>
              <p className="text-white/90 text-lg max-w-xl mx-auto">
                Sua satisfação é nosso compromisso. Entenda como funciona nossa garantia e processo de devolução.
              </p>
            </div>

            <div className="p-6 md:p-10">
              <Accordion type="single" collapsible defaultValue="item-0" className="w-full space-y-4">
                {policies.map((item, index) => (
                  <AccordionItem key={index} value={`item-${index}`} className="border border-gray-100 rounded-xl px-4 data-[state=open]:bg-[#E6F4E8] data-[state=open]:border-[#3FAE2A]/20 transition-colors">
                    <AccordionTrigger className="hover:no-underline py-5">
                      <div className="flex items-center gap-4 text-left">
                        <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-100">
                          {item.icon}
                        </div>
                        <span className="font-bold text-[#4A4A4A] text-lg">{item.title}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="text-gray-600 text-base leading-relaxed pb-6 pl-[4.5rem]">
                      {item.content}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>

              <div className="mt-10 bg-gray-50 p-6 rounded-xl border border-gray-200 text-center">
                <h3 className="font-bold text-[#4A4A4A] mb-2">Ainda tem dúvidas?</h3>
                <p className="text-gray-600 mb-4">Nossa equipe de suporte está pronta para ajudar você.</p>
                <Link to="/contato">
                  <Button className="bg-[#3FAE2A] hover:bg-[#359923]">Entrar em contato</Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </main>
        
        <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
          <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
            <p>&copy; 2025 Finança Online. Todos os direitos reservados.</p>
          </div>
        </footer>
      </div>
    </>
  );
};

export default RefundPolicyPage;