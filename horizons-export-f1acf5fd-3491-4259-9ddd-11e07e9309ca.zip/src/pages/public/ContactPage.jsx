import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, MapPin, Send, Instagram, Linkedin, Twitter, ArrowRight } from 'lucide-react';
import Logo from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Mensagem enviada!",
        description: "Recebemos seu contato e responderemos em breve.",
        duration: 5000,
      });
      e.target.reset();
    }, 1500);
  };

  return (
    <>
      <Helmet>
        <title>Fale Conosco - Finança Online</title>
        <meta name="description" content="Entre em contato com a equipe do Finança Online. Estamos aqui para ajudar." />
      </Helmet>

      <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
        <header className="bg-white shadow-sm sticky top-0 z-50">
          <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
             <Link to="/"><Logo /></Link>
             <Link to="/login"><Button variant="ghost">Entrar</Button></Link>
          </nav>
        </header>

        <div className="flex-1 flex flex-col">
          {/* Hero Section */}
          <div className="bg-[#3FAE2A] text-white py-16 md:py-24 text-center px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl mx-auto"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Entre em contato com a gente</h1>
              <p className="text-xl text-white/90">
                Tem alguma dúvida, sugestão ou precisa de ajuda? <br className="hidden md:block" />
                Nossa equipe está pronta para atender você.
              </p>
            </motion.div>
          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 mb-20 w-full">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Info Cards */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="lg:col-span-1 space-y-6"
              >
                <div className="bg-white p-8 rounded-2xl shadow-lg border-l-4 border-[#3FAE2A] h-full">
                  <h3 className="text-xl font-bold text-[#4A4A4A] mb-6">Canais de Atendimento</h3>
                  
                  <div className="space-y-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-green-50 p-3 rounded-xl text-[#3FAE2A]">
                        <Mail size={24} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-800">E-mail</p>
                        <p className="text-sm text-gray-500 mb-1">Para suporte e dúvidas gerais</p>
                        <a href="mailto:suporte@financaonline.com" className="text-[#3FAE2A] hover:underline font-medium">suporte@financaonline.com</a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-green-50 p-3 rounded-xl text-[#3FAE2A]">
                        <MessageSquare size={24} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-800">Chat Online</p>
                        <p className="text-sm text-gray-500 mb-1">Disponível no Dashboard</p>
                        <span className="text-gray-600 text-sm">Seg - Sex, 09h às 18h</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-green-50 p-3 rounded-xl text-[#3FAE2A]">
                        <MapPin size={24} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-800">Escritório</p>
                        <p className="text-gray-600 text-sm">
                          Av. Paulista, 1000 - Bela Vista<br/>
                          São Paulo, SP - Brasil
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-10 pt-8 border-t border-gray-100">
                    <p className="text-sm font-bold text-gray-500 mb-4 uppercase tracking-wider">Redes Sociais</p>
                    <div className="flex gap-4">
                      <a href="#" className="p-3 bg-gray-50 rounded-full text-gray-600 hover:bg-[#3FAE2A] hover:text-white transition-all">
                        <Instagram size={20} />
                      </a>
                      <a href="#" className="p-3 bg-gray-50 rounded-full text-gray-600 hover:bg-[#3FAE2A] hover:text-white transition-all">
                        <Linkedin size={20} />
                      </a>
                      <a href="#" className="p-3 bg-gray-50 rounded-full text-gray-600 hover:bg-[#3FAE2A] hover:text-white transition-all">
                        <Twitter size={20} />
                      </a>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Contact Form */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="lg:col-span-2"
              >
                <div className="bg-white p-8 md:p-10 rounded-2xl shadow-lg h-full">
                  <h3 className="text-2xl font-bold text-[#4A4A4A] mb-6">Envie uma mensagem</h3>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name">Seu Nome</Label>
                        <Input id="name" placeholder="Ex: João Silva" required className="h-12 bg-gray-50" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Seu E-mail</Label>
                        <Input id="email" type="email" placeholder="joao@exemplo.com" required className="h-12 bg-gray-50" />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="subject">Assunto</Label>
                      <Input id="subject" placeholder="Como podemos ajudar?" required className="h-12 bg-gray-50" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Mensagem</Label>
                      <Textarea 
                        id="message" 
                        placeholder="Descreva sua dúvida ou solicitação com detalhes..." 
                        className="min-h-[150px] bg-gray-50 resize-none" 
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full md:w-auto bg-[#3FAE2A] hover:bg-[#359923] h-14 px-8 text-lg font-bold"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <span className="flex items-center gap-2">Enviando...</span>
                      ) : (
                        <span className="flex items-center gap-2">Enviar Mensagem <Send size={18} /></span>
                      )}
                    </Button>
                  </form>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
          <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
            <p>&copy; 2025 Finança Online. Todos os direitos reservados.</p>
          </div>
        </footer>
      </div>
    </>
  );
};

export default ContactPage;