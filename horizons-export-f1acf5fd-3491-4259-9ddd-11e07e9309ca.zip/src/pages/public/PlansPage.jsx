
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Check,
  Star,
  Shield,
  Headphones,
  Zap,
  Infinity,
  Loader2,
  CreditCard,
  BarChart3,
  Target,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { createCheckoutSession, cancelSubscription } from '@/utils/subscription';
import { useToast } from '@/components/ui/use-toast';
import { PLAN_PRICES } from '@/utils/stripeConfig';
import { usePlanName } from '@/hooks/usePlanName';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';

const PlansPage = () => {
  const { user, subscription, refreshSubscription } = useAuth();
  const { toast } = useToast();
  const [loadingPlanId, setLoadingPlanId] = useState(null);
  const [canceling, setCanceling] = useState(false);
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);

  const navigate = useNavigate();
  const { hasActivePlan, currentPlanName } = usePlanName(subscription);

  const handleSubscribe = async (planId) => {
    if (!user) {
      navigate('/login');
      return;
    }
    setLoadingPlanId(planId);
    try {
      await createCheckoutSession(planId);
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Erro ao iniciar pagamento",
        description: "Não foi possível conectar ao Stripe. Tente novamente."
      });
    } finally {
      setLoadingPlanId(null);
    }
  };

  const confirmCancel = () => {
    setIsCancelDialogOpen(true);
  };

  const handleCancel = async () => {
    setCanceling(true);
    try {
      await cancelSubscription();
      await refreshSubscription();
      toast({
        title: "Assinatura cancelada",
        description: "Sua assinatura não será renovada ao final do período.",
        variant: "default"
      });
    } catch (error) {
      console.error(error);
      toast({
        variant: "destructive",
        title: "Erro ao cancelar",
        description: "Não foi possível processar o cancelamento."
      });
    } finally {
      setCanceling(false);
      setIsCancelDialogOpen(false);
    }
  };

  const commonFeaturesMensal = [
    { text: 'Lançamentos Ilimitados', icon: <Infinity className="w-5 h-5" /> },
    { text: 'Controle de Contas e Cartões', icon: <CreditCard className="w-5 h-5" /> },
    { text: 'Relatórios Completos', icon: <BarChart3 className="w-5 h-5" /> },
    { text: 'Planejamento de Metas', icon: <Target className="w-5 h-5" /> },
    { text: 'Suporte', icon: <Headphones className="w-5 h-5" /> },
    { text: 'Backup Automático', icon: <Shield className="w-5 h-5" /> },
  ];
  
  const commonFeaturesAnual = [
    { text: 'Tudo do plano Básico', icon: <Infinity className="w-5 h-5" /> },
    { text: 'Suporte Prioritário', icon: <Headphones className="w-5 h-5" /> },
  ];

  const plans = [
    {
      id: PLAN_PRICES.basic_monthly.id,
      name: 'Plano Mensal',
      price: 'R$ 19,90',
      period: '/mês',
      description: 'Flexibilidade total para seu controle financeiro.',
      buttonText: "Assinar Mensal",
      features: commonFeaturesMensal,
      highlight: false
    },
    {
      id: PLAN_PRICES.pro_annual.id,
      name: 'Plano Anual',
      price: 'R$ 199,90',
      period: '/ano',
      description: 'A melhor escolha para economizar a longo prazo.',
      buttonText: "Assinar Anual",
      originalPrice: 'R$ 238,80',
      discountLabel: '2 MESES GRÁTIS',
      savingsText: 'Economize R$ 38,90 por ano',
      features: commonFeaturesAnual,
      highlight: true
    }
  ];

  return (
    <>
      <Helmet>
        <title>Meus Planos - Finança Online</title>
      </Helmet>

      <div className="py-8 md:py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 space-y-4">
            <h1 className="text-3xl md:text-5xl font-bold text-[#4A4A4A] tracking-tight">
              Invista no seu futuro
            </h1>
            <p className="text-xl text-gray-500 max-w-2xl mx-auto">
              Escolha o ciclo de pagamento ideal para você. Todos os recursos incluídos em ambos os planos.
            </p>
          </div>

          {hasActivePlan && (
            <div className="max-w-3xl mx-auto mb-16 bg-gradient-to-r from-green-50 to-white p-6 rounded-2xl shadow-sm border border-green-100 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-start gap-4">
                <div className="bg-[#3FAE2A] p-3 rounded-xl text-white shadow-md">
                  <Check size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-800">Assinatura Ativa</h3>
                  <p className="text-gray-600 mt-1">
                    Você está atualmente no <strong>{currentPlanName}</strong>.
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    {subscription.cancel_at_period_end 
                      ? "Seu acesso permanecerá ativo até:"
                      : "Renovação automática em:"}
                    {' '}
                    {subscription.current_period_end ? new Date(subscription.current_period_end).toLocaleDateString('pt-BR') : 'N/A'}
                  </p>
                </div>
              </div>

              {subscription.cancel_at_period_end ? (
                <Button
                  variant="outline"
                  disabled
                  className="whitespace-nowrap w-full md:w-auto border-gray-200 bg-gray-50 text-gray-500 opacity-100 cursor-default"
                >
                  Cancelada — acesso até {new Date(subscription.current_period_end).toLocaleDateString('pt-BR')}
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={confirmCancel}
                  disabled={canceling}
                  className="whitespace-nowrap w-full md:w-auto border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
                >
                  {canceling ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  {canceling ? 'Cancelando...' : 'Cancelar Assinatura'}
                </Button>
              )}
            </div>
          )}

          {/* Cards dos planos */}
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => {
              const planType = subscription?.plan_type;
              const isMonthlyPlanCard = plan.id === PLAN_PRICES.basic_monthly.id;
              const isAnnualPlanCard = plan.id === PLAN_PRICES.pro_annual.id;
              const isAnyLoading = loadingPlanId !== null;
              const isLoadingThis = loadingPlanId === plan.id;
              
              let isButtonDisabled = false;
              let isCurrentPlan = false;

              if (planType === 'monthly') {
                if (isMonthlyPlanCard) {
                  isButtonDisabled = true;
                  isCurrentPlan = true;
                }
              } else if (planType === 'annual') {
                if (isMonthlyPlanCard) {
                  isButtonDisabled = true;
                } else if (isAnnualPlanCard) {
                  isButtonDisabled = true;
                  isCurrentPlan = true;
                }
              }
              
              if (isAnyLoading) {
                isButtonDisabled = true;
              }

              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex flex-col bg-white rounded-3xl transition-all duration-300 ${plan.highlight
                    ? 'shadow-2xl ring-4 ring-[#3FAE2A]/10 border-transparent scale-100 md:scale-105 z-10'
                    : 'shadow-lg border border-gray-100 hover:border-gray-200 z-0'
                    }`}
                >
                  {plan.highlight && (
                    <div className="absolute -top-5 left-1/2 -translate-x-1/2">
                      <div className="bg-[#3FAE2A] text-white px-6 py-2 rounded-full font-bold text-sm shadow-lg flex items-center gap-2 tracking-wide uppercase">
                        <Star size={14} fill="currentColor" /> Recomendado
                      </div>
                    </div>
                  )}

                  <div className="p-8 flex-grow">
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">{plan.name}</h3>
                    <p className="text-gray-500 mb-6">{plan.description}</p>

                    <div className="mb-8">
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl md:text-5xl font-extrabold text-[#3FAE2A] tracking-tighter">
                          {plan.price}
                        </span>
                        <span className="text-gray-500 font-medium">{plan.period}</span>
                      </div>

                      {plan.originalPrice && (
                        <div className="mt-2 flex flex-col items-start gap-1">
                          <span className="text-sm text-gray-400 line-through font-medium">
                            De {plan.originalPrice}
                          </span>
                          <span className="inline-block bg-orange-100 text-orange-700 text-xs font-bold px-3 py-1 rounded-full">
                            {plan.savingsText}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4">
                      {plan.features.map((feature, i) => (
                        <div key={i} className="flex items-center gap-3 group">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors ${plan.highlight
                              ? 'bg-[#3FAE2A]/10 text-[#3FAE2A]'
                              : 'bg-gray-100 text-gray-500 group-hover:bg-[#3FAE2A]/10 group-hover:text-[#3FAE2A]'
                              }`}
                          >
                            <Check size={16} strokeWidth={3} />
                          </div>
                          <span className="text-gray-600 font-medium text-sm md:text-base">
                            {feature.text}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-8 pt-0 mt-auto">
                    <Button
                      onClick={() => handleSubscribe(plan.id)}
                      disabled={isButtonDisabled}
                      className={`w-full h-14 text-lg font-bold rounded-xl transition-all duration-300 ${plan.highlight
                        ? 'bg-[#3FAE2A] hover:bg-[#359923] text-white shadow-lg hover:shadow-xl hover:-translate-y-1'
                        : 'bg-gray-50 hover:bg-gray-100 text-gray-800 hover:text-[#3FAE2A] border border-gray-200'
                        }`}
                    >
                      {isLoadingThis ? (
                        <span className="flex items-center gap-2">
                          <Loader2 className="animate-spin" /> Processando...
                        </span>
                      ) : isCurrentPlan ? (
                        <span className="flex items-center gap-2">
                          <Check size={20} /> Plano Atual
                        </span>
                      ) : (
                        plan.buttonText
                      )}
                    </Button>

                    {plan.highlight && (
                      <p className="text-center text-xs text-gray-400 mt-4 font-medium flex items-center justify-center gap-1">
                        <Zap size={12} /> Cancele quando quiser
                      </p>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>

          <div className="mt-16 text-center">
            <p className="text-gray-400 text-sm flex items-center justify-center gap-2">
              <Shield size={16} /> Pagamentos processados com segurança pelo Stripe. Seus dados estão protegidos.
            </p>
          </div>
        </div>
      </div>

      {/* Modal de cancelamento */}
      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent className="bg-white w-[90%] max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <Trash2 size={20} /> Cancelar Assinatura
            </DialogTitle>
            <DialogDescription>
              Tem certeza que deseja cancelar sua assinatura?<br />
              Você continuará tendo acesso aos benefícios até o final do período pago.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => setIsCancelDialogOpen(false)}
              className="w-full sm:w-auto"
            >
              Manter Assinatura
            </Button>
            <Button
              variant="destructive"
              onClick={handleCancel}
              disabled={canceling}
              className="bg-red-600 hover:bg-red-700 w-full sm:w-auto"
            >
              {canceling ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              {canceling ? 'Cancelando...' : 'Confirmar Cancelamento'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default PlansPage;
