export const STRIPE_PUBLIC_KEY = 'pk_test_51Sajiq9KXxTuVm1fQOJgCHtCSZ5BPdEcug3tXD3utJm15Kkiut0rskBU7lcSVHvnhloJUubWKTLWkbzOj2JQLuCO003dSmtEYN';

export const PLAN_PRICES = {
  basic_monthly: {
    id: 'price_1SbCzk9KXxTuVm1fBUFBIVBQ',
    name: 'Básico Mensal',
    amount: 1990, // R$ 19,90
    interval: 'month'
  },
  pro_annual: {
    id: 'price_1SbD0X9KXxTuVm1fX90ZDuXA',
    name: 'PRO Anual',
    amount: 19990, // R$ 199,90
    interval: 'year'
  }
};