import { supabase } from '@/lib/supabase';

export const PLAN_LIMITS = {
  trial: { categories: 999, goals: 999, cards: 999, months: 12 },
  essential_monthly: { categories: 30, goals: 20, cards: 5, months: 6 },
  essential_annual: { categories: 30, goals: 20, cards: 5, months: 6 }
};

export const checkLimit = async (userId, table) => {
  // Get current subscription
  const { data: subscription } = await supabase
    .from('subscriptions')
    .select('plan_type')
    .eq('user_id', userId)
    .eq('status', 'active')
    .single();

  const plan = subscription?.plan_type || 'trial'; // Default to trial for demo
  const limits = PLAN_LIMITS[plan] || PLAN_LIMITS.trial;

  let limitKey;
  if (table === 'categories') limitKey = 'categories';
  if (table === 'financial_goals') limitKey = 'goals';
  if (table === 'credit_cards') limitKey = 'cards';

  if (!limitKey) return true;

  const { count, error } = await supabase
    .from(table)
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId);

  if (error) throw error;

  return count < limits[limitKey];
};

export const getPlanName = (planType) => {
  switch(planType) {
    case 'essential_monthly': return 'Essencial Mensal';
    case 'essential_annual': return 'Essencial Anual';
    default: return 'Teste Grátis';
  }
};