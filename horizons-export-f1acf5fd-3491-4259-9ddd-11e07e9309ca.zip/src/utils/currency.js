export const formatCurrency = (value) => {
  if (value === null || value === undefined) return 'R$ 0,00';
  
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(numValue);
};

export const parseCurrency = (value) => {
  if (!value) return 0;
  
  const cleaned = value.toString()
    .replace(/[^\d,.-]/g, '')
    .replace(/\./g, '')
    .replace(',', '.');
  
  return parseFloat(cleaned) || 0;
};

export const maskCurrency = (value) => {
  let numValue = value.toString().replace(/\D/g, '');
  
  if (numValue === '') return '';
  
  numValue = (parseInt(numValue) / 100).toFixed(2);
  
  return formatCurrency(numValue);
};