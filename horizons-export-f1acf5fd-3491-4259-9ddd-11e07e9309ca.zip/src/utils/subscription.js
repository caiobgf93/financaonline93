
import { supabase } from '@/lib/supabase';
import { PLAN_PRICES } from './stripeConfig';

/**
 * Cria uma sessão de checkout no Stripe via Supabase Edge Function
 */
export const createCheckoutSession = async (planId) => {
  try {
    // Verifica se o plano existe
    const planEntry = Object.entries(PLAN_PRICES).find(([key, val]) => val.id === planId);
    const plan = planEntry ? planEntry[1] : null;

    if (!plan) throw new Error('Plano inválido');

    // Verifica se o usuário está logado
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      window.location.href = '/login';
      return;
    }

    // Invoca a função Edge "create-checkout-session"
    const { data, error } = await supabase.functions.invoke('create-checkout-session', {
      body: {
        planId: plan.id,               // envia o price_id
        returnUrl: window.location.origin // URL base para success/cancel
      },
      headers: {
        Authorization: `Bearer ${session.access_token}` // 👈 envia o token do usuário
      }
    });

    if (error) {
      console.error("Erro Supabase Function:", error.message || error);
      throw error;
    }

    if (data?.url) {
      window.location.href = data.url;
    } else {
      throw new Error('Não foi possível iniciar o checkout');
    }
  } catch (error) {
    console.error('Erro ao criar sessão de checkout:', error.message || error);
    throw error;
  }
};

/**
 * Cancela a assinatura ativa do usuário
 * Flow:
 * 1. Invoca Edge Function para cancelar no Stripe
 * 2. Se sucesso, atualiza explicitamente a tabela local para refletir o status imediatamente
 */
export const cancelSubscription = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Usuário não autenticado');

    // 1. Solicitar cancelamento no Stripe (Backend)
    const { data, error } = await supabase.functions.invoke('cancel-subscription', {
      method: 'POST'
    });

    if (error) {
      console.error("Erro Supabase Function (cancel):", error.message || error);
      throw error;
    }

    // 2. Atualizar tabela localmente para feedback instantâneo (Frontend/DB)
    // Isso garante que a UI saiba que 'cancel_at_period_end' é true sem esperar webhook
    const { error: dbError } = await supabase
      .from('subscriptions')
      .update({ cancel_at_period_end: true })
      .eq('user_id', user.id);

    if (dbError) {
      console.error('Erro ao sincronizar cancelamento no DB local:', dbError);
      // Não lançamos erro aqui pois o Stripe já processou, é apenas delay visual
    }

    return data;
  } catch (error) {
    console.error('Erro ao cancelar assinatura:', error.message || error);
    throw error;
  }
};

/**
 * Verifica o status da assinatura do usuário
 */
export const checkSubscriptionStatus = async (userId) => {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (error) {
    console.error("Erro ao verificar assinatura:", error.message || error);
    return null;
  }
  return data;
};
