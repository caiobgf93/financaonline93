import React from 'react';

/**
 * @typedef {'monthly' | 'annual' | 'trial' | 'pro'} PlanType
 */

/**
 * Hook utilitário para obter nome do plano e status da assinatura.
 * PURE FUNCTION: This hook must NEVER modify the database. It only formats data for display.
 * 
 * @param {object} [subscription] - Objeto de assinatura do usuário.
 * @returns {{hasActivePlan: boolean, currentPlanName: string, planType: string | null}}
 */
export function usePlanName(subscription) {
  // A subscription is considered "active" for UI purposes if status is 'active'.
  const isActive = subscription?.status === 'active';
  const planKey = subscription?.plan_type ?? null;

  const planNames = {
    monthly: 'Básico Mensal',
    annual: 'PRO Anual',
    pro: 'Plano PRO',
    trial: 'Teste Grátis',
  };

  const currentPlanName = planKey
    ? planNames[planKey] ?? 'Plano Desconhecido'
    : 'Sem Assinatura';

  return { 
    hasActivePlan: isActive, 
    currentPlanName,
    planType: planKey 
  };
}