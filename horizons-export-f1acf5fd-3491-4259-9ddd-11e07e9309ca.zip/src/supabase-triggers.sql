-- This is a reference file for the triggers and policies that should be in place.
-- I will use the type="database" to apply these.

-- Trigger for automatically creating a subscription on user creation
-- NOTE: Since I cannot create triggers directly in SQL Editor from here easily without knowing if I have permissions,
-- I will rely on the manual creation in signUp logic for now, which is safer for frontend-only environments unless I have direct SQL access.
-- However, I will attempt to set up the tables correctly.