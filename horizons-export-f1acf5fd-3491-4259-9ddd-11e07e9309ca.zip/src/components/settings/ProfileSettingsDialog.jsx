import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { User, CreditCard, Shield, Camera, Loader2, Trash2, Check, ExternalLink } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useNavigate } from 'react-router-dom';

const ProfileSettingsDialog = ({ open, onOpenChange, defaultTab = 'profile' }) => {
  const { user, subscription } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(defaultTab);

  // Profile State
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [fullName, setFullName] = useState(user?.user_metadata?.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.user_metadata?.avatar_url || null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const fileInputRef = useRef(null);

  // Security State
  const [loadingSecurity, setLoadingSecurity] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  useEffect(() => {
    if (open) {
      setActiveTab(defaultTab);
      setFullName(user?.user_metadata?.full_name || '');
      setAvatarUrl(user?.user_metadata?.avatar_url || null);
    }
  }, [open, defaultTab, user]);

  // --- Profile Logic ---
  const handleAvatarUpload = async (event) => {
    try {
      setUploadingAvatar(true);
      const file = event.target.files?.[0];
      if (!file) return;

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}-${Math.random()}.${fileExt}`;
      const filePath = `${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get Public URL
      const { data } = supabase.storage.from('avatars').getPublicUrl(filePath);

      if (data) {
        setAvatarUrl(data.publicUrl);
        // Auto-save avatar change
        await updateUserMetadata({ avatar_url: data.publicUrl });
      }

    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({
        variant: "destructive",
        title: "Erro ao enviar imagem",
        description: "Verifique se a imagem é válida e tente novamente."
      });
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleDeleteAvatar = async () => {
    setAvatarUrl(null);
    await updateUserMetadata({ avatar_url: null });
  };

  const updateUserMetadata = async (metadata) => {
    const { error } = await supabase.auth.updateUser({
      data: metadata
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar",
        description: error.message
      });
    } else {
      toast({
        title: "Perfil atualizado!",
        description: "Suas alterações foram salvas com sucesso.",
        className: "bg-[#E6F4E8] border-[#3FAE2A] text-[#3FAE2A]"
      });
    }
  };

  const handleSaveProfile = async () => {
    setLoadingProfile(true);
    await updateUserMetadata({ full_name: fullName, avatar_url: avatarUrl });
    setLoadingProfile(false);
  };

  // --- Security Logic ---
  const handleUpdatePassword = async (e) => {
    e.preventDefault();

    if (newPassword !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Senhas não conferem",
        description: "A nova senha e a confirmação devem ser iguais."
      });
      return;
    }

    if (newPassword.length < 6) {
      toast({
        variant: "destructive",
        title: "Senha muito fraca",
        description: "A senha deve ter pelo menos 6 caracteres."
      });
      return;
    }

    setLoadingSecurity(true);

    try {
      // Verify current password first
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: currentPassword
      });

      if (signInError) {
        throw new Error("Senha atual incorreta.");
      }

      // Update to new password
      const { error: updateError } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (updateError) throw updateError;

      toast({
        title: "Senha alterada!",
        description: "Sua senha foi atualizada com sucesso.",
        className: "bg-[#E6F4E8] border-[#3FAE2A] text-[#3FAE2A]"
      });

      // Reset fields
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');

    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao atualizar senha",
        description: error.message
      });
    } finally {
      setLoadingSecurity(false);
    }
  };

  const handlePlanRedirect = () => {
    onOpenChange(false);
    navigate('/planos');
  };

  const getPlanName = () => {
    if (!subscription) return 'Carregando...';
    if (subscription.plan_type === 'trial') return 'Período de Teste Gratuito';
    if (subscription.plan_type?.includes('monthly')) return 'Plano Mensal';
    if (subscription.plan_type?.includes('annual')) return 'Plano Anual';
    return 'Plano Gratuito';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[700px] p-0 overflow-hidden bg-white rounded-2xl shadow-xl ring-1 ring-black/5">
        <div className="flex h-[80vh] max-h-[900px]">


          {/* Sidebar */}
          <div className="w-64 bg-white/80 backdrop-blur-sm border-r border-gray-100 p-6 flex flex-col rounded-l-2xl h-full">




            <DialogTitle className="text-xl font-bold text-[#4A4A4A] mb-6">Configurações</DialogTitle>
            <Tabs value={activeTab} onValueChange={setActiveTab} orientation="vertical" className="flex-1 flex flex-col space-y-2">
              <TabsList className="flex flex-col h-auto bg-transparent space-y-2 p-0">
                <TabsTrigger
                  value="profile"
                  className="w-full justify-start px-4 py-3 text-gray-500 hover:bg-[#E6F4E8] hover:text-[#3FAE2A]
  data-[state=active]:bg-[#E6F4E8] data-[state=active]:text-[#3FAE2A]
  data-[state=active]:font-bold
  rounded-xl transition-all flex items-center"
                >
                  <User className="w-4 h-4 mr-3" /> Perfil
                </TabsTrigger>


                <TabsTrigger
                  value="plan"
                  className="w-full justify-start px-4 py-3 text-gray-500 hover:bg-[#E6F4E8] hover:text-[#3FAE2A]
  data-[state=active]:bg-[#E6F4E8] data-[state=active]:text-[#3FAE2A]
  data-[state=active]:font-bold
  rounded-xl transition-all flex items-center"
                >
                  <CreditCard className="w-4 h-4 mr-3" /> Plano
                </TabsTrigger>

                <TabsTrigger
                  value="security"
                  className="w-full justify-start px-4 py-3 text-gray-500 hover:bg-[#E6F4E8] hover:text-[#3FAE2A]
  data-[state=active]:bg-[#E6F4E8] data-[state=active]:text-[#3FAE2A]
  data-[state=active]:font-bold
  rounded-xl transition-all flex items-center"
                >
                  <Shield className="w-4 h-4 mr-3" /> Segurança
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Content Area */}
          <div className="flex-1 p-8 overflow-y-auto bg-[#FAFAFA] rounded-r-2xl">
            <Tabs value={activeTab} className="w-full h-full">

              {/* --- PROFILE TAB --- */}
              <TabsContent value="profile" className="mt-0 h-full space-y-6 animate-in fade-in-50 duration-300">
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#4A4A4A]">Dados do Perfil</h3>
                  <p className="text-sm text-gray-500">Gerencie suas informações pessoais.</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="flex items-start gap-6">
                    <div className="relative group">
                      <Avatar className="w-24 h-24 border-4 border-transparent group-hover:border-[#3FAE2A] transition-all shadow-md">
                        <AvatarImage src={avatarUrl} />
                        <AvatarFallback className="bg-[#E6F4E8] text-[#3FAE2A] text-3xl font-bold">
                          {user?.email?.[0]?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div
                        className="absolute inset-0 bg-[#3FAE2A]/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        {uploadingAvatar ? <Loader2 className="w-8 h-8 text-white animate-spin" /> : <Camera className="w-8 h-8 text-white" />}
                      </div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                      />
                    </div>
                    <div className="flex-1 pt-2">
                      <div className="flex gap-2 mb-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => fileInputRef.current?.click()}
                          disabled={uploadingAvatar}
                          className="text-xs font-medium bg-white hover:bg-[#3FAE2A] hover:text-white border-gray-300 rounded-xl"
                        >
                          Alterar foto
                        </Button>
                        {avatarUrl && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={handleDeleteAvatar}
                            className="text-xs font-medium text-red-500 hover:bg-[#E6F4E8] hover:text-red-600 rounded-xl"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      <p className="text-xs text-gray-400">Recomendado: 400x400px. Max 2MB.</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
                  <div className="space-y-2">
                    <Label className="text-gray-600">Nome Completo</Label>
                    <Input
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Seu nome"
                      className="bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-600">E-mail</Label>
                    <Input
                      value={user?.email}
                      disabled
                      className="bg-gray-50 text-gray-500 cursor-not-allowed border-dashed"
                    />
                  </div>
                  <div className="pt-2 flex justify-end">
                    <Button
                      onClick={handleSaveProfile}
                      disabled={loadingProfile}
                      className="bg-[#3FAE2A] hover:bg-[#359923] text-white px-6"
                    >
                      {loadingProfile ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Check className="w-4 h-4 mr-2" />}
                      Salvar Alterações
                    </Button>
                  </div>
                </div>
              </TabsContent>

              {/* --- PLAN TAB --- */}
              <TabsContent value="plan" className="mt-0 h-full space-y-6 animate-in fade-in-50 duration-300">
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#4A4A4A]">Meu Plano</h3>
                  <p className="text-sm text-gray-500">Detalhes da sua assinatura atual.</p>
                </div>

                <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm flex flex-col items-center text-center space-y-4">
                  <div className="w-16 h-16 bg-[#E6F4E8] rounded-full flex items-center justify-center text-[#3FAE2A] mb-2">
                    <CreditCard className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-2xl font-bold text-[#4A4A4A] mb-1">{getPlanName()}</h4>
                    <p className="text-gray-500">
                      {subscription?.status === 'active'
                        ? 'Sua assinatura está ativa e em dia.'
                        : 'Seu período de teste está ativo.'}
                    </p>
                  </div>

                  {subscription?.current_period_end && (
                    <div className="bg-gray-50 px-4 py-2 rounded-full text-sm text-gray-600 border border-gray-200 mt-2">
                      Renovação em: <strong>{new Date(subscription.current_period_end).toLocaleDateString('pt-BR')}</strong>
                    </div>
                  )}

                  <div className="pt-6 w-full">
                    <Button onClick={handlePlanRedirect} className="w-full bg-[#3FAE2A] hover:bg-[#359923] text-white h-12 font-bold">
                      Gerenciar Assinatura <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </TabsContent>

              {/* --- SECURITY TAB --- */}
              <TabsContent value="security" className="mt-0 h-full space-y-6 animate-in fade-in-50 duration-300">
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-[#4A4A4A]">Segurança</h3>
                  <p className="text-sm text-gray-500">Atualize sua senha de acesso.</p>
                </div>

                <form onSubmit={handleUpdatePassword} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
                  <div className="space-y-2">
                    <Label className="text-gray-600">Senha Atual</Label>
                    <Input
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="••••••••"
                      className="bg-white"
                      required
                    />
                  </div>

                  <div className="h-px bg-gray-100 my-4" />

                  <div className="space-y-2">
                    <Label className="text-gray-600">Nova Senha</Label>
                    <Input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="bg-white"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-gray-600">Confirmar Nova Senha</Label>
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="bg-white"
                      required
                    />
                  </div>

                  <div className="pt-4 flex justify-end">
                    <Button
                      type="submit"
                      disabled={loadingSecurity}
                      className="bg-[#3FAE2A] hover:bg-[#359923] text-white px-6"
                    >
                      {loadingSecurity ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Shield className="w-4 h-4 mr-2" />}
                      Atualizar Senha
                    </Button>
                  </div>
                </form>
              </TabsContent>

            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProfileSettingsDialog;