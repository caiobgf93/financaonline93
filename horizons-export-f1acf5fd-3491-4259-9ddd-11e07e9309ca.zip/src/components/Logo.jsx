import React from 'react';
import { DollarSign } from 'lucide-react';

const Logo = ({ className = "h-8", customLogoUrl = null }) => {
  // Usa o customLogoUrl se vier via prop, senão cai no link fixo
  const logoSrc = customLogoUrl || "https://i.imgur.com/fAXCr65.png";

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <img 
  src="https://i.imgur.com/NApihLD.png" 
  alt="Logo" 
  className="h-14 w-auto object-contain" 
  onError={(e) => {
    e.target.onerror = null; 
    e.target.style.display = 'none';
    e.target.nextSibling.style.display = 'flex';
  }}
      />
      {/* Fallback se a imagem falhar */}
      <div className="hidden items-center gap-2">
        <div className="bg-[#3FAE2A] p-1.5 rounded-xl">
          <DollarSign className="text-white" size={20} />
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-xl font-bold text-[#3FAE2A]">Finança</span>
          <span className="text-xl font-bold text-[#4A4A4A]">Online</span>
        </div>
      </div>
    </div>
  );
};

export default Logo;