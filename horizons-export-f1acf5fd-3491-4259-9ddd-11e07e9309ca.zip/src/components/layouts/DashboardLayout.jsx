import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Wallet,
  CreditCard,
  PieChart,
  Target,
  LogOut,
  Menu,
  X,
  Receipt,
  Tag,
  Settings,
  HelpCircle,
  FileText,
  Plus,
  Clipboard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import ProfileSettingsDialog from '@/components/settings/ProfileSettingsDialog';
import Logo from '@/components/Logo';
import { cn } from '@/lib/utils';

const DashboardLayout = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  const navItems = [
    { icon: <LayoutDashboard size={20} />, label: 'Visão Geral', path: '/dashboard' },
    { icon: <Tag size={20} />, label: 'Categorias', path: '/dashboard/categorias' },
    { icon: <Wallet size={20} />, label: 'Lançamentos', path: '/dashboard/lancamentos' },
    { icon: <Clipboard size={20} />, label: 'Orçamentos', path: '/dashboard/orcamentos' },
    { icon: <Receipt size={20} />, label: 'Contas a Pagar', path: '/dashboard/contas' },
    { icon: <CreditCard size={20} />, label: 'Cartões', path: '/dashboard/cartoes' },
    { icon: <Target size={20} />, label: 'Metas', path: '/dashboard/metas' },
    { icon: <PieChart size={20} />, label: 'Relatórios', path: '/dashboard/relatorios' },
    { icon: <FileText size={20} />, label: 'Meus Planos', path: '/planos' },
  ];
  return (
    <div className="min-h-screen bg-[#F8F9FA] flex flex-col md:flex-row overflow-x-hidden justify-start">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b border-gray-200 px-4 py-3 flex justify-between items-center sticky top-0 z-50 shadow-sm h-16 shrink-0">
        <Logo className="h-8 w-auto" />
        <Button variant="ghost" size="icon" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X size={24} className="text-gray-600" /> : <Menu size={24} className="text-gray-600" />}
        </Button>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={cn(
          "absolute top-0 left-0 z-40 w-64 bg-white transform transition-transform duration-200 ease-in-out flex flex-col",
          "md:static md:h-screen md:w-64 md:bg-white md:flex md:flex-col md:z-40",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        )}
      >

        <div className="p-6 flex flex-col h-full">
          <div className="hidden md:block mb-14">
            <Logo />
          </div>

          <div className="mb-6 md:hidden">
            <Button
              className="w-full bg-[#3FAE2A] hover:bg-[#359923] text-white shadow-sm gap-2"
              onClick={() => {
                navigate('/dashboard/lancamentos');
                setIsMobileMenuOpen(false);
              }}
            >
              <Plus size={18} /> Novo Lançamento
            </Button>
          </div>

          <nav className="space-y-1 flex-1 overflow-y-auto pr-2 custom-scrollbar">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={() => cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  (item.path === '/dashboard' ? location.pathname === '/dashboard' : location.pathname.startsWith(item.path))
                    ? "bg-[#E6F4E8] text-[#3FAE2A]"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                {item.icon}
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="pt-4 border-t border-gray-100 space-y-1 mt-2">
            <NavLink
              to="/ajuda"
              onClick={() => setIsMobileMenuOpen(false)}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                isActive ? "bg-[#E6F4E8] text-[#3FAE2A]" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <HelpCircle size={20} />
              Central de Ajuda
            </NavLink>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-gray-50 transition-colors text-left group">
                  <Avatar className="h-9 w-9 border border-gray-100">
                    <AvatarImage src={user?.user_metadata?.avatar_url} />
                    <AvatarFallback className="bg-[#3FAE2A] text-white text-xs">
                      {user?.email?.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 overflow-hidden">
                    <p className="text-sm font-medium text-gray-900 truncate group-hover:text-[#3FAE2A] transition-colors">
                      {user?.user_metadata?.full_name || 'Usuário'}
                    </p>
                    <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                  </div>
                  <Settings size={16} className="text-gray-400 group-hover:text-[#3FAE2A]" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56" side="right" sideOffset={10}>
                <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setIsProfileOpen(true)} className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" /> Configurações
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-red-600 cursor-pointer focus:text-red-600 focus:bg-red-50">
                  <LogOut className="mr-2 h-4 w-4" /> Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile menu */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/20 z-30 md:hidden backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto md:h-screen w-full">
        <div className="px-4 py-2 md:p-8 max-w-[1600px] mx-auto mt-0">
          <Outlet />
        </div>
      </main>

      <ProfileSettingsDialog
        open={isProfileOpen}
        onOpenChange={setIsProfileOpen}
      />
    </div>
  );
};

export default DashboardLayout;