import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/lib/customSupabaseClient';

const ResendEmailButton = ({ email }) => {
  const [cooldown, setCooldown] = useState(0);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((c) => Math.max(c - 1, 0)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  const handleResend = async () => {
    if (!email || sending || cooldown > 0) return;
    setSending(true);

    await supabase.auth.resend({
      type: 'signup',
      email,
      // sem redirectTo → Supabase usa o que está configurado no Dashboard
    });

    setCooldown(60);
    setSending(false);
  };

  return (
    <Button
      type="button"
      onClick={handleResend}
      disabled={sending || cooldown > 0}
      className="w-full mt-4 bg-[#3FAE2A] hover:bg-[#359923]"
    >
      {cooldown > 0
        ? `Reenviar em ${cooldown}s`
        : sending
          ? 'Enviando...'
          : 'Reenviar e‑mail de confirmação'}
    </Button>
  );
};

export default ResendEmailButton;