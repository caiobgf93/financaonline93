import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { supabase, createTrialSubscription } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  // UseCallback garante que essa função não seja recriada a cada renderização
  const fetchSubscription = useCallback(async (currentUser) => {
    if (!currentUser) return;

    try {
      let { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', currentUser.id)
        .maybeSingle();

      // Ensure trial is created if it doesn't exist
      if (!data) {
        console.log('[AuthContext] No subscription found. Attempting to create trial...');
        // Pass the full user object to ensure public.users record exists
        const { data: newSub, error: createError } = await createTrialSubscription(currentUser);

        if (newSub) {
          data = newSub;
        } else {
          console.error('[AuthContext] Failed to create trial:', createError);
        }
      }

      setSubscription(data);
    } catch (err) {
      console.error('[AuthContext] Exception fetching subscription:', err);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    // Initial session check
    const initializeSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();

        if (error) {
          // Fix: Handle refresh token errors by clearing session
          if (error.message.includes("refresh_token_not_found") || error.message.includes("Invalid Refresh Token")) {
            console.log('[AuthContext] Refresh token invalid, signing out...');
            await supabase.auth.signOut();
            setUser(null);
            setSubscription(null);
          }
          // Don't throw, just log
          console.warn("[AuthContext] Session init warning:", error.message);
        }

        if (mounted) {
          if (session?.user) {
            setUser(session.user);
            await fetchSubscription(session.user);
          }
        }
      } catch (error) {
        console.error("[AuthContext] Unexpected auth init error:", error);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    initializeSession();

    // Listen for auth changes
    const { data: { subscription: authListener } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log(`[Auth] Event: ${event}`);

        if (!mounted) return;

        if (event === 'SIGNED_OUT' || event === 'USER_DELETED') {
          setUser(null);
          setSubscription(null);
          setLoading(false);
          return;
        }

        if (session?.user) {
          // Update user state only if it changed or if it's a new login
          setUser(prev => {
            // Compara ID e updated_at para evitar loops de renderização
            if (prev?.id === session.user.id && prev?.updated_at === session.user.updated_at) {
              return prev;
            }
            return session.user;
          });

          // Re-fetch subscription on sign in or token refresh
          if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED' || event === 'INITIAL_SESSION') {
            await fetchSubscription(session.user);
          }
        }

        setLoading(false);
      }
    );

    return () => {
      mounted = false;
      authListener.unsubscribe();
    };
  }, [fetchSubscription]); // Dependência segura

  const signIn = async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (error) return { data: null, error };
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  };

  const signInWithProvider = async (provider) => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: `${window.location.origin}/dashboard`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });

      if (error) return { data: null, error };
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  };

  const signUp = async (email, password, options) => {
    try {
      const { data, error } = await supabase.auth.signUp({ email, password, options });
      if (error) return { data: null, error };
      return { data, error: null };
    } catch (err) {
      return { data: null, error: err };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSubscription(null);
  };

  const isSubscriptionExpired = () => {
    if (!subscription) return true;
    if (subscription.status === 'active' || subscription.plan_type === 'trial') {
      const endString = subscription.current_period_end || subscription.end_date;
      if (!endString) return false;
      return new Date() > new Date(endString);
    }
    return true;
  };

  const daysUntilExpiration = () => {
    const endString = subscription?.current_period_end || subscription?.end_date;
    if (!endString) return 0;
    const diff = new Date(endString).getTime() - Date.now();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  };

  const value = {
    signUp,
    signIn,
    signInWithProvider,
    signOut,
    user,
    subscription,
    isExpired: isSubscriptionExpired(),
    daysUntilExpiration: daysUntilExpiration(),
    loading,
    refreshSubscription: () => user && fetchSubscription(user)
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);