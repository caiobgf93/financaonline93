
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
import { Toaster } from '@/components/ui/toaster';

// Public pages
import HomePage from '@/pages/public/HomePage';
import HowItWorksPage from '@/pages/public/HowItWorksPage';
import LoginPage from '@/pages/public/LoginPage';
import SignupPage from '@/pages/public/SignupPage';
import ForgotPasswordPage from '@/pages/public/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/public/ResetPasswordPage';
import SuccessPage from '@/pages/public/SuccessPage';
import PublicPlansPage from '@/pages/public/PublicPlansPage'; 
import TermsAndPrivacyPage from '@/pages/public/TermsAndPrivacyPage';
import ContactPage from '@/pages/public/ContactPage';
import RefundPolicyPage from '@/pages/public/RefundPolicyPage';
import ConfirmacaoPage from '@/pages/public/ConfirmacaoPage';
import EmailConfirmado from '@/pages/public/EmailConfirmado';

// Dashboard pages
import DashboardLayout from '@/components/layouts/DashboardLayout';
import DashboardHome from '@/pages/dashboard/DashboardHome';
import CategoriesPage from '@/pages/dashboard/CategoriesPage';
import BudgetsPage from '@/pages/dashboard/BudgetsPage';
import TransactionsPage from '@/pages/dashboard/TransactionsPage';
import CreditCardsPage from '@/pages/dashboard/CreditCardsPage';
import GoalsPage from '@/pages/dashboard/GoalsPage';
import ReportsPage from '@/pages/dashboard/ReportsPage';
import PlansPage from '@/pages/public/PlansPage';
import BillsPage from '@/pages/dashboard/BillsPage';
import SupportPage from '@/pages/dashboard/SupportPage';

import ProtectedRoute from '@/components/ProtectedRoute';

function AppRoutes() {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen w-full bg-[#F5F5F5]">
         <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-[#3FAE2A]"></div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<HomePage />} />
      <Route path="/como-funciona" element={<HowItWorksPage />} />
      <Route path="/planos-publicos" element={<PublicPlansPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/cadastro" element={<SignupPage />} />
      <Route path="/recuperar-senha" element={<ForgotPasswordPage />} />
      <Route path="/reset-password" element={<ResetPasswordPage />} />
      <Route path="/success" element={<SuccessPage />} />
      <Route path="/confirmacao" element={<ConfirmacaoPage />} />
      <Route path="/email-confirmado" element={<EmailConfirmado />} />
      
      {/* Legal & Contact */}
      <Route path="/termos-privacidade" element={<TermsAndPrivacyPage />} />
      <Route path="/contato" element={<ContactPage />} />
      <Route path="/reembolso" element={<RefundPolicyPage />} />

      {/* Redirect old routes for safety */}
      <Route path="/termos" element={<Navigate to="/termos-privacidade" replace />} />
      <Route path="/privacidade" element={<Navigate to="/termos-privacidade" replace />} />

      {/* Dashboard routes */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardHome />} />
        <Route path="categorias" element={<CategoriesPage />} />
        <Route path="orcamentos" element={<BudgetsPage />} />
        <Route path="lancamentos" element={<TransactionsPage />} />
        <Route path="contas" element={<BillsPage />} />
        <Route path="cartoes" element={<CreditCardsPage />} />
        <Route path="metas" element={<GoalsPage />} />
        <Route path="relatorios" element={<ReportsPage />} />
      </Route>
      
      {/* Routes outside /dashboard but using layout (or can be nested if preferred) */}
      <Route element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
          <Route path="/planos" element={<PlansPage />} />
          <Route path="/ajuda" element={<SupportPage />} />
      </Route>

      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <Helmet>
          <title>Finança Online - Gestão Financeira Inteligente</title>
          <meta name="description" content="Controle suas finanças de forma simples e eficiente com Finança Online" />
        </Helmet>
        <AppRoutes />
        <Toaster />
      </Router>
    </AuthProvider>
  );
}

export default App;
